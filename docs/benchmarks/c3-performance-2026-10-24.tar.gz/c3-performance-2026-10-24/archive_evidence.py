"""Freeze an explicit public evidence set; never include the original device dump."""
import hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent;repo=root.parent.parent
summary=json.loads((root/'summary.json').read_text())
assert summary['final_device']['passed']
required={'hardware-smoke','hardware-storage','hardware-runtime','hardware-matrix',
          'hardware-throughput','final-confirmation','final-stars-repeats','hardware-soak','final-device'}
status=summary['validation_status']
assert {r['label'] for r in status if r['exit_code']==0}==required
assert all(r['exit_code']==0 for r in status)
assert summary['hardware-matrix']['pairs']==96 and summary['hardware-matrix']['equal_pairs']==96
assert summary['deployed_confirmation']['samples']==14
entries={}
def add(path,name=None):
 assert 'private' not in path.name and path.name!='backup.log',path
 entries[name or str(path.relative_to(root))]=path.read_bytes()
for pattern in ('*.json','*.log','*.py','idf-env.sh','pre-usb-fix-main.c','*serial-trace.bin'):
 for p in root.glob(pattern):
  if p.name=='backup.log':continue
  add(p)
for folder in ('campaign-packages','matrix'):
 for p in (root/'pico-evidence'/folder).rglob('*'):
  if p.is_file() and p.suffix in ('.json','.py','.lbc'):add(p)
for p in (root/'firmwares').glob('*/lightvm.bin'):add(p)
for variant in ('standard','pre-usb-fix','final'):
 for name in ('lightvm.elf','lightvm.map','sdkconfig','CMakeCache.txt'):
  p=root/'firmwares'/variant/name
  if p.exists():add(p)
for name in ('bootloader/bootloader.bin','partition_table/partition-table.bin','lightvm-partitions.csv'):
 add(repo/'build/c3-baseline'/name,'installation/'+name)
for name in ('ram-report.json','ha-stack-report.json','stack-paths.json'):
 add(repo/'build/pico-verify'/name,'pico-cross-build/'+name)
sources=['CMakeLists.txt','platforms/esp32/CMakeLists.txt','platforms/esp32/main/CMakeLists.txt',
 'platforms/esp32/boards/xiao_esp32c3.h','platforms/esp32/main/main.c','platforms/esp32/main/platform.c',
 'platforms/esp32/main/usb_connection.h','src/vm.c','tests/portable_contract.inc',
 'tests/test_esp32_usb_connection.c','tools/benchmark_numeric.py','tools/check_numeric_runtime_hardware.py',
 'tools/benchmark_animation_profile.py','tools/check_storage_hardware.py','tools/benchmark_saved_preset.py',
 'tools/client.py','tools/smoke_controller.py']
for name in sources:add(repo/name,'source/'+name)
entries['source-changes.patch']=subprocess.check_output(['git','diff','--binary','--',*sources],cwd=repo)
manifest={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(entries.items())}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=repo/'docs/benchmarks/c3-performance-2026-10-24.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name,data in sorted(entries.items()):
  info=tarfile.TarInfo('c3-performance-2026-10-24/'+name);info.size=len(data);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(data))
summary['evidence_archive']={'file':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
 'bytes':archive.stat().st_size,'files':len(entries),'private_device_dump_included':False}
(repo/'docs/benchmarks/c3-performance-2026-10-24.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['evidence_archive']))
