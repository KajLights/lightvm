"""Verify the installed image, reboot, and execute a persisted mapped program."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent
repo=root.parent.parent
sys.path.insert(0,str(repo/'tools'))
from client import Client,SerialTransport,STOP,FRAME
port='/dev/cu.usbmodem1101'
firmware=root/'firmwares/final/lightvm.bin'
package=(root/'pico-evidence/campaign-packages/saved-color.lbc').read_bytes()
name='boot_coherence_probe'
result={'firmware_sha256':hashlib.sha256(firmware.read_bytes()).hexdigest()}
client=Client(SerialTransport(port,no_reset=True),timeout=30)
try:
 original=client.get_config()
 result['before']=client.describe()
 assert original['outputs']==[],original
 assert client.programs()==[],client.programs()
 client.save_program(name,package)
finally:client.close()
subprocess.run([sys.executable,'-m','esptool','--chip','esp32c3','-p',port,
               'verify_flash','0x10000',str(firmware)],check=True)
time.sleep(1)
client=Client(SerialTransport(port,no_reset=True),timeout=30)
try:
 after=client.describe()
 assert after['boot_id']!=result['before']['boot_id'],'no reboot observed'
 assert after['board']=='xiao_esp32c3'
 for key,value in {'render_workers':1,'render_slice_us':2000,'render_epoch_target_us':2000,
                   'cpu_clock_hz':160000000,'bytecode_cache_bytes':256}.items():
  assert after[key]==value,(key,after[key])
 assert client.get_program(name)==package,'persisted readback mismatch'
 client.configure({'schema':'lightvm.config','outputs':[{'id':'probe','type':'ws2812b',
    'config':{'pin':'D1','count':200,'brightness_limit':32}}]})
 client.configure_composition([{'id':'color','program':name,'inputs':{
    'color':{'value':0x123456},'brightness':{'value':1.0}}}],output='probe')
 client.require_ok(client.command(STOP,output='probe'))
 client.require_ok(client.command(FRAME,bytes(4),output='probe'))
 assert bytes(client.pixel_snapshot)==bytes.fromhex('123456')*200,'persisted execution differs'
 result['persisted_program_execution']=True
finally:
 try:
  client.configure({'schema':'lightvm.config','outputs':[]})
  client.configure(original)
  client.delete_program(name)
  result['after']=client.describe()
  result['config']=client.get_config()
  result['programs']=client.programs()
  assert result['config']==original and result['programs']==[]
 finally:client.close()
result['passed']=True
(root/'final-device.json').write_text(json.dumps(result,indent=2)+'\n')
print('Installed image verified; persisted program survived reboot and rendered exactly; empty configuration restored.')
