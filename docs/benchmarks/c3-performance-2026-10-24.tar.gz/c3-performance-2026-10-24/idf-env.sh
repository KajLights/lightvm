export IDF_PATH=/Users/kws/work/kajlights/lightvm/build/cleanup-deps/esp-idf
export IDF_TOOLS_PATH=/Users/kws/work/kajlights/lightvm/build/cleanup-deps/idf-tools
export IDF_PYTHON_ENV_PATH="$IDF_TOOLS_PATH/python_env/idf5.5_py3.12_env"
export IDF_COMPONENT_MANAGER=0
export PATH="$IDF_PYTHON_ENV_PATH/bin:$IDF_TOOLS_PATH/tools/riscv32-esp-elf/esp-14.2.0_20251107/riscv32-esp-elf/bin:/Users/kws/work/kajlights/lightvm/build/pico-async-output/tooling/cmake/data/bin:$PATH"
