import json,time
from pathlib import Path
p=Path(__file__).with_name('campaign-status.json')
while True:
 try:rows=json.loads(p.read_text())
 except (FileNotFoundError,json.JSONDecodeError):rows=[]
 if rows and rows[-1]['label']=='campaign-restore-final-flash':
  assert len([r for r in rows if r['label'].startswith('paired-') and not r['label'].endswith('-flash') and r['exit_code']==0])==10, 'campaign incomplete'
  assert all(r['exit_code']==0 for r in rows)
  break
 time.sleep(1)
import run_validation
