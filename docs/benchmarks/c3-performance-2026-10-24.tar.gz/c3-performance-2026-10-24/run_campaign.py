"""Alternate preserved standard and selected C3 images; checkpoint each block."""
import json,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent
repo=root.parent.parent
py=sys.executable
port='/dev/cu.usbmodem1101'
state=[]
cases=['map','scalar','draw','sprites','control-rainbow','control-sweep','stable-stars','mixed','saved-rainbow','saved-stars']
def call(label,cmd):
 print('Starting '+label,flush=True)
 start=time.time()
 with (root/(label+'.log')).open('w') as log:
  r=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 state.append({'label':label,'exit_code':r.returncode,'start_unix':start,'end_unix':time.time()})
 (root/'campaign-status.json').write_text(json.dumps(state,indent=2)+'\n')
 if r.returncode:raise RuntimeError(label+' failed')
 print('Completed '+label,flush=True)
def flash(variant,label):
 firmware=root/'firmwares'/variant/'lightvm.bin'
 call(label+'-flash',[py,'-m','esptool','--chip','esp32c3','-p',port,'-b','460800','write_flash','0x10000',str(firmware)])
 return firmware
try:
 for trial in range(5):
  for variant in ('standard','final') if trial%2==0 else ('final','standard'):
   label=f'paired-{trial+1}-{variant}'
   fw=flash(variant,label)
   selected=cases if trial%2==0 else list(reversed(cases))
   call(label,[py,'tools/benchmark_animation_profile.py','--port',port,'--board','xiao_esp32c3',
     '--packages',str(root/'pico-evidence/campaign-packages'),'--firmware',str(fw),
     '--label',label,'--result',str(root/(label+'.json')),'--samples','1','--seconds','3',
     '--network-regime','Services compiled; unprovisioned network; USB STATUS at 20 Hz',
     *[arg for case in selected for arg in ('--case',case)]])
finally:
 flash('final','campaign-restore-final')
