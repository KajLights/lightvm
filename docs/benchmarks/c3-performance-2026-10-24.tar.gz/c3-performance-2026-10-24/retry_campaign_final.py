"""Retain the failed post-flash setup attempt and repeat its empty measurement block."""
import json,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent;repo=root.parent.parent
sys.path.insert(0,str(repo/'tools'))
from client import Client,SerialTransport
label='paired-5-final'
(root/(label+'.log')).rename(root/(label+'-setup-failed.log'))
c=Client(SerialTransport('/dev/cu.usbmodem1101',no_reset=True),timeout=30)
try:
 assert c.get_config()['outputs']==[]
 programs=c.programs()
 for p in programs:
  assert p['name'] in ('ap_control-rainbow','ap_control-stars','ap_control-sweep'),p
  c.delete_program(p['name'])
 assert c.programs()==[]
finally:c.close()
cases=['map','scalar','draw','sprites','control-rainbow','control-sweep','stable-stars','mixed','saved-rainbow','saved-stars']
args=[sys.executable,'tools/benchmark_animation_profile.py','--port','/dev/cu.usbmodem1101',
 '--board','xiao_esp32c3','--packages',str(root/'pico-evidence/campaign-packages'),
 '--firmware',str(root/'firmwares/final/lightvm.bin'),'--label',label,
 '--result',str(root/(label+'.json')),'--samples','1','--seconds','3',
 '--network-regime','Services compiled; unprovisioned network; USB STATUS at 20 Hz',
 *[a for case in cases for a in ('--case',case)]]
started=time.time()
with (root/(label+'.log')).open('w') as log:r=subprocess.run(args,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
(root/'campaign-retry-status.json').write_text(json.dumps({'label':label,'exit_code':r.returncode,
 'start_unix':started,'end_unix':time.time(),'reason':'Upload session lost immediately after flash; no samples recorded; removed three completed temporary uploads before repeating.'},indent=2)+'\n')
if r.returncode:raise RuntimeError('repeat failed')
print('Repeated final block completed; starting hardware validation.',flush=True)
import run_validation
