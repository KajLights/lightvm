"""Trace C3 protocol setup without changing firmware or retrying operations."""
import sys,time
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parent.parent/'tools'))
import serial
read=serial.Serial.read
raw=(root/'numeric-serial-trace.bin').open('wb',buffering=0)
def traced_read(self,*args,**kwargs):
 data=read(self,*args,**kwargs)
 if data:raw.write(data)
 return data
serial.Serial.read=traced_read
import benchmark_numeric as bench
base=bench.Client
class TracedClient(base):
 def __init__(self,*args,**kwargs):
  kwargs['timeout']=15
  super().__init__(*args,**kwargs)
 def save_program(self,name,data):
  print(f'UPLOAD {time.monotonic():.3f} {name} {len(data)} bytes',flush=True)
  return super().save_program(name,data)
 def describe(self):
  d=super().describe()
  print(f'DESCRIBE boot={d["boot_id"]} stack={d["main_stack_peak_bytes"]}',flush=True)
  return d
bench.Client=TracedClient
bench.main()
