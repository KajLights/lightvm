import hashlib,json,statistics
from pathlib import Path
root=Path(__file__).resolve().parent;repo=root.parent.parent

def distribution(values):
 values=[x for x in values if x is not None]
 return {'count':len(values),'median':statistics.median(values),'min':min(values),'max':max(values)} if values else None

def group(files):
 data={};allrows=[]
 for file in files:
  d=json.loads(file.read_text());assert d['measurement_complete'] and d['restoration_complete'],file
  for row in d['samples']:
   allrows.append(row)
   for layer,v in row['layers'].items():
    key=(row['case'],layer);data.setdefault(key,[]).append((row,v))
 result=[]
 for (case,layer),rows in data.items():
  gaps=[];heaps=[]
  for row,v in rows:
   samples=row['foreground_gap_samples'];gaps.append(samples[-1]['ingress_over_10ms']-samples[0]['ingress_over_10ms'])
   values=[h['heap'] for h in row['heap_samples']];heaps.append([min(values),max(values)])
  result.append({'case':case,'layer':layer,'render_us':distribution([v['mean_render_us'] for _,v in rows]),
   'updates_hz':distribution([v['updates_per_second'] for _,v in rows]),
   'presentations_hz':distribution([r['presentations_per_second'] for r,_ in rows]),
   'usb_p95_ms':distribution([r['status_latency_ms']['p95'] for r,_ in rows]),
   'usb_p99_ms':distribution([r['status_latency_ms']['p99'] for r,_ in rows]),
   'ingress_over_10ms_deltas':gaps,'heap_ranges':heaps})
 return result,allrows

pico=json.loads((repo/'docs/benchmarks/numeric-pico-validation-2026-10-23.json').read_text())
pico_saved=json.loads((root/'pico-evidence/saved-stars.json').read_text())
result={'schema':'lightvm.validation.c3-profile','date':'2026-10-24',
 'source_base':'fe97e17','scope':'USB-connected ESP32-C3; historical Pico W comparison, no simultaneous Pico attached',
 'profile':{'selection':'AUTO selects c3 on xiao_esp32c3; standard on S3/C6','core_optimization':'-O3; strict floating point; IDF default switch options',
 'draw_kernels':'IRAM','storage_reads':'persistent memory mapping','workers':1,'slice_us':2000,'epoch_us':2000,
 'usb_disconnect_confirmation_us':100000,
  'cpu_hz':160000000,'flash':'DIO 40 MHz','bytecode_cache_bytes':256,'vm_heap_bytes':131072},
 'method':{'paired_blocks':5,'pixels':200,'status_poll_hz':20,'control_seconds':3,'control_warmup_seconds':1,
  'saved_stars_seconds':30,'saved_stars_warmup_seconds':7,'stable_stars_warmup':'at least 2 seconds and 25 completed frames',
  'c3_network':'services compiled; unprovisioned network','pico_network':'configured Wi-Fi and MQTT, no intentional command load',
  'c3_pin':'D1/GPIO3','pico_pin':'GP16','c3_brightness_limit':32,'pico_saved_stars_brightness_limit':255,
  'saved_stars':'same frozen color/stars bytes, settings and input bindings; steady composition without entry fade',
  'optical_validation':False},'comparisons':[]}
raw={}
for variant in ('standard','final'):
 files=sorted(root.glob('paired-*-'+variant+'.json'));assert len(files)==5,(variant,len(files))
 rows,allrows=group(files);raw[variant]=rows
 result[variant]={'groups':rows,'files':[f.name for f in files],
  'firmware_sha256':json.loads(files[0].read_text())['firmware_sha256'],
  'samples':len(allrows),'status_samples':sum(r['status_latency_ms']['count'] for r in allrows),
  'ingress_over_10ms':sum(r['foreground_gap_samples'][-1]['ingress_over_10ms']-r['foreground_gap_samples'][0]['ingress_over_10ms'] for r in allrows),
  'max_usb_p95_ms':max(r['status_latency_ms']['p95'] for r in allrows),
  'max_main_stack_peak_bytes':max(r['description_after']['main_stack_peak_bytes'] for r in allrows)}
for row in raw['final']:
 base=next(x for x in raw['standard'] if (x['case'],x['layer'])==(row['case'],row['layer']))
 peer=next((x['candidate'] for x in pico['regression'] if (x['case'],x['layer'])==(row['case'],row['layer'])),None)
 if row['case']=='stable-stars':peer=pico['stars_population_control']['candidate']
 if row['case']=='saved-stars' and row['layer']=='A/layer1':
  old=[s['layers']['B/stars'] for s in pico_saved['samples']]
  peer={'updates_hz':distribution([r['updates_per_second'] for r in old]),'render_us':distribution([r['mean_render_us'] for r in old])}
 old=base['updates_hz']['median'];new=row['updates_hz']['median']
 result['comparisons'].append({'case':row['case'],'layer':row['layer'],'standard_updates_hz':old,'final_updates_hz':new,
  'gain_percent':(new/old-1)*100 if old else None,'pico':peer})
result['tuning_candidate']=result.pop('final')
result['comparisons_stage']='Five-pair tuning candidate before USB disconnect confirmation fix'
result['tuning_candidate']['stage']='Performance profile before USB disconnect confirmation fix; five paired blocks'
result['deployed_firmware_sha256']=hashlib.sha256((root/'firmwares/final/lightvm.bin').read_bytes()).hexdigest()
confirmation=[root/'final-confirmation.json',root/'final-stars-repeats.json']
if all(p.exists() and json.loads(p.read_text()).get('restoration_complete') for p in confirmation):
 groups,rows=group(confirmation)
 assert all(json.loads(p.read_text())['firmware_sha256']==result['deployed_firmware_sha256'] for p in confirmation)
 result['deployed_confirmation']={'groups':groups,'files':[p.name for p in confirmation],
  'samples':len(rows),'ingress_over_10ms':sum(r['foreground_gap_samples'][-1]['ingress_over_10ms']-r['foreground_gap_samples'][0]['ingress_over_10ms'] for r in rows),
  'max_usb_p95_ms':max(r['status_latency_ms']['p95'] for r in rows)}
result['screens']={p.stem:json.loads(p.read_text()) for p in root.glob('*-screen.json')}
# Keep detailed screens in the raw archive; summarise their outcomes here.
result['screens']={k:{'completed':v.get('measurement_complete',False),'samples':len(v['samples']),
 'firmware_sha256':v['firmware_sha256'],'cases':[{'case':r['case'],'render_us':{n:x['mean_render_us'] for n,x in r['layers'].items()},'updates_hz':{n:x['updates_per_second'] for n,x in r['layers'].items()},'usb_p95_ms':r['status_latency_ms']['p95']} for r in v['samples']]} for k,v in result['screens'].items()}
for name in ('hardware-storage','hardware-runtime','hardware-matrix','hardware-throughput','hardware-soak'):
 path=root/(name+'.json')
 if path.exists():
  d=json.loads(path.read_text())
  result[name]={'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'passed':d.get('passed',d.get('measurement_complete',False))}
  if name=='hardware-storage':result[name].update(cycles=len(d['cycles']),heap_values=sorted({r['heap'] for r in d['cycles']}))
  if name=='hardware-runtime':result[name].update(cases=len(d['cases']),rejected_candidates=sum(len(r['rejections']) for r in d['cases']))
  if name=='hardware-matrix':result[name].update(pairs=len(d['replays']),equal_pairs=sum(r['equal'] for r in d['replays']))
  if name=='hardware-throughput':
   groups={}
   for r in d['samples']:
    for layer,v in r['layers'].items():groups.setdefault((r['case'],r['pixels'],r['variant'],layer),[]).append((r,v))
   result[name]['groups']=[{'case':case,'pixels':pixels,'variant':variant,'layer':layer,
      'render_us':distribution([v['mean_render_us'] for _,v in rows]),'updates_hz':distribution([v['updates_per_second'] for _,v in rows]),
      'usb_p95_ms':distribution([r['status_latency_ms']['p95'] for r,_ in rows])}
      for (case,pixels,variant,layer),rows in groups.items()]
  if name=='hardware-soak':
   result[name]['samples']=[{'case':r['case'],'seconds':r['seconds'],'updates_hz':{k:v['updates_per_second'] for k,v in r['layers'].items()},
      'heap_range':[min(v['heap'] for v in r['heap_samples']),max(v['heap'] for v in r['heap_samples'])],
      'ingress_over_10ms':r['foreground_gap_samples'][-1]['ingress_over_10ms']-r['foreground_gap_samples'][0]['ingress_over_10ms'],
      'usb_p95_ms':r['status_latency_ms']['p95']} for r in d['samples']]
result['builds']=json.loads((root/'build-identities.json').read_text())
result['linked_memory']=json.loads((root/'linked-memory.json').read_text())
result['software_validation']={'host_ctest_suites':25,'asan_ubsan_suites':25,'host_numeric_cases':34,'host_numeric_replays':2210,
 'python_performance_tests':10,'python_numeric_runtime_tests':18,'python_composition_tests':19,'client_transport_tests':4,
 'cross_builds':['Pico W all services + RAM/software stack checks','C3 USB default profile','ESP32-S3 standard','ESP32-C6 standard'],
 'usb_disconnect_unit_test':'transient gaps, traffic recovery, sustained loss, reconnect'}
result['failures_retained']=['baseline screen stopped responding and was terminated; incomplete, excluded from estimates',
 'fifth tuned block lost upload state before sampling; successful repeat recorded separately',
 'pre-fix numeric matrix timed out during uploads',
 'traced pre-fix matrix lost staged configuration after 13 successful pairs without reboot; followed by USB disconnect confirmation fix']
if (root/'final-device.json').exists():result['final_device']=json.loads((root/'final-device.json').read_text())
result['validation_status']=json.loads((root/'validation-status.json').read_text()) if (root/'validation-status.json').exists() else []
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
for r in result['comparisons']:
 print(r['case'],r['layer'],round(r['standard_updates_hz'],2),round(r['final_updates_hz'],2),round(r['gain_percent'],1) if r['gain_percent'] is not None else None)
