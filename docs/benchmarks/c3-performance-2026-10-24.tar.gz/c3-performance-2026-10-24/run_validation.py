"""Physical checks after the selected image is installed by run_campaign.py."""
import json,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent;repo=root.parent.parent;py=sys.executable
fw=root/'firmwares/final/lightvm.bin';port='/dev/cu.usbmodem1101';jobs=[]
def call(label,args):
 print('Starting '+label,flush=True);started=time.time()
 with (root/(label+'.log')).open('w') as log:r=subprocess.run([py,*args],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 jobs.append({'label':label,'exit_code':r.returncode,'start_unix':started,'end_unix':time.time()});(root/'validation-status.json').write_text(json.dumps(jobs,indent=2)+'\n')
 if r.returncode:raise RuntimeError(label+' failed')
 print('Completed '+label,flush=True)
call('hardware-smoke',['tools/smoke_controller.py','--port',port,'--board','xiao_esp32c3','--reference','build/host/lightvm'])
call('hardware-storage',['tools/check_storage_hardware.py','--port',port,'--board','xiao_esp32c3','--firmware',str(fw),'--result',str(root/'hardware-storage.json'),'--cycles','32'])
call('hardware-runtime',['tools/check_numeric_runtime_hardware.py','--port',port,'--no-reset','--pin','D1','--firmware',str(fw),'--result',str(root/'hardware-runtime.json')])
common=['tools/benchmark_numeric.py','--port',port,'--no-reset','--pin','D1','--packages',str(root/'pico-evidence/matrix'),'--firmware',str(fw),'--network-regime','Services compiled; unprovisioned network; USB STATUS at 20 Hz']
manifest=json.loads((root/'pico-evidence/matrix/manifest.json').read_text())
cases=sorted({n.rsplit('-',1)[0] for n in manifest}-{'control-rainbow','control-stars'})
call('hardware-matrix',[*common,'--label','final-matrix','--result',str(root/'hardware-matrix.json'),'--correctness','--pixels','33','200','1024',*[a for c in cases for a in ('--case',c)]])
cases=['G1-l64-o-19','G2-l17','Q1-p32768','B1-lazy-piecewise','M1-all-pairs','M2-all-pairs']
call('hardware-throughput',[*common,'--label','final-throughput','--result',str(root/'hardware-throughput.json'),'--pixels','200','500','1024','--samples','3','--seconds','3','--warmup','1',*[a for c in cases for a in ('--case',c)]])
call('hardware-soak',['tools/benchmark_animation_profile.py','--port',port,'--board','xiao_esp32c3','--packages',str(root/'pico-evidence/campaign-packages'),'--firmware',str(fw),'--label','final-soak','--result',str(root/'hardware-soak.json'),'--network-regime','Services compiled; unprovisioned network; USB STATUS at 20 Hz','--case','saved-stars','--case','mixed','--samples','1','--seconds','120'])
call('final-device',[str(root/'verify_final_device.py')])
