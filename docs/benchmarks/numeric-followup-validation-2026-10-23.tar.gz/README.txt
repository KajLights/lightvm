Apply sources/ over base revision 129ebbf56c52f97f2f4fdc2e3d4e61d049d627a9. Changed/new files are complete copies; no files are deleted.
The summary and matrix are software evidence; hardware acceptance is explicitly open.
Firmware identities are recorded, not deployment approval.
