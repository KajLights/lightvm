Earlier ESP32 screening firmware, including rejected experiments. Raw run results and final report are in esp32-optimisation-2026-10-24.tar.gz. These are not the final matched cohort.
