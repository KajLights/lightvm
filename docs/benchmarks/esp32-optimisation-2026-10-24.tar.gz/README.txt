Frozen ESP32 optimisation evidence, 24 October 2026. See REPORT.md and PROTOCOL.md.
Firmware source: e3c3dd36355a36cd9619e630ac958f83f5233904; source-changes.patch applies on main15096bc.
Original screening attempts and observers are retained separately from final paired measurements.
Orchestration records local paths and /tmp helper imports; update roots, environment and ports for another rig.
Do not run two clients against the same serial port. Use native BoardMonitor throughout tests.
No full-flash backup or provisioned credentials are included.
Manifest hashes cover the uncompressed bytes of every file except the manifest itself.
