from importlib.machinery import SourceFileLoader
c=SourceFileLoader('campaign','/tmp/lightvm-esp-screen.py').load_module()
c.command([c.py,str(c.root/'tools/benchmark_esp32_endurance.py'),'--port',c.boards['c6'],'--board','xiao_esp32c6','--firmware',str(c.run/'c6-auto/lightvm.bin'),'--packages',str(c.run/'packages'),'--result',str(c.run/'c6-endurance.json'),'--seconds','3600','--temperature-log',str(c.run/'c6-endurance-temperature.jsonl')],'c6-endurance.log')
print('C6 corrected endurance complete',flush=True)
c.command([c.py,'/tmp/lightvm-esp-postflight.py','c6'],'c6-postflight-retry.log')
print('C6 postflight retry complete',flush=True)
