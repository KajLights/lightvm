import json,os,shutil,subprocess,time
from pathlib import Path
root=Path('/Users/kws/.codex/worktrees/c314/lightvm');run=root/'build/esp32-campaign'
cmake='/Users/kws/work/kajlights/lightvm/build/pico-async-output/tooling/cmake/data/bin/cmake'
ctest=str(Path(cmake).with_name('ctest'))
while True:
 ready=True
 for chip in ('c3','c6','s3'):
  f=run/(chip+'-return-standard.json')
  try:d=json.loads(f.read_text());ready &= bool(d.get('measurement_complete') and d.get('temporary_cleanup_complete'))
  except (FileNotFoundError,json.JSONDecodeError):ready=False
 if ready:break
 time.sleep(10)
print('Primary and return-baseline measurements complete; starting host/Pico checks.',flush=True)
results={}
def command(label,args,env=None):
 with (run/(label+'.log')).open('w') as f:r=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 results[label]=r.returncode
 print(label+': '+str(r.returncode),flush=True)
 (run/'crosschecks.json').write_text(json.dumps(results,indent=2)+'\n')
 return r.returncode==0
if command('host-sanitize-final-build',[cmake,'--build',str(run/'host-sanitize'),'-j','2']):
 command('host-sanitize-final-test',[ctest,'--test-dir',str(run/'host-sanitize'),'--output-on-failure'])
env=os.environ.copy();env['PYTHONPATH']='.:tools:tests';env['LIGHTVM_RECEIVER']=str(run/'host/lightvm')
command('focused-final-tests',['/Users/kws/work/kajlights/lightvm/build/venv/bin/python','-m','unittest','test_inputs','test_board_monitor','test_optimisation_protocol','test_animation_profile'],env)
shutil.copy2(root/'build/pico-verify/CMakeCache.txt',run/'pico-maximum-services-CMakeCache.txt')
if command('pico-supported-configure',[cmake,'-S',str(root),'-B',str(root/'build/pico-verify'),'-DLIGHTVM_WEBSOCKET=OFF','-DLIGHTVM_MQTT=OFF']):
 if command('pico-supported-build',[cmake,'--build',str(root/'build/pico-verify'),'-j','2']):
  for f in ('CMakeCache.txt','lightvm.uf2','platforms/pico/stack-paths.json'):
   p=root/'build/pico-verify'/f
   if p.exists():shutil.copy2(p,run/('pico-supported-'+p.name))
print('Cross-platform checks finished.',flush=True)
