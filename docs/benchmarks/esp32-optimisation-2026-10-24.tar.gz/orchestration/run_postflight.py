import concurrent.futures,hashlib,json,sys,time,subprocess
from importlib.machinery import SourceFileLoader
c=SourceFileLoader('campaign','/tmp/lightvm-esp-screen.py').load_module()
sys.path.insert(0,str(c.root/'tools'));sys.path.insert(0,str(c.root))
from client import Client,SerialTransport,STOP,FRAME
from board_monitor import BoardMonitor
from lightvm.compiler import compile_source

def connect(chip,label):
 client=Client(SerialTransport(c.boards[chip],no_reset=True),timeout=10)
 BoardMonitor(client,c.run/(label+'-temperature.jsonl'))
 return client

def postflight(chip):
 try:
  deadline=time.monotonic()+3*3600
  while True:
   p=c.run/(chip+'-endurance.json')
   if p.exists():
    try:d=json.loads(p.read_text())
    except json.JSONDecodeError:d={}
    if '--after-user-stop' in sys.argv and (c.run/'endurance-disposition.json').exists() and d.get('cleanup_complete'):break
    if d.get('passed') is False:raise RuntimeError('endurance failed; inspect before further hardware work')
    if d.get('passed') and d.get('cleanup_complete') and d.get('measured_seconds',0)>=3600:break
   if time.monotonic()>deadline:raise RuntimeError('endurance not completed within postflight deadline')
   time.sleep(5)
  time.sleep(1)
  image=c.run/(chip+'-auto')/'lightvm.bin';pin='D1' if chip=='c3' else 'D0';second='D2' if chip=='c3' else 'D1'
  try:
   c.command([c.py,str(c.root/'tools/check_esp32_scheduling.py'),'--port',c.boards[chip],'--board','xiao_esp32'+chip,'--pin',pin,'--second-pin',second,'--firmware',str(image),'--packages',str(c.run/'packages'),'--result',str(c.run/(chip+'-scheduling.json')),'--temperature-log',str(c.run/(chip+'-scheduling-temperature.jsonl'))],chip+'-scheduling.log')
  except RuntimeError:
   d=json.loads((c.run/(chip+'-scheduling.json')).read_text())
   if not d.get('cleanup_complete') or 'Board monitor' in d.get('error',''):raise
   print(chip+' scheduling gate failed; collecting remaining independent checks',flush=True)
  c.flash(chip,'usb-only',chip+'-usb-only-installed')
  # This lane has a distinct network regime and is never pooled with full services.
  label=chip+'-usb-only-screen'
  cmd=[c.py,str(c.root/'tools/benchmark_animation_profile.py'),'--port',c.boards[chip],'--board','xiao_esp32'+chip,'--rig','esp32-'+chip+'-usb-20261024','--packages',str(c.run/'packages'),'--firmware',str(c.run/(chip+'-usb-only')/'lightvm.bin'),'--label',label,'--result',str(c.run/(label+'.json')),'--network-regime','usb-only-firmware','--ingress-instrumented','--samples','1','--seconds','12','--warmup','2','--temperature-log',str(c.run/(label+'-temperature.jsonl'))]
  for case in c.cases:cmd+=['--case',case]
  c.command(cmd,label+'.log')
  source='from lightvm import profile,render,rgb\nprofile("animation")\n@render\ndef draw(ctx,runtime,pixels):\n pixels.fill(rgb(17,51,93))\n'
  artifact=compile_source(source)
  if not artifact.success:raise RuntimeError(artifact.diagnostics)
  cli=connect(chip,chip+'-persistence');before=cli.describe();cli.save_program('persist_probe',artifact.bytecode);cli.close()
  c.command([c.idfpy,'-m','esptool','--chip','esp32'+chip,'--port',c.boards[chip],'flash_id'],chip+'-persistence-reset.log')
  time.sleep(2);cli=connect(chip,chip+'-persistence');after=cli.describe()
  if after['boot_id']==before['boot_id']:raise RuntimeError('persistence check did not reboot')
  if cli.get_program('persist_probe')!=artifact.bytecode:raise RuntimeError('program readback differs after reboot')
  cli.configure({'schema':'lightvm.config','outputs':[{'id':'persist','type':'ws2812b','config':{'pin':pin,'count':25,'brightness_limit':32}}]})
  cli.activate('persist_probe',output='persist');cli.require_ok(cli.command(STOP,output='persist'));cli.require_ok(cli.command(FRAME,bytes(4),output='persist'))
  if bytes(cli.pixel_snapshot)!=bytes([17,51,93])*25:raise RuntimeError('stored mapped execution differs after reboot')
  cli.configure({'schema':'lightvm.config','outputs':[]});cli.delete_program('persist_probe');cli.close()
  (c.run/(chip+'-persistence.json')).write_text(json.dumps({'passed':True,'source':source,'package_sha256':hashlib.sha256(artifact.bytecode).hexdigest(),'before':before,'after':after},indent=2)+'\n')
  c.flash(chip,'auto',chip+'-clean-final',erase=True)
  directory=c.run/(chip+'-auto');args=json.loads((directory/'flasher_args.json').read_text());files=[]
  for offset,file in args['flash_files'].items():files += [offset,str(directory/file)]
  c.command([c.idfpy,'-m','esptool','--chip','esp32'+chip,'--port',c.boards[chip],'--baud','460800','verify_flash']+files,chip+'-clean-final-verify.log')
  time.sleep(2);cli=connect(chip,chip+'-clean-final');description=cli.describe();active=cli.get_config();saved=cli.get_config(saved=True);programs=cli.programs();presets=cli.presets();cli.manage('input_list');sensors=json.loads(cli.data_reply)
  if active.get('outputs') or saved.get('outputs') or programs or presets or description['network_revision']!=0:raise RuntimeError('final board was not clean')
  if description['boot_error'] or description['animation_error']:raise RuntimeError('final firmware reported an error')
  cli.close()
  (c.run/(chip+'-installed.json')).write_text(json.dumps({'passed':True,'firmware_sha256':hashlib.sha256(image.read_bytes()).hexdigest(),'description':description,'active_config':active,'saved_config':saved,'programs':programs,'presets':presets,'sensors':sensors,'flash_verified':True},indent=2)+'\n')
  print(chip+' postflight complete, final image verified and clean',flush=True)
 except Exception as error:
  (c.run/(chip+'-postflight-error.json')).write_text(json.dumps({'error':str(error)})+'\n')
  print(chip+' POSTFLIGHT FAILED: '+str(error),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(postflight,[a for a in sys.argv[1:] if not a.startswith('--')] or c.boards))
