import sys,concurrent.futures
sys.path.insert(0,'/tmp')
from importlib.machinery import SourceFileLoader
c=SourceFileLoader('campaign','/tmp/lightvm-esp-screen.py').load_module()
def validate(chip):
 try:
  image=c.run/(chip+'-auto')/'lightvm.bin';port=c.boards[chip];pin='D1' if chip=='c3' else 'D0';prefix=chip+'-selected'
  def run(tool,extra):
   label=prefix+'-'+tool.replace('.py','')
   cmd=[c.py,str(c.root/'tools'/tool),'--port',port,'--temperature-log',str(c.run/(label+'-temperature.jsonl'))]+extra
   c.command(cmd,label+'.log');print(label+' passed',flush=True)
  run('smoke_controller.py',['--board','xiao_esp32'+chip,'--no-reset','--reference',str(c.run/'host/lightvm')])
  run('check_storage_hardware.py',['--board','xiao_esp32'+chip,'--firmware',str(image),'--cycles','32','--result',str(c.run/(prefix+'-storage.json'))])
  run('check_numeric_runtime_hardware.py',['--pin',pin,'--no-reset','--firmware',str(image),'--result',str(c.run/(prefix+'-faults.json'))])
  run('benchmark_usb_hardware.py',['--no-reset','--firmware',str(image),'--label',prefix,'--samples','10','--result',str(c.run/(prefix+'-usb.json'))])
  run('benchmark_numeric.py',['--pin',pin,'--no-reset','--firmware',str(image),'--packages',str(c.run/'numeric'),'--label',prefix,'--correctness','--pixels','33','200','1024','--result',str(c.run/(prefix+'-numeric-correctness.json'))])
 except Exception as e:
  print(chip,str(e),flush=True)
  raise
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(validate,sys.argv[1:] or c.boards))
