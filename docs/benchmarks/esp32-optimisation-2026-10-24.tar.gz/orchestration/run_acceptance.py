import concurrent.futures,json,sys,time
from importlib.machinery import SourceFileLoader
c=SourceFileLoader('campaign','/tmp/lightvm-esp-screen.py').load_module()
v=SourceFileLoader('validate','/tmp/lightvm-esp-validate.py').load_module()
def acceptance(chip):
 try:
  for pair in range(1,6):
   order=['standard','auto'] if pair%2 else ['auto','standard']
   for profile in order:
    label=f'{chip}-accept-{pair}-{profile}'
    c.flash(chip,profile,label,erase=pair==1 and profile==order[0])
    c.measure(chip,profile,label,seconds=12,reverse=pair%2==0)
  try:c.command([c.py,str(c.root/'tools/compare_optimisation.py'),'--baseline']+[str(c.run/f'{chip}-accept-{i}-standard.json') for i in range(1,6)]+['--candidate']+[str(c.run/f'{chip}-accept-{i}-auto.json') for i in range(1,6)]+['--output',str(c.run/(chip+'-comparison.json'))],chip+'-comparison.log')
  except RuntimeError:print(chip+' comparison has open gates; retaining evidence and continuing validation',flush=True)
  c.flash(chip,'standard',chip+'-return-standard')
  c.measure(chip,'standard',chip+'-return-standard',seconds=12)
  c.flash(chip,'auto',chip+'-installed')
  v.validate(chip)
  image=c.run/(chip+'-auto')/'lightvm.bin'
  c.command([c.py,str(c.root/'tools/benchmark_esp32_endurance.py'),'--port',c.boards[chip],'--board','xiao_esp32'+chip,'--firmware',str(image),'--packages',str(c.run/'packages'),'--result',str(c.run/(chip+'-endurance.json')),'--seconds','3600','--temperature-log',str(c.run/(chip+'-endurance-temperature.jsonl'))],chip+'-endurance.log')
  print(chip+' endurance complete',flush=True)
 except Exception as e:print(chip,str(e),flush=True)
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(acceptance,sys.argv[1:] or c.boards))
