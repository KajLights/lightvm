import concurrent.futures,hashlib,json,os,subprocess,time,sys
from pathlib import Path
root=Path('/Users/kws/.codex/worktrees/c314/lightvm');run=root/'build/esp32-campaign'
py='/Users/kws/work/kajlights/lightvm/build/venv/bin/python'
env=os.environ.copy();env.update(json.loads((run/'build-environment.json').read_text()));env['IDF_COMPONENT_MANAGER']='0'
idfpy=env['IDF_PYTHON_ENV_PATH']+'/bin/python'
boards={'c3':'/dev/cu.usbmodem1101','c6':'/dev/cu.usbmodem1201','s3':'/dev/cu.usbmodem4'}
cases=['map','scalar','draw','sprites','control-color','control-rainbow','control-sweep','mixed','stable-stars','stars-background']
def command(cmd,log,cwd=root):
 with (run/log).open('w') as f:
  r=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError(f'{log} failed ({r.returncode})')
def flash(chip,profile,label,erase=False):
 directory=run/(chip+'-'+profile);port=boards[chip]
 base=[idfpy,'-m','esptool','--chip','esp32'+chip,'--port',port,'--baud','460800']
 if erase:command(base+['erase_flash'],label+'-erase.log')
 args=json.loads((directory/'flasher_args.json').read_text());files=[]
 for offset,file in args['flash_files'].items():files.extend([offset,str(directory/file)])
 command(base+['write_flash']+args['write_flash_args']+files,label+'-flash.log',directory)
 time.sleep(2)
 print(label+' installed',flush=True)
def measure(chip,profile,label,seconds=3,reverse=False,samples=1):
 image=run/(chip+'-'+profile)/'lightvm.bin'
 cmd=[py,str(root/'tools/benchmark_animation_profile.py'),'--port',boards[chip],'--board','xiao_esp32'+chip,'--rig','esp32-'+chip+'-usb-20261024','--packages',str(run/'packages'),'--firmware',str(image),'--label',label,'--result',str(run/(label+'.json')),'--network-regime','full-services-unprovisioned-ap','--ingress-instrumented','--samples',str(samples),'--seconds',str(seconds),'--warmup','2','--temperature-log',str(run/(label+'-temperature.jsonl'))]
 for case in cases:cmd+=['--case',case]
 if reverse:cmd+=['--reverse-cases']
 command(cmd,label+'.log')
 print(label+' measured',flush=True)
def screen(chip):
 try:
  flash(chip,'standard',chip+'-screen-standard',erase=True)
  measure(chip,'standard',chip+'-screen-standard')
  # The candidate builds are created concurrently with this screen.
  target=run/(chip+'-auto')/'lightvm.bin';limit=time.monotonic()+900
  while not target.exists():
   if time.monotonic()>limit:raise RuntimeError('candidate build not ready')
   time.sleep(1)
  flash(chip,'auto',chip+'-screen-auto')
  measure(chip,'auto',chip+'-screen-auto',reverse=True)
 except Exception as e:print(chip,str(e),flush=True)
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(screen,boards))
