import json,statistics
from pathlib import Path
root=Path('/Users/kws/.codex/worktrees/c314/lightvm');run=root/'build/esp32-campaign'
def read(name):
 p=run/name
 return json.loads(p.read_text()) if p.exists() else None
summary={'context':read('context.json'),'boards':{}}
for chip in ('c3','c6','s3'):
 result={'comparison':read(chip+'-comparison.json'),'return_baseline':{},'resources':{},'temperature':{}}
 for profile in ('standard','auto'):
  docs=[read(f'{chip}-accept-{i}-{profile}.json') for i in range(1,6)]
  result['resources'][profile]={'main_stack_peak_bytes':max([s['description_after']['main_stack_peak_bytes'] for d in docs if d for s in d['samples']],default=0),'linked_layout':read(chip+'-'+profile+'-size.json')}
  values=[];queries=[]
  for i in range(1,6):
   p=run/f'{chip}-accept-{i}-{profile}-temperature.jsonl'
   if p.exists():
    for line in p.read_text().splitlines():
     d=json.loads(line)
     for s in d.get('sensors',[]):
      if s['name']=='board.temperature_c' and s.get('valid'):values.append(s['value'])
     if 'query_ms' in d:queries.append(d['query_ms'])
  result['temperature'][profile]={'readings':len(values),'min_c':min(values) if values else None,'max_c':max(values) if values else None,'median_query_ms':statistics.median(queries) if queries else None}
 comparison=result['comparison'];ret=read(chip+'-return-standard.json')
 if ret and comparison:
  for row in ret['samples']:
   layers={}
   for key,value in row['layers'].items():
    base=comparison['cases'][row['case']]['layers'][key]
    med=base['baseline_updates_hz']['median'];oldcost=base.get('baseline_render_us',{}).get('median')
    layers[key]={'updates_change_percent':100*(value['updates_per_second']/med-1) if med else None,'render_change_percent':100*(value['mean_render_us']/oldcost-1) if oldcost and value['mean_render_us'] else None}
   result['return_baseline'][row['case']]=layers
 for field,suffix in [('storage','selected-storage'),('numeric_faults','selected-faults'),('usb_boundaries','selected-usb'),('numeric_correctness','selected-numeric-correctness'),('endurance','endurance'),('scheduling','scheduling'),('persistence','persistence'),('installed','installed')]:
  d=read(chip+'-'+suffix+'.json')
  if d:
   if field=='endurance':
    d={k:v for k,v in d.items() if k not in ('blocks','packages')};d['completed_blocks']=len(read(chip+'-endurance.json').get('blocks',[]))
   elif field=='numeric_correctness':d={k:v for k,v in d.items() if k not in ('packages','results','samples')}
   result[field]=d
 summary['boards'][chip]=result
(run/'summary-in-progress.json').write_text(json.dumps(summary,indent=2)+'\n')
for chip,result in summary['boards'].items():
 d=result['comparison']
 if not d:continue
 print(chip,d['verdict'])
 for case,row in d['cases'].items():
  print(case,[(k,round(v['baseline_updates_hz']['median'],2),round(v['candidate_updates_hz']['median'],2),round(v.get('updates_change_percent',0),1),round(v.get('render_change_percent',0),1)) for k,v in row['layers'].items()])
 print('temperature',result['temperature']);print('return drift',result['return_baseline'])
