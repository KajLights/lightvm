import argparse,hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path('/Users/kws/.codex/worktrees/c314/lightvm');run=root/'build/esp32-campaign'
parser=argparse.ArgumentParser();parser.add_argument('--create',action='store_true');args=parser.parse_args()
files={}
def add(path,name):
 if path.is_file():files[name]=path
for p in run.iterdir():
 if p.is_file() and p.suffix in ('.json','.jsonl','.log') and p.name!='summary-in-progress.json':add(p,'runs/'+p.name)
for directory in ('frozen-selected','frozen-screen','packages','numeric'):
 for p in (run/directory).rglob('*'):
  if p.is_file():add(p,str(p.relative_to(run)))
for chip in ('c3','c6','s3'):
 for name in ('lightvm.bin','lightvm.elf','lightvm.map','sdkconfig','CMakeCache.txt','flasher_args.json','bootloader/bootloader.bin','partition_table/partition-table.bin'):
  add(run/(chip+'-usb-only')/name,'frozen-usb-only/'+chip+'/'+name)
for p in (root/'tools').glob('*.py'):add(p,'tools/'+p.name)
for p in (root/'tests').glob('test_*'):
 if p.name in ('test_board_monitor.py','test_optimisation_protocol.py','test_esp32_usb_connection.c','test_inputs.py','test_animation_profile.py'):add(p,'tests/'+p.name)
for name,source in {'run_screen.py':'/tmp/lightvm-esp-screen.py','run_acceptance.py':'/tmp/lightvm-esp-acceptance.py','run_validation.py':'/tmp/lightvm-esp-validate.py','run_postflight.py':'/tmp/lightvm-esp-postflight.py','run_crosschecks.py':'/tmp/lightvm-esp-crosschecks.py','summarize.py':'/tmp/lightvm-esp-summary.py','package_evidence.py':'/tmp/lightvm-esp-archive.py'}.items():add(Path(source),'orchestration/'+name)
add(root/'docs/design/esp32-optimisation-2026-10-24.md','REPORT.md')
add(root/'tools/pico-stack-contracts.json','tools/pico-stack-contracts.json')
add(Path('/tmp/lightvm-esp-c6-retry.py'),'orchestration/run_c6_retry.py')
add(Path('/tmp/lightvm-pico-clean-check.py'),'orchestration/run_pico_clean.py')
add(run/'pico-clean-CMakeCache.txt','pico/CMakeCache.txt')
add(run/'pico-clean-lightvm.uf2','pico/lightvm.uf2')
add(run/'pico-clean-stack-paths.json','pico/stack-paths.json')
add(root/'docs/optimisation-protocol.md','PROTOCOL.md')
print('Files',len(files),'uncompressed MiB',round(sum(p.stat().st_size for p in files.values())/1048576,1),flush=True)
if not args.create:raise SystemExit()
for chip in ('c3','c6','s3'):
 d=json.loads((run/(chip+'-installed.json')).read_text())
 if not d.get('passed'):raise RuntimeError(chip+' final install not verified')
extra={'source-changes.patch':subprocess.check_output(['git','diff','15096bc','e3c3dd3'],cwd=root),
       'README.txt':b'''Frozen ESP32 optimisation evidence, 24 October 2026. See REPORT.md and PROTOCOL.md.\nFirmware source: e3c3dd36355a36cd9619e630ac958f83f5233904; source-changes.patch applies on main15096bc.\nOriginal screening attempts and observers are retained separately from final paired measurements.\nOrchestration records local paths and /tmp helper imports; update roots, environment and ports for another rig.\nDo not run two clients against the same serial port. Use native BoardMonitor throughout tests.\nNo full-flash backup or provisioned credentials are included.\nManifest hashes cover the uncompressed bytes of every file except the manifest itself.\n'''}
groups={'esp32-optimisation-2026-10-24':{n:p for n,p in files.items() if not n.startswith('frozen-screen/')},'esp32-optimisation-screens-2026-10-24':{n:p for n,p in files.items() if n.startswith('frozen-screen/')}}
records=[]
for stem,members in groups.items():
 manifest={name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for name,p in members.items()}
 additions=dict(extra) if 'screens' not in stem else {'README.txt':b'Earlier ESP32 screening firmware, including rejected experiments. Raw run results and final report are in esp32-optimisation-2026-10-24.tar.gz. These are not the final matched cohort.\n'}
 manifest.update({name:{'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for name,data in additions.items()})
 additions['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
 output=root/'docs/benchmarks'/(stem+'.tar.gz')
 with tarfile.open(output,'w:gz',compresslevel=6) as tf:
  for name,p in sorted(members.items()):tf.add(p,arcname=name,recursive=False)
  for name,data in additions.items():
   info=tarfile.TarInfo(name);info.size=len(data);tf.addfile(info,io.BytesIO(data))
 verified=set()
 with tarfile.open(output,'r|gz') as tf:
  for member in tf:
   if member.name=='MANIFEST.json':continue
   data=tf.extractfile(member).read();expected=manifest[member.name]
   if len(data)!=expected['bytes'] or hashlib.sha256(data).hexdigest()!=expected['sha256']:raise RuntimeError('archive verification failed: '+member.name)
   verified.add(member.name)
 if verified!=set(manifest):raise RuntimeError('archive member set differs')
 record={'archive':output.name,'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'verified_members':len(manifest)}
 if record['bytes']>=100*1024*1024:raise RuntimeError('archive exceeds100MiB')
 records.append(record);print(json.dumps(record),flush=True)
(root/'docs/benchmarks/esp32-optimisation-2026-10-24-archives.json').write_text(json.dumps(records,indent=2)+'\n')
