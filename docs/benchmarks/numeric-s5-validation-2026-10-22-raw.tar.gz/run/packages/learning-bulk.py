from lightvm import profile, setting, Input, Ramp, rgb, hsv, hash01, init, render, PixelArray, Sprite, SpriteBatch, Transform, ColorTransform, red, green, blue, colorwheel, pico_colorwheel, hue_degrees, floor, ceil, trunc, fixed, fixed_bits, fixed_from_bits, fixed_sqrt, FixedArray
from lightvm.motion import repeat, pingpong, clamp01, lerp, fit_start, fit_end
from lightvm.easing import linear, smoothstep, quadratic_in, quadratic_out, quadratic_in_out, cubic_in, cubic_out, cubic_in_out
from lightvm.transitions import crossfade, wipe
from array import array
import math
import random
profile("animation")

def _js_remainder(a, b):
    zero = a - a
    if a == zero or ((a < zero) == (b < zero)):
        remainder = a % b
        return a * zero if remainder == zero else remainder
    opposite = -a
    if opposite < zero and a < zero:
        remainder = a % b
        return remainder - b if remainder != zero else remainder
    return (a * zero) - (opposite % b)

@init
def _js_fn2(_js_v4, _js_v5):
    _js_v4.table = FixedArray(_js_v5.pixel_count, fill=(fixed(0.75) + fixed(0.75)))
    _js_v4.factor = (fixed(1.5) + fixed(1.5))
@render
def _js_fn3(_js_v6, _js_v7, _js_v8):
    for _js_v9 in range(int(float(_js_v8.count))):
        _js_v10 = _js_v6.table[int(_js_v9)]
        _js_v11 = 0
        if (_js_v9 < 16):
            _js_v11 = int((_js_v10 * _js_v6.factor))
        else:
            _js_v11 = int(fixed_sqrt(_js_v10))
        _js_v8[int(_js_v9)] = rgb((_js_v11 & 31), int(math.sqrt(4.0)), 7)
