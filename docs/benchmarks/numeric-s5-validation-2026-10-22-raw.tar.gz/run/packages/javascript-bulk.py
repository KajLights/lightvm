from lightvm import profile, setting, Input, Ramp, rgb, hsv, hash01, init, render, PixelArray, Sprite, SpriteBatch, Transform, ColorTransform, red, green, blue, colorwheel, pico_colorwheel, hue_degrees, floor, ceil, trunc, fixed, fixed_bits, fixed_from_bits, fixed_sqrt, FixedArray
from lightvm.motion import repeat, pingpong, clamp01, lerp, fit_start, fit_end
from lightvm.easing import linear, smoothstep, quadratic_in, quadratic_out, quadratic_in_out, cubic_in, cubic_out, cubic_in_out
from lightvm.transitions import crossfade, wipe
from array import array
import math
import random
profile("animation")

def _js_remainder(a, b):
    zero = a - a
    if a == zero or ((a < zero) == (b < zero)):
        remainder = a % b
        return a * zero if remainder == zero else remainder
    opposite = -a
    if opposite < zero and a < zero:
        remainder = a % b
        return remainder - b if remainder != zero else remainder
    return (a * zero) - (opposite % b)

@init
def _js_fn1(_js_v3, _js_v4):
    _js_v3.table = FixedArray(_js_v4.pixel_count, fill=(fixed(0.75) + fixed(0.75)))
    _js_v3.factor = (fixed(1.5) + fixed(1.5))
@render
def _js_fn2(_js_v5, _js_v6, _js_v7):
    for _js_v8 in range(_js_v7.count):
        _js_v9 = _js_v5.table[int(_js_v8)]
        _js_v10 = 0
        if (_js_v8 < 16):
            _js_v10 = int((_js_v9 * _js_v5.factor))
        else:
            _js_v10 = int(fixed_sqrt(_js_v9))
        _js_v7[int(_js_v8)] = rgb((_js_v10 & 31), int(math.sqrt(4.0)), 7)
