from lightvm import profile, setting, Input, Ramp, rgb, hsv, hash01, init, render, PixelArray, Sprite, SpriteBatch, Transform, ColorTransform, red, green, blue, colorwheel, pico_colorwheel, hue_degrees, floor, ceil, trunc, fixed, fixed_bits, fixed_from_bits, fixed_sqrt, FixedArray
from lightvm.motion import repeat, pingpong, clamp01, lerp, fit_start, fit_end
from lightvm.easing import linear, smoothstep, quadratic_in, quadratic_out, quadratic_in_out, cubic_in, cubic_out, cubic_in_out
from lightvm.transitions import crossfade, wipe
from array import array
import math
import random
profile("animation")
@init
def init_program(state, runtime):
    state.table = FixedArray(runtime.pixel_count, fill=(fixed(0.75) + fixed(0.75)))
    state.factor = (fixed(1.5) + fixed(1.5))
@render
def render_program(state, runtime, pixels):
    for v_i in range(int(pixels.count)):
        v_q = state.table[int(v_i)]
        v_v = 0
        if (v_i < 16):
            v_v = int((v_q * state.factor))
        else:
            v_v = int(fixed_sqrt(v_q))
        pixels[int(v_i)] = rgb((v_v & 31), int(math.sqrt(4.0)), 7)
