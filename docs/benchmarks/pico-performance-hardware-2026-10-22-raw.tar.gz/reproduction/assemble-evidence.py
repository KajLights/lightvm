import sys,json,hashlib,statistics,datetime,gzip,tarfile,io
from pathlib import Path
root=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(root/'tools'))
from summarize_pico_campaign import summarize,compare
from benchmark_saved_preset import percentile
p=Path(__file__).resolve().parent
out=root/'docs/benchmarks/pico-performance-hardware-2026-10-22.json'
def load(name):return json.loads((p/(name+'.json')).read_text())
def distribution(values):
 return {'count':len(values),'median':statistics.median(values),'p95':percentile(values,.95),'p99':percentile(values,.99),'min':min(values),'max':max(values)} if values else None
def comparison(a,b):
 x=summarize([p/(a+'.json')]);y=summarize([p/(b+'.json')])
 return {'baseline':x,'candidate':y,'changes':compare(x,y)}
result={'date':'2026-10-22','status':'in progress','scope':'One RP2040 B2 Pico W, one 200-pixel WS2812 output on GP16; logical 500/1024-pixel tests use the same physical output. No electrical or optical probe.',
 'baseline':{'source_association':'59b7c52','artifact':'baseline-firmware.bin','format':'raw flash code and padding, 0x10000000..0x100fe000; excludes journal/storage','sha256':hashlib.sha256((p/'baseline-firmware.bin').read_bytes()).hexdigest()},
 'candidate':load('candidate-final/identity'),
 'rom':load('rom-identity'),'rom_stack_audit':load('rom-stack-paths'),
 'bootstrap_method':'5000 independent trial resamples of median ratios, seed 20261022; five-trial intervals are descriptive and do not include systematic clock/boundary/observer uncertainty.',
 'comparisons':{},'preparation':{},'dirty_input':{},'ha':{},'replays':{},'resources':{},
 'limitations':['Unmodified baseline has no displayed-age/dependency stamps or main-stack watermark.','Legacy A-only presentation fields incorrectly read an unused transition counter and are excluded; layer throughput, CPU and latency remain valid.','20 Hz USB observer cost is distinct from internal instrumentation overhead; no telemetry-disabled firmware was built.','Package bytes are identical but flash extent addresses are not pinned across firmware blocks; code/data cache and scheduler costs are not causally isolated.','No one/two-worker factorial or 500/1000us slice sweep in this campaign.','Continuous-operation endurance uses one physical output; Pico 2 W, APA102/electrical probe and multiple physical outputs require separate hardware.','Rendered layer completions and distinct driver-completed contributions are software counters, not optical measurements.','Cumulative foreground-gap maxima include setup/flash; they cannot prove a steady-state 10ms ingress bound.']}
for key,a,b in [('primary','baseline-matched','candidate-final-matched'),('saved_stars','baseline-saved-stars','candidate-final-saved-stars'),('original_candidate_saved_stars','baseline-saved-stars','candidate-saved-stars'),('original_candidate_primary','baseline-matched','candidate-matched-first'),('pixels_500','baseline-pixels-500','candidate-final-pixels-500'),('pixels_1024','baseline-pixels-1024','candidate-final-pixels-1024'),('layers_8','baseline-layers8','candidate-final-layers8'),('observer','baseline-no-observer','candidate-final-no-observer')]:
 if (p/(b+'.json')).exists():result['comparisons'][key]=comparison(a,b)
for key in ('calibration-epoch6000','calibration-cache512','candidate-final-source','candidate-final-diagnostics'):
 if (p/(key+'.json')).exists():result['comparisons'][key]=summarize([p/(key+'.json')])
for label in ('baseline','candidate-final'):
 d=load(label+'-preparation');rows=d['samples']
 result['preparation'][label]={'trials':len(rows),'complete':d.get('complete',False),'acceptance_ms':distribution([r['acceptance_ms'] for r in rows]),'completion_ms':distribution([r['completion_ms'] for r in rows]),'usb_latency_ms':distribution([v for r in rows for v in r['usb_latency_ms']]),'http_latency_ms':distribution([(v['ended']-v['started'])*1000 for r in rows for v in r['http_observations'] if 'ended' in v]),'cancellations':d['cancellations'],'stage_execution_us':[r['operation'].get('stage_us') for r in rows if r['operation']]}
 d=load(label+'-dirty');result['dirty_input'][label]={'events':len(d['events']),'composite_readback_ms':distribution([r['composite_readback_ms'] for r in d['events']]),'completed_output_delay_ms':distribution([r['completed']['dirty_to_display_us']/1000 for r in d['events'] if r['completed'].get('dirty_to_display_us') is not None])}
 d=load('baseline-ha-complete' if label=='baseline' else label+'-ha');result['ha'][label]={k:v for k,v in d.items() if k.endswith('_summary') or k in ('boot_unchanged','error_free','complete','output_retry_observations')}
 observed=d['observed_commands'];control_receipts=[x for x in observed if set(x[1])=={'brightness'}]
 expected=[x['command'] for x in d['scenario']+d['controls']]
 result['ha'][label]['load']={'protocol':'MQTT 3.1.1 QoS0, authenticated, acknowledgement-gated; 30ms pause after each ordinary control','commands_before_restore':len(expected),'observed_sequence_matches': [x[1] for x in observed[:-1]]==expected,'ordinary_payload_bytes':sorted({len(json.dumps(x[1]).encode()) for x in control_receipts}),'ordinary_observed_commands_per_second':(len(control_receipts)-1)/(control_receipts[-1][0]-control_receipts[0][0])}
 for name in [label+'-matched',label+'-ha',label+'-preparation']:
  f=p/(name+'.json')
  if not f.exists():continue
  d=json.loads(f.read_text());descriptions=[r['description_after'] for r in d.get('samples',[]) if 'description_after' in r]+[r['description'] for r in d.get('checks',[])]+[d[k] for k in ('description_before','description_after') if k in d]
  if descriptions:result['resources'][name]={k:max(x.get(k,0) for x in descriptions) for k in ('main_stack_peak_bytes','worker_stack_peak_bytes','render_epoch_max_us','foreground_max_gap_us')}
reference={r['name']:r for r in load('baseline-replays')['replays']}
semantic_fields=('program_us','paused','faulted','contribution_valid','output_valid','contribution_frame','output_frame','render_count','active_wall_us','inputs_revision','inputs','settings_values')
for name in ('baseline-replays','candidate-final-replays-baseline','candidate-final-replays-current'):
 if not (p/(name+'.json')).exists():continue
 d=load(name);result['replays'][name]=[{'name':r['name'],'frames':r['frames'],'sha256_all_frames':r['sha256_all_frames'],'matches_baseline':r['frame_sha256']==reference[r['name']]['frame_sha256'],'observable_state_fields':list(semantic_fields),'observable_state_matches_baseline':all(r['after'].get(k)==reference[r['name']]['after'].get(k) for k in semantic_fields),'measured_render_execution_us':r['after']['render_total_us']-r['before']['render_total_us'],'measured_dispatches':r['after']['dispatch_count']-r['before']['dispatch_count'],'before':r['before'],'after':r['after']} for r in d['replays']]
for name in ('candidate-final-sequence','candidate-final-endurance','restoration','source-comparison','network-observer-summary','configuration-workspace-sizes','continuity','candidate-final-memory-failure','candidate-final-memory-recovery'):
 if (p/(name+'.json')).exists():
  d=load(name)
  result[name]=d if name!='candidate-final-endurance' else {k:v for k,v in d.items() if k.endswith('_summary') or k in ('boot_unchanged','error_free','complete','soak_seconds','output_retry_observations')}
if result.get('candidate-final-sequence',{}).get('complete') and result.get('restoration',{}).get('verified'):result['status']='complete'
result['candidate_accepted']=False
result['acceptance']={'exact_replay_and_observable_state':'pass within recorded scope','fixed_sprite_throughput':'pass','required_dynamic_throughput':'fail','primary_steady_usb_latency':'pass','secondary_two_map_relative_usb_latency':'fail','busy_preparation_usb_latency':'fail under defined heavier observer load','preparation_acceptance':'pass','heavy_preparation_completion':'fail','ordinary_ha_dimming':'pass','ha_recall_activation':'regressed; not accepted','dirty_input_readback':'regressed','replacement_admission':'fail at 1024 pixels/four scalar layers','pico_w_stack_scope':'pass with recorded ROM/IRQ assumptions','continuous_one_output_campaign':'pass','internal_basic_telemetry_overhead':'not isolated','pico2_w_hardware_and_electrical_matrix':'not tested'}
out.write_text(json.dumps(result,indent=2)+'\n')
print(out)
