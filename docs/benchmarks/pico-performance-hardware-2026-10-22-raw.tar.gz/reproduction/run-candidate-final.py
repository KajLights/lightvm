import subprocess,sys,json,time,datetime,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
python=sys.executable
firmware=p/'candidate-final/lightvm.uf2'
common=['--port','/dev/cu.usbmodem11401','--firmware',str(firmware)]
packages=['--packages',str(p/'packages-baseline')]
started=time.monotonic()
record={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'firmware_sha256':hashlib.sha256(firmware.read_bytes()).hexdigest(),'jobs':[]}
if (p/'candidate-final-sequence.json').exists():
 record=json.loads((p/'candidate-final-sequence.json').read_text())
 started=time.monotonic()-(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(record['started_utc'])).total_seconds()
def run(name,tool,args):
 if any(j['name']==name and j['returncode']==0 for j in record['jobs']):
  return json.loads((p/(name+'.json')).read_text())
 command=[python,'tools/'+tool]+common+['--label',name,'--result',str(p/(name+'.json'))]+args
 print('START '+name,flush=True)
 tick=time.monotonic()
 with (p/(name+'.log')).open('w') as f:
  result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 record['jobs'].append({'name':name,'command':command,'elapsed_s':time.monotonic()-tick,'returncode':result.returncode,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 record['elapsed_s']=time.monotonic()-started
 (p/'candidate-final-sequence.json').write_text(json.dumps(record,indent=2)+'\n')
 if result.returncode:raise SystemExit('FAILED '+name)
 print('DONE '+name,flush=True)
 return json.loads((p/(name+'.json')).read_text())
ha=run('candidate-final-ha','benchmark_ha_hardware.py',['--network',str(p/'original-objects/5-$network.json')])
if not ha['error_free']:raise SystemExit('HA retry regression remains')
run('candidate-final-preparation','benchmark_preparation_hardware.py',packages+['--url','http://10.77.10.231'])
run('candidate-final-dirty','benchmark_dirty_hardware.py',packages)
for compiler in ('baseline','current'):
 data=run('candidate-final-replays-'+compiler,'benchmark_pico_campaign.py',['--packages',str(p/('packages-'+compiler)),'--replay'])
 expected={r['name']:r['frame_sha256'] for r in json.loads((p/'baseline-replays.json').read_text())['replays']}
 for r in data['replays']:
  if r['frame_sha256']!=expected[r['name']]:raise SystemExit('PIXEL MISMATCH '+r['name'])
run('candidate-final-matched','benchmark_pico_campaign.py',packages)
for pixels in (500,1024):
 run('candidate-final-pixels-'+str(pixels),'benchmark_pico_campaign.py',packages+['--pixels',str(pixels),'--samples','3','--seconds','20','--case','fixed12','--case','images2','--case','scalars4']+(['--clear-before-configure'] if pixels==1024 else []))
run('candidate-final-layers8','benchmark_pico_campaign.py',packages+['--samples','3','--seconds','20','--case','layers8','--case','maps2'])
run('candidate-final-source','benchmark_pico_campaign.py',packages+['--case','fixed12','--case','geometry12','--case','style12'])
run('candidate-final-diagnostics','benchmark_pico_campaign.py',packages+['--samples','1','--diagnostics','--case','fixed12','--case','asymmetric','--case','scalars4'])
run('candidate-final-no-observer','benchmark_pico_campaign.py',packages+['--samples','1','--poll-hz','0','--case','fixed12','--case','images2','--case','scalars4'])
run('candidate-final-saved-stars','benchmark_saved_preset.py',[])
# Finish at least one hour of continuous operation on this image, covering
# flash writes, scene replacement, USB, HTTP and authenticated MQTT traffic.
remaining=max(120,3660-(time.monotonic()-started))
soak=run('candidate-final-endurance','benchmark_ha_hardware.py',['--network',str(p/'original-objects/5-$network.json'),'--controls','0','--soak-seconds',str(remaining)])
if not soak['error_free']:raise SystemExit('Endurance retry regression')
record['complete']=True;record['elapsed_s']=time.monotonic()-started
(p/'candidate-final-sequence.json').write_text(json.dumps(record,indent=2)+'\n')
