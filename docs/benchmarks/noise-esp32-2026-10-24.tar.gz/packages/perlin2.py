from lightvm import profile, Input, Ramp, render, rgb, perlin2
profile("animation")
SCALE = Input("scale", default=4.0, minimum=0.1, maximum=32.0)
PHASE = Input("phase", default=0.0, minimum=0.0, maximum=1.0,
              driver=Ramp(duration=30.0, mode="pingpong"))
FIELD = Input("field", default=0)
@render
def draw(ctx, runtime, pixels):
    scale = runtime.input(SCALE)
    phase = runtime.input(PHASE)
    field = runtime.input(FIELD)
    for i in range(pixels.count):
        n = perlin2(i / pixels.count * scale, phase * 4.0, field)
        value = int(127.0 + 127.0 * n)
        pixels[i] = rgb(value, value, value)
