"""Run only after the ESP32 chat explicitly releases all listed ports."""
import argparse,concurrent.futures,hashlib,json,os,subprocess,time,traceback
from pathlib import Path

root=Path('/Users/kws/.codex/worktrees/6164/lightvm')
run=root/'build/noise-hardware'
parser=argparse.ArgumentParser()
parser.add_argument('--released',action='store_true',required=True)
parser.add_argument('--board',action='append',choices=('c3','c6','s3'))
parser.add_argument('--label',default='screen')
args=parser.parse_args()
env=os.environ.copy();env.update(json.loads((run/'build-environment.json').read_text()))
py=env['IDF_PYTHON_ENV_PATH']+'/bin/python'
context=json.loads((run/'context.json').read_text())
images=json.loads((run/'images.json').read_text())
def command(cmd,path,cwd=root):
    if path.exists(): raise RuntimeError('refusing to overwrite '+str(path))
    with path.open('w') as stream:
        proc=subprocess.run(cmd,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT)
    if proc.returncode: raise RuntimeError(f'{path.name}: exit {proc.returncode}')
def measure(chip):
    directory=run/'images'/chip;board=context['boards'][chip];label=chip+'-noise-'+args.label
    record={'chip':chip,'label':label,'port':board['port'],'phase':'checking image'}
    checkpoint=run/(label+'-execution.json')
    if checkpoint.exists(): raise RuntimeError('previous execution exists: '+str(checkpoint))
    def save(): checkpoint.write_text(json.dumps(record,indent=2)+'\n')
    save()
    try:
        actual=hashlib.sha256((directory/'lightvm.bin').read_bytes()).hexdigest()
        if actual!=images['images'][chip]['sha256']['lightvm.bin']: raise RuntimeError('frozen firmware hash differs')
        flash=json.loads((directory/'flasher_args.json').read_text());files=[]
        for offset,name in flash['flash_files'].items(): files.extend([offset,str(directory/name)])
        base=[py,'-m','esptool','--chip','esp32'+chip,'--port',board['port'],'--baud','460800']
        record['phase']='flashing';save()
        command(base+['write_flash']+flash['write_flash_args']+files,run/(label+'-flash.log'),directory)
        command(base+['verify_flash']+files,run/(label+'-verify.log'),directory)
        record['flash_verified']=True;record['firmware_sha256']=actual;save()
        time.sleep(2)
        print(chip+' noise firmware verified',flush=True)
        record['phase']='measuring';save()
        cmd=[py,str(root/'tools/benchmark_noise.py'),'--port',board['port'],'--board',board['board'],
             '--pin',board['pin'],'--firmware',str(directory/'lightvm.bin'),'--packages',str(run/'packages'),
             '--label',label,'--result',str(run/(label+'.json')),'--temperature-log',str(run/(label+'-temperature.jsonl')),
             '--network-regime','full-services-unprovisioned-ap','--samples','1','--seconds','3','--warmup','1','--events','8']
        record['command']=cmd;save()
        command(cmd,run/(label+'.log'))
        result=json.loads((run/(label+'.json')).read_text())
        record.update(phase='complete',passed=result['passed'],timing_windows=len(result['timing']),
                      live_windows=len(result['live']),rgb_replays=len(result['replays']),cleanup=result.get('cleanup'))
    except BaseException as error:
        record.update(passed=False,error=str(error));traceback.print_exc()
    finally:save()
    print(json.dumps(record),flush=True)
    return record
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(measure,args.board or ('c3','c6','s3')))
if not all(r.get('passed') for r in results): raise SystemExit(1)
