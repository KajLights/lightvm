import json,statistics,math
from pathlib import Path
run=Path(__file__).resolve().parent

def distribution(values):
    values=sorted(values)
    if not values:return {'count':0}
    return {'count':len(values),'median':statistics.median(values),'p95':values[math.ceil(len(values)*.95)-1],'max':max(values)}

def summarize(path):
    data=json.loads(path.read_text()); groups={}
    for row in data['timing']:
        key=f"{row['program']}/{row['pixels']}"; layer=row['layers']['A/field']
        groups.setdefault(key,{})['timing']={'render_ms':layer['mean_render_us']/1000,'updates_hz':layer['updates_per_second'],'status_p95_ms':row['status_latency_ms']['p95'],'render_reusable':layer['after']['render_reusable'],'seconds':row['seconds']}
    for row in data['live']:
        key=f"{row['program']}/{row['pixels']}"
        groups.setdefault(key,{})['live']={k:row[k] for k in ('updates_per_second','mean_render_us','actual_publish_hz','requested_publish_hz','acceptance_ms','status_latency_ms','seconds')}
        times=[r['elapsed_s'] for r in row['events']]
        groups[key]['live']['publish_intervals_ms']=distribution([(b-a)*1000 for a,b in zip(times,times[1:])])
    for key,group in groups.items():
        rows=[r for r in data['replays'] if f"{r['program']}/{r['pixels']}"==key]
        group['replay']={'count':len(rows),'all_equal':all(r['equal'] for r in rows),'input_to_readback_ms':distribution([r['composite_readback_ms'] for r in rows]),'firmware_dirty_to_display_ms':distribution([r['completed']['dirty_to_display_us']/1000 for r in rows if r['dependency_changed'] and r['completed']['dirty_to_display_us'] is not None])}
    temp=Path(data['temperature_log']);temperatures=[]
    for line in temp.read_text().splitlines():
        row=json.loads(line)
        temperatures.extend(s['value'] for s in row.get('sensors',[]) if s.get('name')=='board.temperature_c' and s.get('valid'))
    return {'source':path.name,'passed':data['passed'],'cleanup':data.get('cleanup'),'firmware_sha256':data['firmware_sha256'],'description_before':data['description_before'],'description_after':data.get('description_after'),'temperature_c':distribution(temperatures),'groups':groups,'replays':len(data['replays'])}

result={'evidence_class':'short hardware screen; no long-run stability claim','boards':{}}
for chip in ('c3','c6','s3'):
    path=run/(chip+'-noise-screen.json')
    if path.exists():result['boards'][chip]=summarize(path)
(run/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
for chip,board in result['boards'].items():
    print(chip,'passed',board['passed'],'RGB',board['replays'],'temperature',board['temperature_c'])
    for key,group in board['groups'].items():
        if key.endswith('/200'):print(key,group)
