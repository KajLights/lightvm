import concurrent.futures,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/Users/kws/.codex/worktrees/6164/lightvm');run=root/'build/noise-hardware'
sys.path.insert(0,str(root/'tools'))
from client import Client,SerialTransport
from board_monitor import BoardMonitor
context=json.loads((run/'context.json').read_text())
def clean(chip):
    board=context['boards'][chip];result={'board':board['board'],'phase':'resetting benchmark publishers'}
    try:
        with (run/(chip+'-postflight-reset.log')).open('w') as stream:
            subprocess.run([sys.executable,'-m','esptool','--chip','esp32'+chip,'--port',board['port'],'run'],stdout=stream,stderr=subprocess.STDOUT,check=True)
        time.sleep(2)
        client=Client(SerialTransport(board['port'],no_reset=True),timeout=15)
        try:
            monitor=BoardMonitor(client,run/(chip+'-postflight-temperature.jsonl'))
            result['description']=client.describe()
            result['active_config']=client.get_config();result['saved_config']=client.get_config(saved=True)
            result['programs']=client.programs();result['presets']=client.presets()
            result['benchmark_publishers']={}
            for name in ('noise.scale','noise.phase','noise.field'):
                client.manage('input_list',name=name)
                result['benchmark_publishers'][name]=json.loads(client.data_reply)
            if result['description']['version']!='1.4.0' or result['description']['board']!=board['board']:raise RuntimeError('wrong final firmware identity')
            if result['active_config']['outputs'] or result['saved_config']['outputs'] or result['programs'] or result['presets'] or any(result['benchmark_publishers'].values()):raise RuntimeError('benchmark state remains')
            result.update(phase='complete',passed=True)
        finally:client.close()
    except BaseException as e:result.update(passed=False,error=str(e))
    (run/(chip+'-postflight.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(chip,result['passed'],result.get('error'),flush=True)
    return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(clean,('c3','c6','s3')))
if not all(r['passed'] for r in results):raise SystemExit(1)
