from lightvm import profile,init,render,rgb
profile('animation')
@init
def setup(ctx,runtime):
 ctx.value=0.0
 for i in range(20000):
  ctx.value=(ctx.value+0.03125)*0.9375
@render
def draw(ctx,runtime,pixels):
 pixels.fill(rgb(int(ctx.value*200),17,87))
