from lightvm import profile,init,render,rgb,hsv,PixelArray,Transform
profile('animation')
from lightvm import ColorTransform
@render
def draw(ctx,runtime,pixels):
 pixels.fill(rgb(0,17,255))
 pixels.transform(ColorTransform(brightness=12/255))
