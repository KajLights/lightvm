import subprocess,time,sys,os,json,concurrent.futures
from pathlib import Path
p=Path(__file__).resolve().parent
while 'DONE screen28-matched' not in (p/'screen28-sequence.log').read_text():
 if 'Traceback' in (p/'screen28-sequence.log').read_text():raise SystemExit('Screen failed')
 time.sleep(3)
cmake='build/pico-async-output/tooling/cmake/data/bin/cmake';ctest='build/pico-async-output/tooling/cmake/data/bin/ctest'
def run(name,cmd,env=None):
 start=time.monotonic()
 with (p/(name+'.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 row={'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start}
 print(json.dumps(row),flush=True)
 if r.returncode:raise RuntimeError(name)
 return row
def python_tests():
 env=dict(os.environ,LIGHTVM_RECEIVER=str((p/'final/lightvm-host').resolve()))
 return [run('accepted-python',[sys.executable,'-m','unittest','discover','-s','tests'],env)]
def board_tests():
 return [run('accepted-'+name+'-build',[cmake,'--build',directory,'-j','4']) for name,directory in [('pico2','build/multicore-pico2-w'),('minimal','build/review-pico-minimal')]]
def sanitizer_tests():
 rows=[run('accepted-asan-build',[cmake,'--build','build/performance-asan','-j','4'])]
 env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1')
 rows.append(run('accepted-asan-ctest',[ctest,'--test-dir','build/performance-asan','--output-on-failure'],env))
 env.update(LIGHTVM_RECEIVER=str(Path('build/performance-asan/lightvm').resolve()),PYTHONPATH='tests:tools')
 rows.append(run('accepted-asan-python',[sys.executable,'-m','unittest','test_configuration','test_composition','test_inputs'],env))
 return rows
import hashlib,shutil
identity=json.loads((p/'final/identity.json').read_text())
def source_check():
 for name,digest in identity['source_sha256'].items():
  assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
source_check()
prechecks=[run('accepted-host-build',[cmake,'--build','build/multicore-host','-j','4']),run('accepted-ctest',[ctest,'--test-dir','build/multicore-host','--output-on-failure'])]
shutil.copy2('build/multicore-host/lightvm',p/'final/lightvm-host')
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 results=[future.result() for future in [pool.submit(fn) for fn in (python_tests,board_tests,sanitizer_tests)]]
(p/'accepted-validation.json').write_text(json.dumps({'complete':True,'checks':prechecks+sum(results,[]), 'host_sha256':hashlib.sha256((p/'final/lightvm-host').read_bytes()).hexdigest(),'sanitizer_scope':'ASan/UBSan; LeakSanitizer unavailable on this macOS host'},indent=2)+'\n')
source_check()
print('COMPLETE software validation',flush=True)
