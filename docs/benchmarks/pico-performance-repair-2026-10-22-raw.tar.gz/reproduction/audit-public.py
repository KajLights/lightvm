"""Check the final public bundle against source, raw files and the gate summary."""
import json,hashlib,tarfile
from pathlib import Path
p=Path(__file__).resolve().parent;root=p.parents[2]
sha=lambda data:hashlib.sha256(data).hexdigest()
identity=json.loads((p/'final/identity.json').read_text())
for name,digest in identity['source_sha256'].items():assert sha((root/name).read_bytes())==digest,name
for name,digest in identity['artifacts'].items():assert sha((p/'final'/name).read_bytes())==digest,name
summary=root/'docs/benchmarks/pico-performance-repair-2026-10-22.json'
r=json.loads(summary.read_text());assert r['status']=='complete' and r['regression_repair_accepted']
manifest=json.loads((root/'docs/benchmarks/pico-performance-repair-2026-10-22-manifest.json').read_text())
archive=root/'docs/benchmarks'/manifest['archive'];assert sha(archive.read_bytes())==manifest['archive_sha256']
with tarfile.open(archive) as tar:
 assert set(tar.getnames())==set(manifest['files'])|{'manifest.json'}
 for name,data in manifest['files'].items():
  value=tar.extractfile(name).read()
  assert len(value)==data['bytes'] and sha(value)==data['sha256'],name
  assert not any(forbidden in name for forbidden in ['private-full-flash','original-full-flash','initial-state.json','original-objects/']),name
 embedded=json.load(tar.extractfile('manifest.json'))
 assert embedded['files']==manifest['files']
 assert tar.extractfile('summary.json').read()==summary.read_bytes()
 patch=tar.extractfile('final/source.patch').read()
 assert b'feature-proposal-control-api' not in patch and b'feature-proposal-inputs' not in patch
 assert sha(tar.extractfile('final/lightvm.uf2').read())==r['firmware-readback']['uf2_sha256']
 assert sha(tar.extractfile('final/lightvm.elf').read())==r['resources']['pico_w']['stack-paths']['elf_sha256']
print(json.dumps({'verified':True,'source_files':len(identity['source_sha256']),'archive_files':len(manifest['files']),'archive_bytes':archive.stat().st_size,'regression_gates_pass':r['regression_repair_accepted']},indent=2))
