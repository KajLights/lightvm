import sys,struct,zlib,json,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
blob=Path(sys.argv[1]).read_bytes()[0x100000:]
u=lambda b,o:struct.unpack_from('<I',b,o)[0]
valid=[]
for base in (0,0x80000):
 root=blob[base:base+1024];commit=blob[base+1024:base+1280]
 if root[:4]!=b'LVS2' or u(root,1020)!=zlib.crc32(root[:1020]):continue
 if u(commit,0)!=0x54494d43 or u(commit,4)!=u(root,8) or u(commit,8)!=u(root,1020) or u(commit,12)!=zlib.crc32(commit[:12]):continue
 valid.append(root)
root=max(valid,key=lambda r:u(r,8));offset,size=u(root,28),u(root,32)
catalog=blob[offset:offset+size];assert zlib.crc32(catalog)==u(root,36)
rows=[]
for i in range(u(root,12)):
 r=catalog[i*64:(i+1)*64];name=r[:33].split(b'\0')[0].decode()
 if not name.startswith('hw_'):continue
 address,length=u(r,36),u(r,40);data=blob[address:address+length];assert zlib.crc32(data)==u(r,44)
 rows.append({'name':name,'flash_address':hex(0x10100000+address),'size':length,'sha256':hashlib.sha256(data).hexdigest()})
rows.sort(key=lambda r:r['name'])
Path(sys.argv[2]).write_text(json.dumps(rows,indent=2)+'\n')
print('Verified '+str(len(rows))+' resident package extents.',flush=True)
