"""After a complete candidate run: verify continuity/readback and repeat baseline."""
import sys,json,hashlib,struct,subprocess,time,datetime
from pathlib import Path
p=Path(__file__).resolve().parent;old=p.parent/'hardware-2026-10-22'
sequence=json.loads((p/'candidate-sequence.json').read_text());assert sequence['complete']
assert sequence['elapsed_s']>=3600
boots=set();watermarks={'main_stack_peak_bytes':0,'worker_stack_peak_bytes':0};descriptions=0;heap_peak=0

def inspect(value):
 global descriptions,heap_peak
 if isinstance(value,dict):
  if 'heap_peak' in value:heap_peak=max(heap_peak,int(value['heap_peak']))
  if 'boot_id' in value and isinstance(value['boot_id'],str):boots.add(value['boot_id'])
  if value.get('controller_id')=='pico-E6614103E7236D37' and 'boot_id' in value:
   boots.add(value['boot_id']);descriptions+=1
   for k in watermarks:watermarks[k]=max(watermarks[k],value.get(k,0))
  for item in value.values():inspect(item)
 elif isinstance(value,list):
  for item in value:inspect(item)
for job in sequence['jobs']:
 assert job['returncode']==0
 inspect(json.loads((p/(job['name']+'.json')).read_text()))
assert len(boots)==1,boots
preflight=json.loads((p/'candidate-preflight.json').read_text());assert boots=={preflight['boot_id']}
assert heap_peak<=65536
ha_heaps=[r['heap']['heap'] for r in json.loads((p/'candidate-ha.json').read_text())['checks']]
(p/'continuity.json').write_text(json.dumps({'verified':True,'boot_ids':sorted(boots),'descriptions':descriptions,'campaign_seconds':sequence['elapsed_s'],'watermarks':watermarks,'vm_heap_peak_bytes':heap_peak,'ha_live_heap_bytes':{'min':min(ha_heaps),'max':max(ha_heaps),'checks':len(ha_heaps)}},indent=2)+'\n')
# Full snapshots stay private; public evidence contains hashes/verified extents.
snapshot=p/'candidate-private-full-flash.bin'
if not snapshot.exists():
 snapshot.touch(mode=0o600)
 with (p/'candidate-readback.log').open('w') as f:
  subprocess.run(['build/deps/picotool-usb/picotool','save','-a','-v',str(snapshot),'--ser','E6614103E7236D37','-f'],stdout=f,stderr=subprocess.STDOUT,check=True)
blob=snapshot.read_bytes();assert len(blob)==2*1024*1024
uf2=(p/'final/lightvm.uf2').read_bytes();blocks=0
for offset in range(0,len(uf2),512):
 block=uf2[offset:offset+512];flags,address,size=struct.unpack_from('<III',block,8)
 if flags&1:continue
 assert blob[address-0x10000000:address-0x10000000+size]==block[32:32+size],hex(address)
 blocks+=1
(p/'firmware-readback.json').write_text(json.dumps({'verified':True,'blocks':blocks,'uf2_sha256':hashlib.sha256(uf2).hexdigest(),'code_and_padding_sha256':hashlib.sha256(blob[:0xfe000]).hexdigest(),'private_state_excluded':True},indent=2)+'\n')
subprocess.run([sys.executable,str(p/'read-extents.py'),str(snapshot),str(p/'resident-extents-after.json')],check=True)
assert json.loads((p/'resident-extents-before.json').read_text())==json.loads((p/'resident-extents-after.json').read_text())
print('Candidate continuity, firmware readback and all 27 package extents verified.',flush=True)
# picotool -f save returns after requesting application reboot. Let USB
# re-enumerate before a subsequent -f load tries to find that interface.
time.sleep(4)
with (p/'baseline-return-flash.log').open('w') as f:
 subprocess.run(['build/deps/picotool-usb/picotool','load','-v','-x',str(p/'resident-private-full-flash.bin'),'-t','bin','-o','0x10000000','--ser','E6614103E7236D37','-f'],stdout=f,stderr=subprocess.STDOUT,check=True)
time.sleep(4)
sys.path.insert(0,'tools')
from client import Client,HttpTransport
for attempt in range(10):
 try:
  c=Client(HttpTransport('http://10.77.10.231',timeout=10),timeout=10);c.status_fields();n=c.network_status();c.close()
  if not n['mqtt_connected']:raise RuntimeError('MQTT reconnecting')
  break
 except Exception:
  if attempt==9:raise
  time.sleep(5)
started=time.monotonic();cmd=[sys.executable,'tools/benchmark_pico_campaign.py','--port','/dev/cu.usbmodem11401','--firmware',str(old/'baseline-firmware.bin'),'--packages',str(old/'packages-baseline'),'--reuse-packages','--samples','3','--label','baseline-return-primary','--result',str(p/'baseline-return-primary.json')]
with (p/'baseline-return-primary.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
(p/'baseline-return-sequence.json').write_text(json.dumps({'complete':True,'command':cmd,'seconds':time.monotonic()-started,'purpose':'A-before/B/A-after drift check, separately reported from primary five-trial denominator'},indent=2)+'\n')
print('COMPLETE baseline return',flush=True)
