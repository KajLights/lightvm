"""Restore exact original state, then leave the user's selected firmware."""
import argparse,subprocess,sys,json,time
from pathlib import Path
p=Path(__file__).resolve().parent;old=p.parent/'hardware-2026-10-22'
parser=argparse.ArgumentParser();parser.add_argument('--leave',choices=['original','optimized'],required=True);args=parser.parse_args()
assert json.loads((p/'baseline-return-sequence.json').read_text())['complete']
picotool='build/deps/picotool-usb/picotool'
subprocess.run([picotool,'load','-v','-x',str(old/'original-full-flash.bin'),'-t','bin','-o','0x10000000','--ser','E6614103E7236D37','-f'],check=True)
time.sleep(4)
result=p/('restoration-original.json' if args.leave=='optimized' else 'restoration.json')
subprocess.run([sys.executable,str(p/'verify-restoration.py'),'--firmware','original','--result',str(result)],check=True)
if args.leave=='optimized':
 subprocess.run([picotool,'load','-v','-x',str(p/'final/lightvm.uf2'),'--ser','E6614103E7236D37','-f'],check=True)
 time.sleep(4)
 subprocess.run([sys.executable,str(p/'verify-restoration.py'),'--firmware','optimized'],check=True)
print('Restoration verified; firmware left: '+args.leave,flush=True)
