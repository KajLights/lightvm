import sys,json,time,hashlib,datetime,argparse
from pathlib import Path
sys.path.insert(0,'tools')
from client import Client,SerialTransport
p=Path(__file__).resolve().parent
old=p.parent/'hardware-2026-10-22'
parser=argparse.ArgumentParser()
parser.add_argument('--firmware',choices=['original','optimized'],default='original')
parser.add_argument('--result',type=Path,default=p/'restoration.json')
args=parser.parse_args()
original=json.loads((old/'initial-state.json').read_text())
index={(r['type'],r['name']):r for r in json.loads((old/'original-object-index.json').read_text())}
c=Client(SerialTransport('/dev/cu.usbmodem11401'),timeout=30)
try:
 deadline=time.monotonic()+90
 while True:
  n=c.network_status()
  if n['mqtt_connected']:break
  if time.monotonic()>deadline:raise RuntimeError('Restored firmware did not reconnect to MQTT')
  time.sleep(.25)
 d=c.describe();active=c.get_config();saved=c.get_config(saved=True)
 assert active==original['active_config']
 assert saved==original['saved_config']
 expected={(r['name'],r['type']) for r in original['programs']}
 actual={(r['name'],r['type']) for r in c.programs()}
 assert actual==expected,(actual,expected)
 verified=[]
 for name,kind in sorted(actual):
  typ={'animation':1,'transition':2}[kind];data=c.get_program(name,kind);digest=hashlib.sha256(data).hexdigest()
  assert digest==index[(typ,name)]['sha256'],name
  verified.append({'name':name,'type':kind,'sha256':digest})
 for name in ('rainbow','stars'):
  c.manage('preset_get',name=name);digest=hashlib.sha256(c.data_reply).hexdigest()
  assert digest==index[(3,name)]['sha256'],name
  verified.append({'name':name,'type':'preset','sha256':digest})
 before=next(o for o in d['outputs'] if o['id']=='lights')
 target=original['description']['outputs'][0]
 assert before['selected_preset']==target['selected_preset']=='rainbow'
 for key in ('power','brightness','color','color_control'):
  assert before['light'][key]==target['light'][key],(key,before['light'][key],target['light'][key])
 time.sleep(7)
 after=c.describe();output=next(o for o in after['outputs'] if o['id']=='lights')
 assert after['boot_id']==d['boot_id'] and output['frames']>before['frames']
 assert not after['boot_error'] and not output['animation_error'] and not output.get('light_error')
 result={'verified':True,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'firmware':'exact original full-flash backup, loaded with picotool -v -x and successful exit','original_full_flash_sha256':hashlib.sha256((old/'original-full-flash.bin').read_bytes()).hexdigest(),'firmware_code_sha256':hashlib.sha256((old/'baseline-firmware.bin').read_bytes()).hexdigest(),'active_config_matches':True,'saved_config_matches':True,'public_objects':verified,'storage_scope':'All 13 objects restored by verified full-flash load; ten public program/preset byte hashes checked again over USB. Private network data excluded.','mqtt_connected':True,'selected_preset':output['selected_preset'],'light':{k:output['light'][k] for k in ('power','brightness','color','color_control')},'frames_advanced':output['frames']-before['frames'],'boot_id':after['boot_id'],'errors':[]}
 if args.firmware=='optimized':
  result['firmware']='validated repair UF2 loaded with picotool -v -x after verified restoration of the exact original full-flash snapshot'
  result.pop('firmware_code_sha256')
  result['firmware_uf2_sha256']=hashlib.sha256((p/'final/lightvm.uf2').read_bytes()).hexdigest()
  result['storage_scope']='All 13 original objects restored before firmware-only flashing; ten public program/preset byte hashes checked again over USB. Private network data excluded.'
 args.result.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
finally:c.close()
