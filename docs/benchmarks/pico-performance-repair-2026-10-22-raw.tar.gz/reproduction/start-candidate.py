import subprocess,sys,json,time,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
while not (p/'accepted-validation.json').exists():
 if 'Traceback' in (p/'accepted-validation-sequence.log').read_text():raise SystemExit('Software validation failed')
 time.sleep(3)
assert json.loads((p/'accepted-validation.json').read_text())['complete']
identity=json.loads((p/'final/identity.json').read_text())
for name,digest in identity['source_sha256'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
assert hashlib.sha256((p/'final/lightvm.uf2').read_bytes()).hexdigest()==identity['artifacts']['lightvm.uf2']
for name,extra in [('resident-private-full-flash.bin',['-t','bin','-o','0x10000000']),('final/lightvm.uf2',[])]:
 with (p/('candidate-flash-'+Path(name).stem+'.log')).open('w') as f:
  subprocess.run(['build/deps/picotool-usb/picotool','load','-v','-x',str(p/name)]+extra+['--ser','E6614103E7236D37','-f'],stdout=f,stderr=subprocess.STDOUT,check=True)
 time.sleep(4)
sys.path.insert(0,'tools')
from client import Client,HttpTransport
for attempt in range(10):
 try:
  client=Client(HttpTransport('http://10.77.10.231',timeout=10),timeout=10)
  description=client.describe();state=client.network_status();client.close()
  if not state['mqtt_connected']:raise RuntimeError('MQTT not yet ready')
  assert description['controller_id']=='pico-E6614103E7236D37'
  assert description['cpu_clock_hz']==125000000
  assert description['ingress_calls']>0
  (p/'candidate-preflight.json').write_text(json.dumps({'boot_id':description['boot_id'],'controller_id':description['controller_id'],'cpu_clock_hz':description['cpu_clock_hz'],'http_ready':True,'mqtt_connected':True,'firmware_sha256':identity['artifacts']['lightvm.uf2']},indent=2)+'\n')
  break
 except Exception:
  if attempt==9:raise
  time.sleep(5)
print('Candidate flashed on the matched resident catalog; HTTP and MQTT ready.',flush=True)
subprocess.run([sys.executable,'-u',str(p/'run-block.py'),'candidate'],check=True)
