"""Assemble the repeat campaign without discarding failed screens or old evidence."""
import sys,json,hashlib,statistics,datetime
from pathlib import Path
p=Path(__file__).resolve().parent;root=p.parents[2];old=p.parent/'hardware-2026-10-22'
sys.path.insert(0,str(root/'tools'))
from summarize_pico_campaign import summarize,compare
from benchmark_saved_preset import percentile

def load(name):return json.loads((p/(name+'.json')).read_text())
def distribution(values):
 return {'count':len(values),'median':statistics.median(values),'p95':percentile(values,.95),'p99':percentile(values,.99),'min':min(values),'max':max(values)} if values else None

def comparison(a,b):
 x=summarize([p/(a+'.json')]);y=summarize([p/(b+'.json')]);return {'baseline':x,'candidate':y,'changes':compare(x,y)}

result={'date':'2026-10-22','status':'in progress','scope':'One RP2040 B2 Pico W, 125 MHz, serial E6614103E7236D37; 200 physical WS2812 pixels on GP16, with logical 500/1024-pixel configurations on the same wire.',
 'baseline':{'source_association':'59b7c52 (inferred; verified binary is authoritative)','firmware_sha256':hashlib.sha256((old/'baseline-firmware.bin').read_bytes()).hexdigest()},
 'candidate':load('final/identity'),'software_validation':load('accepted-validation'),
 'comparisons':{},'preparation':{},'dirty_input':{},'ha':{},'replays':{},'resources':{},
 'method':{'primary':'Five 30-second trials per case after seven-second warmup; identical archived bytecode and case order; alternating case-order reversal within each block.',
           'secondary':'Three 20-second trials for two/eight maps and each 500/1024-pixel case.',
           'confidence':'5000 independent trial-resampling bootstrap draws of median ratios; seed 20261022. Five-trial intervals are descriptive and omit systematic uncertainty.',
           'observer':'20 Hz STATUS; expensive describe/transition readback is at sample boundaries. Boundary-only observer checks reported separately.',
           'foreground':'fg10 retains full app_tick intervals. io10 measures actual bounded USB/digital-input polls before and after engine work. Steady deltas use existing STATUS replies, excluding boundary-only describe calls.'},
 'limitations':['No optical/electrical probe; contribution stamps describe software driver completion, not observed light.',
                'Baseline firmware has no comparable displayed-age/input stamps, stack watermark or steady ingress counter.',
                'Basic internal telemetry overhead is not isolated from necessary runtime bookkeeping; observer cost is a separate measurement.',
                'Pico 2 W, APA102, multiple physical outputs and external electrical timing still require the corresponding hardware.',
                'One board and one run order are the primary comparison; the later baseline return block checks drift separately when present.',
                'ASan/UBSan ran on host; LeakSanitizer is unavailable on this macOS host.']}
for name in ['primary','layers','pixels-500','pixels-1024','saved-stars','no-observer']:
 if (p/('candidate-'+name+'.json')).exists():result['comparisons'][name]=comparison('baseline-'+name,'candidate-'+name)
if (p/'candidate-source.json').exists():result['source_variants']=summarize([p/'candidate-source.json'])
if (p/'baseline-return-primary.json').exists():
 result['baseline_return']=comparison('baseline-primary','baseline-return-primary')
 result['candidate_vs_return']=comparison('baseline-return-primary','candidate-primary')
for label in ['baseline','candidate']:
 if (p/(label+'-preparation.json')).exists():
  d=load(label+'-preparation');rows=d['samples']
  result['preparation'][label]={'complete':d.get('complete',False),'trials':len(rows),'acceptance_ms':distribution([r['acceptance_ms'] for r in rows]),'completion_ms':distribution([r['completion_ms'] for r in rows]),'usb_latency_ms':distribution([v for r in rows for v in r['usb_latency_ms']]),'http_latency_ms':distribution([(v['ended']-v['started'])*1000 for r in rows for v in r['http_observations'] if 'ended' in v]),'http_valid':all(r['http_valid'] for r in rows),'stage_execution_us':[r['operation']['stage_us'] for r in rows if r['operation']], 'cancellations':d['cancellations'], 'loop_over_10ms':[], 'ingress_over_10ms':[]}
  for row in rows:
   if label=='candidate':
    frames=[int(v['state']['frames']) for v in row['http_observations'] if 'state' in v and int(v['state'].get('generation',-1))==row['before']['generation']]
    result['preparation'][label].setdefault('old_scene_frame_advances',[]).append(max(frames)-min(frames) if len(frames)>1 else 0)
   f=row.get('foreground_gap_samples',[])
   if f:
    result['preparation'][label]['loop_over_10ms'].append(f[-1]['over_10ms']-f[0]['over_10ms'])
    if f[0].get('ingress_over_10ms') is not None:result['preparation'][label]['ingress_over_10ms'].append(f[-1]['ingress_over_10ms']-f[0]['ingress_over_10ms'])
 if (p/(label+'-dirty.json')).exists():
  d=load(label+'-dirty');result['dirty_input'][label]={'complete':d.get('complete',False),'events':len(d['events']),'readback_ms':distribution([r['composite_readback_ms'] for r in d['events']]),'driver_completion_ms':distribution([r['completed']['dirty_to_display_us']/1000 for r in d['events'] if r['completed'].get('dirty_to_display_us') is not None])}
 if (p/(label+'-ha.json')).exists():
  d=load(label+'-ha');result['ha'][label]={k:v for k,v in d.items() if k.endswith('_summary') or k in ['complete','boot_unchanged','error_free','output_retry_observations']}
  expected=[x['command'] for x in d['scenario']+d['controls']]
  observed=d['observed_commands'];result['ha'][label]['observed_sequence_matches']=[x[1] for x in observed[:-1]]==expected
for name in ['memory','usb','preflight','sequence']:
 if (p/('candidate-'+name+'.json')).exists():
  d=load('candidate-'+name)
  result[name]=d if name!='memory' else {'complete':d['complete'],'samples':[{k:v for k,v in s.items() if k not in ['before','after_rejected']} for s in d['samples']]}
if (p/'candidate-endurance.json').exists():
 d=load('candidate-endurance');result['endurance']={k:v for k,v in d.items() if k.endswith('_summary') or k in ['complete','boot_unchanged','error_free','soak_seconds','output_retry_observations']}
 heaps=[r['heap']['heap'] for r in d['checks']]
 result['endurance']['sampled_live_heap_bytes']={'min':min(heaps),'max':max(heaps),'count':len(heaps)} if heaps else None
 if d.get('complete'):result['endurance']['observed_sequence_matches']=[r[1] for r in d['observed_commands'][:-1]]==[r['command'] for r in d['scenario']+d['controls']+d['soak']]
if (p/'candidate-replays.json').exists():
 ref={r['name']:r for r in load('baseline-replays')['replays']}
 fields=['program_us','paused','faulted','contribution_valid','output_valid','contribution_frame','output_frame','render_count','active_wall_us','inputs_revision','inputs','settings_values']
 for r in load('candidate-replays')['replays']:
  b=ref[r['name']];result['replays'][r['name']]={'frames':r['frames'],'sha256_all_frames':r['sha256_all_frames'],'pixels_equal':r['frame_sha256']==b['frame_sha256'],'state_equal':all(r['after'].get(k)==b['after'].get(k) for k in fields),'state_fields':fields,'dispatches':r['after']['dispatch_count']-r['before']['dispatch_count']}
for prefix in ['','pico2-','minimal-']:
 result['resources'][prefix or 'pico_w']={name:load('final/'+prefix+name) for name in ['ram-report','stack-paths']}
for name in ['firmware-readback','continuity','restoration','resident-packages','resident-extents-before','resident-extents-after']:
 if (p/(name+'.json')).exists():result[name]=load(name)
if 'resident-extents-after' in result:result['package_extents_unchanged']=result['resident-extents-before']==result['resident-extents-after']
# Frozen-screen records are diagnostic, never substituted for missing full trials.
result['screens']=[]
for folder in sorted((f for f in p.glob('screen[0-9]*') if f.is_dir() and f.name[6:].isdigit()),key=lambda f:int(f.name[6:])):
 row={'name':folder.name}
 if (folder/'lightvm.uf2').exists():row['firmware_sha256']=hashlib.sha256((folder/'lightvm.uf2').read_bytes()).hexdigest()
 if (folder/'preparation.json').exists():
  d=json.loads((folder/'preparation.json').read_text());row['preparation_median_ms']=statistics.median(s['completion_ms'] for s in d['samples']) if d['samples'] else None
 result['screens'].append(row)
if result.get('sequence',{}).get('complete') and result.get('restoration',{}).get('verified'):
 result['status']='complete'
# Gates are intentionally explicit; missing evidence is not a pass.
gates={}
comparisons=result['comparisons']
for name in ['primary','layers','pixels-500','pixels-1024']:
 if name not in comparisons:continue
 d=comparisons[name];losses=[];latency_fail=[];ingress=[]
 for case,layers in d['changes'].items():
  for layer,change in layers.items():
   if case in ['fixed12','timed'] and layer=='A/layer0':continue
   if change['median_change_percent'] < -5:losses.append([case,layer,change['median_change_percent']])
  a=d['baseline'][case]['status_latency_ms'];b=d['candidate'][case]['status_latency_ms']
  if b['p95']>15 or b['p99']>25 or b['p95']>a['p95']+max(a['p95']*.1,1):latency_fail.append(case)
  ingress.extend(m['steady_ingress_over_10ms'] for m in d['candidate'][case]['pair_measurements'])
 gates[name]={'dynamic_rate_pass':not losses,'rate_failures':losses,'usb_pass':not latency_fail,'usb_failures':latency_fail,'ingress_pass':bool(ingress) and all(n==0 for n in ingress),'ingress_deltas':ingress}
if 'candidate' in result['preparation']:
 a=result['preparation']['baseline'];b=result['preparation']['candidate'];gates['preparation']={'acceptance_pass':b['acceptance_ms']['p95']<=100,'completion_pass':b['completion_ms']['median']<=a['completion_ms']['median']*.8,'completion_change_percent':(b['completion_ms']['median']/a['completion_ms']['median']-1)*100,'busy_usb_pass':b['usb_latency_ms']['p95']<=15 and b['usb_latency_ms']['p99']<=25,'ingress_pass':len(b['ingress_over_10ms'])==5 and all(n==0 for n in b['ingress_over_10ms']),'cancellation_pass':len(b['cancellations'])==10 and all(r['old_generation_preserved'] and r['operation']['stage']=='cancelled' for r in b['cancellations'])}
 gates['preparation']['complete_pass']=b['complete'] and b['trials']==5 and b['http_valid']
 gates['preparation']['old_scene_progress_pass']=len(b['old_scene_frame_advances'])==5 and all(n>0 for n in b['old_scene_frame_advances'])
if 'candidate' in result['dirty_input']:gates['freshness_readback_pass']=result['dirty_input']['candidate']['complete'] and result['dirty_input']['candidate']['events']==100 and result['dirty_input']['candidate']['readback_ms']['p95']<=result['dirty_input']['baseline']['readback_ms']['p95']
if result['replays']:gates['exact_replays_pass']=sum(r['frames'] for r in result['replays'].values())==1400 and all(r['pixels_equal'] and r['state_equal'] for r in result['replays'].values())
required={'primary':(5,{'fixed12','timed','images2','asymmetric','scalars4','ab'}),'layers':(3,{'maps2','layers8'}),'pixels-500':(3,{'fixed12','images2','scalars4'}),'pixels-1024':(3,{'fixed12','images2','scalars4'})}
gates['matched_matrix_complete_pass']=all(
 name in comparisons and all(set(comparisons[name][side])==cases and all(row['trials']==trials for row in comparisons[name][side].values()) for side in ['baseline','candidate']) and all(set(comparisons[name]['baseline'][case]['layers'])==set(comparisons[name]['candidate'][case]['layers']) for case in cases)
 for name,(trials,cases) in required.items())
ha=result['ha'].get('candidate',{})
gates['ha_pass']=bool(ha.get('complete') and ha.get('error_free') and ha.get('boot_unchanged') and ha.get('observed_sequence_matches') and ha.get('controls_summary',{}).get('count')==1000 and ha['controls_summary']['p95_ms']<=500 and ha['controls_summary']['max_ms']<=750)
memory=result.get('memory',{})
gates['large_scene_replacement_pass']=bool(memory.get('complete') and len(memory['samples'])==3 and all(s['empty_replacement_succeeded'] and s['heap_before']==s['heap_after_rejected'] for s in memory['samples']))
usb=result.get('usb',{})
gates['usb_packet_boundaries_pass']=bool(usb.get('complete') and usb.get('boot_unchanged') and usb.get('config_unchanged') and len(usb['requests'])==180)
gates['software_validation_pass']=bool(result['software_validation'].get('complete') and all(c['exit_code']==0 for c in result['software_validation']['checks']))
gates['resource_and_stack_pass']=all(r['ram-report']['remaining_bytes_after_reservations']>0 and r['stack-paths']['software_accounting_complete'] and r['stack-paths']['software_gate_passed'] for r in result['resources'].values())
endurance=result.get('endurance',{});continuity=result.get('continuity',{})
gates['endurance_pass']=bool(endurance.get('complete') and endurance.get('error_free') and endurance.get('boot_unchanged') and endurance.get('observed_sequence_matches') and continuity.get('verified') and continuity.get('campaign_seconds',0)>=3600 and endurance['sampled_live_heap_bytes']['min']==endurance['sampled_live_heap_bytes']['max'])
gates['firmware_and_packages_pass']=bool(result.get('firmware-readback',{}).get('verified') and result.get('package_extents_unchanged'))
gates['restoration_pass']=bool(result.get('restoration',{}).get('verified'))
gates['baseline_return_complete_pass']=bool((p/'baseline-return-sequence.json').exists() and load('baseline-return-sequence').get('complete'))
if gates['baseline_return_complete_pass']:
 gates['baseline_return_complete_pass']=set(result['baseline_return']['candidate'])==required['primary'][1] and all(r['trials']==3 for r in result['baseline_return']['candidate'].values())
 gates['dynamic_progress_vs_return_pass']=all(change['median_change_percent']>=-5 for case,layers in result['candidate_vs_return']['changes'].items() for layer,change in layers.items() if not (case in ['fixed12','timed'] and layer=='A/layer0'))
result['acceptance']=gates
checks=[]
for name,value in gates.items():
 if isinstance(value,bool):checks.append(value)
 else:checks.extend(v for k,v in value.items() if k.endswith('_pass'))
result['regression_repair_accepted']=result['status']=='complete' and all(checks)
result['broader_plan_open']=['P1 internal telemetry <=2% is not isolated; no acceptance claimed for that gate.',
 'P6 optional shared batch remains an investigation: two eligible VMs cannot fill a third independent job while one core waits.',
 'Physical Pico 2 W, APA102, multiple outputs and optical/electrical probes.']
out=root/'docs/benchmarks/pico-performance-repair-2026-10-22.json';out.write_text(json.dumps(result,indent=2)+'\n');print(out)
