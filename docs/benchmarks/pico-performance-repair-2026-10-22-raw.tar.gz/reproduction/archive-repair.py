"""Publish an explicit evidence allowlist, excluding private controller storage."""
import json,hashlib,gzip,tarfile,io
from pathlib import Path
p=Path(__file__).resolve().parent;root=p.parents[2];old=p.parent/'hardware-2026-10-22'
files={}
summary=root/'docs/benchmarks/pico-performance-repair-2026-10-22.json'
assert json.loads(summary.read_text())['regression_repair_accepted'], 'Do not publish an incomplete repair as accepted'
def add(name,path):
 if not path.is_file():raise FileNotFoundError(name)
 files[name]=path
# Only measured outputs and their logs; never glob private flash/state files.
for label in ['baseline','candidate']:
 for suffix in ['sequence','primary','layers','pixels-500','pixels-1024','preparation','dirty','ha','replays','saved-stars','no-observer']:
  add(label+'-'+suffix+'.json',p/(label+'-'+suffix+'.json'))
  f=p/(label+'-'+suffix+'.log')
  if f.exists():add(f.name,f)
for name in ['candidate-memory','candidate-usb','candidate-source','candidate-endurance','candidate-preflight','firmware-readback','continuity','restoration','resident-packages','resident-extents-before','resident-extents-after','accepted-validation','baseline-return-primary','baseline-return-sequence']:
 f=p/(name+'.json');add(f.name,f)
for name in ['tools/benchmark_configuration_memory.py','tools/benchmark_usb_hardware.py']:
 add('reproduction/'+name,root/name)
for name in ['accepted-validation.py','start-candidate.py','run-block.py','read-extents.py','verify-restoration.py','restore-state.py','assemble-repair.py','archive-repair.py','audit-public.py','run-baseline-return.py']:
 add('reproduction/'+name,p/name)
for name in ['candidate-memory.log','candidate-usb.log','candidate-source.log','candidate-endurance.log','candidate-readback.log','baseline-return-primary.log','baseline-return-sequence.log','baseline-return-flash.log','baseline-return-sequence-first-attempt.log','baseline-return-flash-first-attempt.log','restoration-original.json']:
 f=p/name
 if f.exists():add(name,f)
add('summary.json',summary)
for name in ['accepted-host-build.log','accepted-ctest.log','accepted-python.log','accepted-asan-build.log','accepted-asan-ctest.log','accepted-asan-python.log','accepted-pico2-build.log','accepted-minimal-build.log','accepted-validation-sequence.log','failed-test-header-accepted-host-build.log','failed-test-header-accepted-validation-sequence.log','restoration.log']:
 add(name,p/name)
for name in ['identity.json','uf2-layout.json','storage-layout.json','source.patch','status.h','lightvm.elf','lightvm.uf2','ram-report.json','stack-paths.json','ha-stack-report.json','pico2-ram-report.json','pico2-stack-paths.json','minimal-ram-report.json','minimal-stack-paths.json','pico-build.log']:
 add('final/'+name,p/'final'/name)
for folder in sorted(p.glob('screen[0-9]*')):
 if not folder.is_dir():continue
 for f in folder.iterdir():
  if f.suffix in ['.json','.log','.patch','.h']:
   add('screens/'+folder.name+'/'+f.name,f)
 f=p/(folder.name+'-sequence.log')
 if f.exists():add('screens/'+f.name,f)
for f in (old/'packages-baseline').iterdir():
 if f.suffix in ['.json','.py','.lbc']:add('packages/'+f.name,f)
for name in ['rom-identity.json','rom-stack-paths.json']:
 add('prior-rom-audit/'+name,old/name)

def check_keys(value):
 if isinstance(value,dict):
  for key,item in value.items():
   if key.lower() in ['password','username','ssid','secret','access_token','refresh_token']:raise ValueError('Private field in public JSON')
   check_keys(item)
 elif isinstance(value,list):
  for item in value:check_keys(item)
network=json.loads((old/'original-objects/5-$network.json').read_text())
secret_values=[]
def collect(value):
 if isinstance(value,dict):
  for key,item in value.items():
   if key.lower() in ['password','username','ssid'] and isinstance(item,str) and len(item)>=4:secret_values.append(item.encode())
   collect(item)
 elif isinstance(value,list):
  for item in value:collect(item)
collect(network)
for name,f in files.items():
 data=f.read_bytes()
 if f.suffix=='.json':check_keys(json.loads(data))
 if any(secret in data for secret in secret_values):raise ValueError('Private value found in '+name)
manifest={'scope':'Regression repair and repeated Pico W comparison, 22 October 2026','private_exclusions':['Full flash snapshots','initial-state.json','original network configuration and credentials'],
 'files':{name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for name,f in sorted(files.items())}}
out=root/'docs/benchmarks/pico-performance-repair-2026-10-22-raw.tar.gz'
with out.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as archive:
 for name,f in sorted(files.items()):
  data=f.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0;archive.addfile(entry,io.BytesIO(data))
 data=(json.dumps(manifest,indent=2)+'\n').encode();entry=tarfile.TarInfo('manifest.json');entry.size=len(data);entry.mode=0o644;entry.mtime=0;archive.addfile(entry,io.BytesIO(data))
(root/'docs/benchmarks/pico-performance-repair-2026-10-22-manifest.json').write_text(json.dumps({'archive':out.name,'archive_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),**manifest},indent=2)+'\n')
print('Published',len(files),'allowlisted files;',out.stat().st_size,'compressed bytes; private-key/value scan passed.')
