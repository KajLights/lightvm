import subprocess,sys,json,time,datetime,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent;old=p.parent/'hardware-2026-10-22';mode=sys.argv[1]
assert mode in ('baseline','candidate')
firmware=old/'baseline-firmware.bin' if mode=='baseline' else p/'final/lightvm.uf2'
common=['--port','/dev/cu.usbmodem11401','--firmware',str(firmware)]
packages=['--packages',str(old/'packages-baseline'),'--reuse-packages']
started=time.monotonic();record={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'firmware_sha256':hashlib.sha256(firmware.read_bytes()).hexdigest(),'jobs':[]}
recordfile=p/(mode+'-sequence.json')
if recordfile.exists():
 record=json.loads(recordfile.read_text());started=time.monotonic()-(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(record['started_utc'])).total_seconds()
def run(suffix,tool,args):
 name=mode+'-'+suffix
 if any(j['name']==name and j['returncode']==0 for j in record['jobs']):return json.loads((p/(name+'.json')).read_text())
 command=[sys.executable,'tools/'+tool]+common+['--label',name,'--result',str(p/(name+'.json'))]+args
 print('START '+name,flush=True);tick=time.monotonic()
 with (p/(name+'.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 record['jobs'].append({'name':name,'command':command,'elapsed_s':time.monotonic()-tick,'returncode':r.returncode,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});record['elapsed_s']=time.monotonic()-started
 recordfile.write_text(json.dumps(record,indent=2)+'\n')
 if r.returncode:raise SystemExit('FAILED '+name)
 print('DONE '+name,flush=True);return json.loads((p/(name+'.json')).read_text())
if mode=='candidate':
 run('usb','benchmark_usb_hardware.py',[])
 run('memory','benchmark_configuration_memory.py',['--packages',str(old/'packages-baseline')])
run('primary','benchmark_pico_campaign.py',packages)
run('layers','benchmark_pico_campaign.py',packages+['--samples','3','--seconds','20','--case','layers8','--case','maps2'])
for pixels in (500,1024):
 run('pixels-'+str(pixels),'benchmark_pico_campaign.py',packages+['--pixels',str(pixels),'--samples','3','--seconds','20','--case','fixed12','--case','images2','--case','scalars4'])
run('preparation','benchmark_preparation_hardware.py',packages+['--url','http://10.77.10.231'])
run('dirty','benchmark_dirty_hardware.py',packages)
ha=run('ha','benchmark_ha_hardware.py',['--network',str(old/'original-objects/5-$network.json')])
if mode=='candidate' and not ha['error_free']:raise SystemExit('HA retry regression')
run('replays','benchmark_pico_campaign.py',packages+['--replay'])
run('saved-stars','benchmark_saved_preset.py',[])
run('no-observer','benchmark_pico_campaign.py',packages+['--samples','1','--poll-hz','0','--case','fixed12','--case','images2','--case','scalars4'])
if mode=='candidate':
 run('source','benchmark_pico_campaign.py',packages+['--case','fixed12','--case','geometry12','--case','style12'])
 remaining=max(120,3660-(time.monotonic()-started))
 soak=run('endurance','benchmark_ha_hardware.py',['--network',str(old/'original-objects/5-$network.json'),'--controls','0','--soak-seconds',str(remaining)])
 if not soak['error_free']:raise SystemExit('Endurance error')
record['complete']=True;record['elapsed_s']=time.monotonic()-started;recordfile.write_text(json.dumps(record,indent=2)+'\n')
print('COMPLETE '+mode,flush=True)
