from pathlib import Path
import subprocess,time,json,hashlib
root=Path('/Users/kws/.codex/worktrees/core-numeric-foundation/lightvm')
py='/Users/kws/work/kajlights/lightvm/build/venv/bin/python'
flash='/Users/kws/work/kajlights/lightvm/build/deps/picotool-usb/picotool'
base=Path('/Users/kws/work/kajlights/lightvm/build/performance-review/regression-fixes-2026-10-22/final/lightvm.uf2')
out=Path('/private/tmp/lightvm-s234-final');out.mkdir(exist_ok=True)
firmwares={}
for name,source in [('candidate-2','/private/tmp/lightvm-s1-pico-w/lightvm.uf2'),('candidate-1','/private/tmp/lightvm-s234-pico-single/lightvm.uf2'),('probe','/private/tmp/lightvm-s1-pico-w/numeric_probe.uf2')]:
 dest=out/(name+'.uf2');dest.write_bytes(Path(source).read_bytes());firmwares[name]=dest
print(json.dumps({n:hashlib.sha256(f.read_bytes()).hexdigest() for n,f in firmwares.items()}),flush=True)
def install(firmware,label):
 with (out/(label+'-flash.log')).open('w') as log:
  subprocess.run([flash,'load','-v','-x',str(firmware),'-f','--ser','E6614103E7236D37'],stdout=log,stderr=subprocess.STDOUT,check=True)
 time.sleep(7)
def run(tool,*args):
 subprocess.run([py,'-B','tools/'+tool,*map(str,args)],cwd=root,check=True)
install(firmwares['probe'],'probe')
run('check_native_math_hardware.py','--port','/dev/cu.usbmodem11401','--firmware',firmwares['probe'],'--result',out/'math.json')
for trial in range(1,6):
 for label,firmware in [('baseline',base),('candidate',firmwares['candidate-2'])]:
  tag=f'control-{trial}-{label}';install(firmware,tag)
  run('benchmark_saved_preset.py','--port','/dev/cu.usbmodem11401','--preset','rainbow','--firmware',firmware,'--label',tag,'--result',out/(tag+'-rainbow.json'),'--samples','1','--seconds','5','--warmup','2')
  run('benchmark_pico_campaign.py','--port','/dev/cu.usbmodem11401','--packages','/private/tmp/lightvm-s234-control-packages','--firmware',firmware,'--label',tag,'--result',out/(tag+'-maps.json'),'--case','map','--case','fixed12','--case','asymmetric','--samples','1','--seconds','5','--warmup','2')
for workers in (2,1):
 firmware=firmwares['candidate-'+str(workers)];label='numeric-'+str(workers)
 if workers==1:install(firmware,label)
 common=['--port','/dev/cu.usbmodem11401','--packages','/private/tmp/lightvm-s234-numeric-packages','--firmware',firmware,'--label',label]
 run('check_numeric_runtime_hardware.py','--port','/dev/cu.usbmodem11401','--firmware',firmware,'--result',out/(label+'-faults.json'))
 run('benchmark_numeric.py',*common,'--result',out/(label+'-replay.json'),'--correctness','--pixels','1','31','32','33','63','64','65','127','128','129','200','500','1024')
 run('benchmark_numeric.py',*common,'--result',out/(label+'-main.json'),'--case','gather-repeat','--case','fixed-branch','--samples','5','--seconds','6','--warmup','2','--mixed')
 run('benchmark_numeric.py',*common,'--result',out/(label+'-math.json'),'--case','gaussian','--case','colour-power','--case','damping','--case','gather-fit','--samples','1','--seconds','5','--warmup','2','--pixels','200')
 if workers==2:
  run('benchmark_numeric.py',*common,'--result',out/(label+'-sizes.json'),'--case','gather-repeat','--case','fixed-branch','--case','gaussian','--samples','1','--seconds','5','--warmup','2','--pixels','500','1024')
install(firmwares['candidate-2'],'restore-two-worker')
print('FINAL HARDWARE CAMPAIGN COMPLETE',flush=True)
