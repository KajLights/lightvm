from pathlib import Path
import hashlib,json,sys,time
ROOT=Path('/Users/kws/.codex/worktrees/core-numeric-foundation/lightvm')
sys.path.insert(0,str(ROOT/'tools'))
from client import Client,SerialTransport
initial=Path('/private/tmp/lightvm-s234-controls')
rainbow=json.loads((initial/'1-baseline-rainbow.json').read_text())
stars=json.loads((initial/'1-baseline-stars.json').read_text())
c=Client(SerialTransport('/dev/cu.usbmodem11401'),timeout=120)
result={}
try:
    description=c.describe()
    assert description['version']=='1.3.0' and description['render_workers']==2
    assert description['storage_bytes']==1048576 and description['storage_available']
    assert c.get_config()==rainbow['config']
    assert c.get_config(saved=True)==rainbow['config']
    artifacts=[]
    for p in c.programs():
        data=c.get_program(p['name'],p['type'])
        artifacts.append({**p,'sha256':hashlib.sha256(data).hexdigest()})
    normalize=lambda rows:sorted(rows,key=lambda p:(p['name'],p['type']))
    assert normalize(artifacts)==normalize(rainbow['artifacts']),artifacts
    presets={name:c.preset(name) for name in ('rainbow','stars')}
    assert presets['rainbow']==rainbow['preset'] and presets['stars']==stars['preset']
    result.update(programs=artifacts,presets=presets,config=rainbow['config'],saved_config_unchanged=True,
                  programs_unchanged=True,presets_unchanged=True,no_temporary_programs=True)
    c.set_light(brightness=.8,power=True,preset='rainbow',output='lights')
    time.sleep(3)
    state=c.light_state(output='lights')
    assert state['power'] and abs(state['brightness']-.8)<.000001 and state['preset']=='rainbow'
    result['light_state']=state
    network=c.network_status()
    # Keep only generic service/link states, never saved network names or secrets.
    def filter_status(value):
        if not isinstance(value,dict):return {}
        keep={}
        for key,v in value.items():
            if isinstance(v,dict):
                child=filter_status(v)
                if child:keep[key]=child
            elif key in ('state','status','connected','enabled','ready','error','mode','supported','link','link_status','mqtt_connected'):
                keep[key]=v
        return keep
    result['network_service_states']=filter_status(network)
    result['description']=c.describe()
    result['passed']=True
    Path('/private/tmp/lightvm-s234-final/restoration.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('description','presets','config','programs')},indent=2))
finally:c.close()
