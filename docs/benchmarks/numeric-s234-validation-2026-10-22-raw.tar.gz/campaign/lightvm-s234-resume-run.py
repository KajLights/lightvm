from pathlib import Path
import subprocess,time,json,hashlib
root=Path('/Users/kws/.codex/worktrees/core-numeric-foundation/lightvm');out=Path('/private/tmp/lightvm-s234-final')
py='/Users/kws/work/kajlights/lightvm/build/venv/bin/python';flash='/Users/kws/work/kajlights/lightvm/build/deps/picotool-usb/picotool'
def run(tool,*args):subprocess.run([py,'-B','tools/'+tool,*map(str,args)],cwd=root,check=True)
def install(firmware,label):
 with (out/(label+'-flash.log')).open('w') as log:subprocess.run([flash,'load','-v','-x',str(firmware),'-f','--ser','E6614103E7236D37'],stdout=log,stderr=subprocess.STDOUT,check=True)
 time.sleep(7)
firmware=out/'candidate-1-storage-corrected.uf2';firmware.write_bytes(Path('/private/tmp/lightvm-s234-pico-single/lightvm.uf2').read_bytes());print('one-worker firmware',hashlib.sha256(firmware.read_bytes()).hexdigest(),flush=True)
install(firmware,'one-worker-corrected')
common=['--port','/dev/cu.usbmodem11401','--packages','/private/tmp/lightvm-s234-numeric-packages','--firmware',firmware,'--label','numeric-1']
run('check_numeric_runtime_hardware.py','--port','/dev/cu.usbmodem11401','--firmware',firmware,'--result',out/'numeric-1-faults.json')
run('benchmark_numeric.py',*common,'--result',out/'numeric-1-replay.json','--correctness','--pixels','1','31','32','33','63','64','65','127','128','129','200','500','1024')
run('benchmark_numeric.py',*common,'--result',out/'numeric-1-main.json','--case','gather-repeat','--case','fixed-branch','--samples','5','--seconds','6','--warmup','2','--mixed')
run('benchmark_numeric.py',*common,'--result',out/'numeric-1-math.json','--case','gaussian','--case','colour-power','--case','damping','--case','gather-fit','--samples','1','--seconds','5','--warmup','2','--pixels','200')
run('benchmark_numeric.py',*common,'--result',out/'numeric-1-heavy.json','--case','math-body','--samples','1','--seconds','10','--warmup','2','--pixels','33')
firmware=out/'candidate-2.uf2';install(firmware,'restore-two-worker')
common=['--port','/dev/cu.usbmodem11401','--packages','/private/tmp/lightvm-s234-numeric-packages','--firmware',firmware,'--label','numeric-2']
run('benchmark_numeric.py',*common,'--result',out/'numeric-2-heavy-replay.json','--case','math-body','--correctness','--pixels','1','31','32','33','63','64','65','127','128','129','200','500','1024')
run('benchmark_numeric.py',*common,'--result',out/'numeric-2-heavy.json','--case','math-body','--samples','1','--seconds','10','--warmup','2','--pixels','33')
print('FINAL HARDWARE CAMPAIGN COMPLETE',flush=True)
