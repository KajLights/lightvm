from pathlib import Path
import collections, gzip, hashlib, io, json, math, statistics, subprocess, tarfile

ROOT = Path('/Users/kws/.codex/worktrees/core-numeric-foundation/lightvm')
RUN = Path('/private/tmp/lightvm-s234-final')
DEST = ROOT / 'docs/benchmarks'
PREFIX = 'numeric-s234-validation-2026-10-22'

def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text())
def stats(values):
    values = [x for x in values if x is not None]
    return dict(n=len(values), median=statistics.median(values), minimum=min(values), maximum=max(values), stdev=statistics.stdev(values) if len(values)>1 else None) if values else None
def pct(values, fraction): return sorted(values)[min(len(values)-1, math.ceil(len(values)*fraction)-1)]
def gaps(row):
    values=row['foreground_gap_samples']
    return {key: values[-1][key]-values[0][key] for key in ('over_10ms','ingress_over_10ms')}
def service(rows):
    latencies=[v for s in rows for v in s['status_latency_ms']['samples']]
    result={'windows':len(rows), 'polling_hz':20, 'status_rtt_ms':{'count':len(latencies),'p50':pct(latencies,.5),'p95':pct(latencies,.95),'p99':pct(latencies,.99),'maximum':max(latencies)},
            'poll_window_gaps':{k:sum(gaps(s)[k] for s in rows) for k in ('over_10ms','ingress_over_10ms')},
            'boundary_description_gap_deltas':{k:sum(s['description_after'][k]-s['description_before'][k] for s in rows) for k in ('foreground_over_10ms','ingress_over_10ms')},
            'cumulative_high_watermarks_include_setup':{k:max(s['description_after'][k] for s in rows) for k in ('render_max_job_us','render_epoch_max_us','foreground_max_gap_us','ingress_max_gap_us','main_stack_peak_bytes','worker_stack_peak_bytes')},
            'steady_heap_growth_windows':sum(len({h['heap'] for h in s['heap_samples']})>1 for s in rows),
            'maximum_cumulative_heap_peak':max(h['heap_peak'] for s in rows for h in s['heap_samples'])}
    return result
def performance(rows, layer):
    layers=[s['layers'][layer] for s in rows]
    return {'render_us':stats([l['mean_render_us'] for l in layers]),'completed_per_second':stats([l['updates_per_second'] for l in layers]),
            'distinct_presentations_per_second':stats([(l['after']['distinct_presentations']-l['before']['distinct_presentations'])/s['seconds'] for s,l in zip(rows,layers)]),
            'physical_presentations_per_second':stats([s['presentations_per_second'] for s in rows]),
            'steady_heap_bytes':sorted({h['heap'] for s in rows for h in s['heap_samples']}),
            'plan_bytes':sorted({s['memory']['map_plan_bytes'] for s in rows if 'memory' in s}),
            'setup_ms':stats([s.get('setup_ms') for s in rows]),'service':service(rows)}

raw={p.name:read(p) for p in sorted(RUN.glob('*.json'))}
required=['numeric-1-main.json','numeric-1-replay.json','numeric-1-math.json','numeric-1-heavy.json','numeric-1-faults.json','numeric-2-main.json','numeric-2-replay.json','numeric-2-math.json','numeric-2-sizes.json','numeric-2-faults.json','numeric-2-heavy-replay.json','numeric-2-heavy.json']
assert all(raw[n].get('passed') for n in required)
assert raw['restoration.json']['passed']
assert len(raw['settled-rainbow.json']['samples'])==5
controls=collections.defaultdict(list)
numeric=collections.defaultdict(list)
for name,d in raw.items():
    for s in d.get('samples',[]):
        if name.startswith('control-'):
            variant=name.split('-')[2]
            case=s.get('name','rainbow')
            for layer in s['layers']: controls[(case,layer,variant)].append(s)
        elif name.startswith('numeric-'):
            workers=s['description_after']['render_workers']
            for layer in s['layers']: numeric[(workers,s['case'],s['pixels'],s.get('variant','mixed'),layer)].append(s)

summary={'schema':'lightvm.numeric-validation.s234.v1','date':'2026-10-22','branch':'codex/core-numeric-foundation',
         'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
         'scope':'S2-S4, attached Pico W; S5 and the complete S6 multi-board matrix remain separate',
         'measurement_notes':['Render cost is instrumented render_total_us divided by completed contributions, not optical output FPS or a sum of both CPU cores.',
          'Five matched controls and five scalar/bulk pairs for each primary workload and worker count; additional workloads are single screens.',
          'Poll-window gaps exclude full DESCRIPTION boundary queries; cumulative high-watermarks include uploads, admission, synchronous FRAME replay and startup.',
          'One-worker initial 512 KiB storage build was rejected at upload and excluded; corrected build uses the original 1 MiB storage layout.',
          'Startup Rainbow has one roughly 54 ms ingress gap on both baseline and candidate; settled follow-up separates that inherited behavior from kernel timing.'],
         'native_math':{k:v for k,v in raw['math.json'].items() if k!='raw_results'},'controls':[], 'numeric':[], 'correctness':{}, 'faults':{}, 'service':{},
         'restoration':raw['restoration.json']}
for (case,layer) in sorted({k[:2] for k in controls}):
    modes={v:performance(controls[case,layer,v],layer) for v in ('baseline','candidate')}
    assert all(len(controls[case,layer,v])==5 for v in modes)
    change=100*(modes['candidate']['render_us']['median']/modes['baseline']['render_us']['median']-1) if all(m['render_us'] for m in modes.values()) else None
    summary['controls'].append({'case':case,'layer':layer,**modes,'median_change_percent':change})
for (workers,case,pixels,variant,layer),rows in sorted(numeric.items()):
    summary['numeric'].append({'workers':workers,'case':case,'pixels':pixels,'variant':variant,'layer':layer,**performance(rows,layer)})
for workers in (1,2):
    replay=[r for n in required if n.startswith(f'numeric-{workers}-') for r in raw[n].get('replays',[])]
    assert all(r['equal'] for r in replay)
    summary['correctness'][str(workers)]={'pairs':len(replay),'frames_per_pair':5,'passed':True,'cases':sorted({r['case'] for r in replay}),'pixel_counts':sorted({r['pixels'] for r in replay})}
    summary['faults'][str(workers)]={k:v for k,v in raw[f'numeric-{workers}-faults.json'].items() if k not in ('source','oversized_source','description')}
    summary['service'][f'numeric_{workers}']=service([s for n in required if n.startswith(f'numeric-{workers}-') for s in raw[n].get('samples',[])])
for variant in ('baseline','candidate'):
    summary['service']['controls_'+variant]=service([s for n,d in raw.items() if n.startswith('control-') and ('-'+variant+'-') in n for s in d['samples']])
summary['service']['settled_rainbow']=service(raw['settled-rainbow.json']['samples'])

builds={'pico_w_two':'/private/tmp/lightvm-s1-pico-w','pico_w_one':'/private/tmp/lightvm-s234-pico-single','pico2_w':'/private/tmp/lightvm-s1-pico2-w','pico_minimal':'/private/tmp/lightvm-s1-pico-minimal','esp32_s3':'/private/tmp/lightvm-s234-esp32s3','host':'/private/tmp/lightvm-s1-host'}
summary['builds']={}
entries={}
def add(path,name): entries[name]=path.read_bytes()
for label,folder in builds.items():
    path=Path(folder);row={'artifacts':{},'configuration':{}}
    for name in ('lightvm.uf2','lightvm.elf','lightvm.bin','lightvm','lightvm_receiver','test_platform','numeric_probe.uf2','numeric_probe.elf'):
        p=path/name
        if p.exists():row['artifacts'][name]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
    for line in (path/'CMakeCache.txt').read_text().splitlines():
        if line.startswith(('LIGHTVM_','CMAKE_C_COMPILER:','CMAKE_BUILD_TYPE:','PICO_BOARD:','CMAKE_C_FLAGS','IDF_TARGET:')) and '=' in line:
            key,value=line.split('=',1);row['configuration'][key]=value
    if (path/'stack-paths.json').exists():
        stack=read(path/'stack-paths.json');row['stack_report']={k:stack[k] for k in ('software_gate_passed','hardware_validated','main','worker','elf_sha256','callgraph_sha256')}
        add(path/'stack-paths.json','builds/'+label+'/stack-paths.json')
    if (path/'CMakeFiles/lightvm.dir/flags.make').exists():add(path/'CMakeFiles/lightvm.dir/flags.make','builds/'+label+'/flags.make')
    if (path/'CMakeFiles/lightvm_core.dir/flags.make').exists():add(path/'CMakeFiles/lightvm_core.dir/flags.make','builds/'+label+'/core-flags.make')
    summary['builds'][label]=row
for p in sorted(RUN.glob('*.json')):add(p,'hardware/'+p.name)
for p in sorted(RUN.glob('*flash.log')):add(p,'hardware/'+p.name)
for p in sorted(Path('/private/tmp').glob('lightvm-s234-host-*.json')):add(p,'host/'+p.name)
logs=['python-final','native-final','sanitize-final','bulk-final','bulk-sanitize-final','web-final','web-build','pico-w-range-build','pico2-w-range-build','pico-minimal-range-build','single-storage-build','esp-final-build']
for name in logs:add(Path('/private/tmp/lightvm-s234-'+name+'.log'),'logs/'+name+'.log')
for p in sorted(Path('/private/tmp/lightvm-s234-controls').glob('*.json')):add(p,'preliminary/'+p.name)
for label in ('control','numeric'):
    for p in sorted(Path('/private/tmp/lightvm-s234-'+label+'-packages').iterdir()):
        if p.is_file():add(p,'packages/'+label+'/'+p.name)
for name in ('lightvm-s234-final-run.py','lightvm-s234-resume-run.py','verify-lightvm-s234-restoration.py','aggregate-lightvm-s234.py'):
    path=Path('/private/tmp')/name
    if path.exists():add(path,'campaign/'+name)
for name in ('lightvm-s234-final-run.log','lightvm-s234-resume-run.log'):
    add(Path('/private/tmp')/name,'logs/'+name)
add(Path('/private/tmp/lightvm-s1-pico-w/CMakeFiles/lightvm_core.dir/src/portable_map.c.su'),'builds/pico_w_two/portable_map.c.su')

# All result JSON is tool-generated; reject accidental credential-shaped fields.
def check_keys(value):
    if isinstance(value,dict):
        for k,v in value.items():
            assert not any(s in k.lower() for s in ('password','secret','credential','ssid','access_token')), k
            check_keys(v)
    elif isinstance(value,list):
        for v in value:check_keys(v)
for name,data in entries.items():
    if name.endswith('.json'):check_keys(json.loads(data))

source_names=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=ROOT,text=True).splitlines()
source_identity={}
for name in sorted(set(source_names)):
    path=ROOT/name
    if path.is_file() and not path.is_symlink() and (name.startswith(('src/','lightvm/','cmake/','platforms/','tests/','tools/','web/src/')) or name in ('CMakeLists.txt','docs/design/numeric-operations.json')):
        source_identity[name]=sha(path.read_bytes())
summary['source_sha256']=source_identity
summary['pico_map_memory_layout']={'evidence':'Arm ELF DWARF and portable_map.c.su from final two-worker build','plan_header_bytes':48,'plan_instruction_bytes':8,'maximum_plan_bytes':1072,'task_bytes':576,'tasks_per_invocation':2,'invariants_bytes_per_lane':512,'task_values_bytes_included':512,'gcc_stack_frames_bytes':{'pbc_map_run':1288,'map_pixels':584,'analyze':2760}}
summary_bytes=(json.dumps(summary,indent=2)+'\n').encode()
(DEST/(PREFIX+'.json')).write_bytes(summary_bytes)
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    for name,data in sorted(entries.items()):
        member=tarfile.TarInfo(name);member.size=len(data);member.mtime=0;member.mode=0o644
        archive.addfile(member,io.BytesIO(data))
compressed=gzip.compress(buffer.getvalue(),compresslevel=9,mtime=0)
archive_name=PREFIX+'-raw.tar.gz';(DEST/archive_name).write_bytes(compressed)
manifest={'schema':'lightvm.evidence-manifest.v1','archive':{'path':archive_name,'bytes':len(compressed),'sha256':sha(compressed)},
          'summary':{'path':PREFIX+'.json','bytes':len(summary_bytes),'sha256':sha(summary_bytes)},
          'members':{n:{'bytes':len(d),'sha256':sha(d)} for n,d in sorted(entries.items())}}
(DEST/(PREFIX+'-manifest.json')).write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'summary_bytes':len(summary_bytes),'archive_bytes':len(compressed),'members':len(entries),'controls':len(summary['controls']),'numeric':len(summary['numeric']),'correctness':summary['correctness'],'service':summary['service']},indent=2))
