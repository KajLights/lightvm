import math
import random
from array import array
from lightvm import profile,init,render,rgb,fixed,fixed_from_bits,FixedArray
profile("animation")
@init
def setup(ctx,runtime):
 ctx.exponents=array('f',[0.5,1.0,2.0,4.0])
 ctx.phases=array('f',[0.0,0.125,0.25,0.5,0.75,0.875])
 ctx.last=0.0
@render
def draw(ctx,runtime,pixels):
 value=0.0
 offset=int(runtime.time*0.0)
 for i in range(pixels.count):
  angle=(2.0*3.1415927410125732)*ctx.phases[((i+offset)//4)%6]
  s=math.sin(angle)
  value=math.pow(abs(s),ctx.exponents[i%4])
  red=int(value*255.0) if s<0.0 else 0
  blue=0 if s<0.0 else int(value*255.0)
  pixels[i]=rgb(red,20,blue)
 ctx.last=value
