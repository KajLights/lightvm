import math
import random
from array import array
from lightvm import profile,init,render,rgb,fixed,fixed_from_bits,FixedArray
profile("animation")
@init
def setup(ctx,runtime):
 ctx.value=0
 ctx.table=array('i',[0,1,2])
 random.seed(12345)
@render
def draw(ctx,runtime,pixels):
 for i in range(pixels.count):
  pixels[(i+1)%pixels.count]=rgb(i%255,0,0)
