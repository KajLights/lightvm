import math
import random
from array import array
from lightvm import profile,init,render,rgb,fixed,fixed_from_bits,FixedArray
profile("animation")
@init
def setup(ctx,runtime):
 ctx.table=array('I',[0]*17)
 for j in range(17):
  ctx.table[j]=(((j*73+17)%256)<<16)|(((j*37+11)%256)<<8)|((j*19+5)%256)
@render
def draw(ctx,runtime,pixels):
 offset=0+int(runtime.time*0.0)
 for i in range(pixels.count):
  color=ctx.table[(i+offset)%17]
  pixels[i]=rgb((color>>16)&255,(color>>8)&255,color&255)
