import math
import random
from array import array
from lightvm import profile,init,render,rgb,fixed,fixed_from_bits,FixedArray
profile("animation")
@render
def draw(ctx,runtime,pixels):
 for i in range(pixels.count):
  x=i
  x=x+1
  x=x+1
  x=x+1
  x=x+1
  x=x+1
  x=x+1
  x=x+1
  x=x+1
  x=x+1
  x=x+1
  x=x+1
  x=x+1
  x=x+1
  x=x+1
  x=x%255
  pixels[i]=rgb(x,0,0)
