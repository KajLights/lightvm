import math
import random
from array import array
from lightvm import profile,init,render,rgb,fixed,fixed_from_bits,FixedArray
profile("animation")
@init
def setup(ctx,runtime):
 ctx.x=fixed_from_bits(52429)
 ctx.v=fixed(0)
 ctx.step=0
 ctx.impulses=array('i',[0,1311,-1311,655,-655])
 ctx.positions=FixedArray(5)
 ctx.velocities=FixedArray(5)
@render
def draw(ctx,runtime,pixels):
 ctx.v=(ctx.v+fixed_from_bits(ctx.impulses[ctx.step%5]))*fixed_from_bits(58982)
 ctx.x=min(fixed(1),max(fixed_from_bits(36045),ctx.x+ctx.v*fixed_from_bits(22938)))
 ctx.positions[ctx.step%5]=ctx.x
 ctx.velocities[ctx.step%5]=ctx.v
 ctx.step+=1
 for i in range(pixels.count):
  shade=ctx.x if i%2==0 else fixed(1)-ctx.x
  pixels[i]=rgb(int(shade*fixed(255)),10,30)
