import math
import random
from array import array
from lightvm import profile,init,render,rgb,fixed,fixed_from_bits,FixedArray
profile("animation")
@init
def setup(ctx,runtime):ctx.last=fixed(0)
@render
def draw(ctx,runtime,pixels):
 p=fixed(0)
 phase=fixed_from_bits(1)+fixed(runtime.time*0.0)
 for i in range(pixels.count):
  p=(phase+fixed(i)/fixed(pixels.count))%fixed(1)
  envelope=fixed(2)*p if p<fixed(0.5) else fixed(2)*(fixed(1)-p)
  pixels[i]=rgb(int(fixed(255)*envelope),0,0)
 ctx.last=p
