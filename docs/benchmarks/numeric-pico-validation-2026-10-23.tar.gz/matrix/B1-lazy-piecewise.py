import math
import random
from array import array
from lightvm import profile,init,render,rgb,fixed,fixed_from_bits,FixedArray
profile("animation")
from lightvm.easing import circular_out
@init
def setup(ctx,runtime):ctx.table=array('i',[3,7,11])
@render
def draw(ctx,runtime,pixels):
 for i in range(pixels.count):
  x=i/float(pixels.count)
  shade=0
  if i<0:shade=ctx.table[999]
  else:
   if x<0.5:shade=int(circular_out(x)*255.0)
   else:shade=ctx.table[i%3]
  pixels[i]=rgb(shade,0,0)
