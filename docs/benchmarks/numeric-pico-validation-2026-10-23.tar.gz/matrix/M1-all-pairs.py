import math
import random
from array import array
from lightvm import profile,init,render,rgb,fixed,fixed_from_bits,FixedArray
profile("animation")
@init
def setup(ctx,runtime):
 ctx.u1=array('f',[0.0000152587890625,0.125,0.5,0.9999847412109375])
 ctx.u2=array('f',[0.0,0.125,0.5,0.875])
 ctx.x=0.0
 ctx.y=0.0
@render
def draw(ctx,runtime,pixels):
 x=0.0
 y=0.0
 offset=int(runtime.time*0.0)
 for i in range(pixels.count):
  radius=math.sqrt(-2.0*math.log(ctx.u1[(i+offset)%4]))
  angle=(2.0*3.1415927410125732)*ctx.u2[(i//4)%4]
  x=radius*math.cos(angle)
  y=radius*math.sin(angle)
  pixels[i]=rgb(int(128.0+20.0*x),int(128.0+20.0*y),40)
 ctx.x=x
 ctx.y=y
