import math
from lightvm import profile,render,rgb,fixed,fixed_sqrt
profile("animation")
@render
def draw(ctx,runtime,pixels):
 phase=fixed(runtime.time*0.0)
 for i in range(pixels.count):
  base=fixed(i%17+1)/fixed(32)+phase
  x=base
  x=x%fixed(0.1875)
  x=x%fixed(0.1875)
  x=x%fixed(0.1875)
  x=x%fixed(0.1875)
  x=x%fixed(0.1875)
  x=x%fixed(0.1875)
  x=x%fixed(0.1875)
  x=x%fixed(0.1875)
  pixels[i]=rgb(int(x*fixed(255))%256,0,0)
