import math
from lightvm import profile,render,rgb,fixed,fixed_sqrt
profile("animation")
@render
def draw(ctx,runtime,pixels):
 t=runtime.time*0.0+0.125
 for i in range(pixels.count):
  x=0.0
  if i%2==0:
   x=math.exp(t)
   x=math.exp(t)
   x=math.exp(t)
   x=math.exp(t)
   x=math.exp(t)
   x=math.exp(t)
   x=math.exp(t)
  else:
   x=math.exp(t+0.125)
   x=math.exp(t+0.125)
   x=math.exp(t+0.125)
   x=math.exp(t+0.125)
   x=math.exp(t+0.125)
   x=math.exp(t+0.125)
   x=math.exp(t+0.125)
  pixels[i]=rgb(int(x),0,0)
