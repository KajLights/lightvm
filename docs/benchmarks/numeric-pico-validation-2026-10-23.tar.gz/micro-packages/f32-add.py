import math
from lightvm import profile,render,rgb,fixed,fixed_sqrt
profile("animation")
@render
def draw(ctx,runtime,pixels):
 phase=float(runtime.time*0.0)
 for i in range(pixels.count):
  base=float(i%17+1)/float(32)+phase
  x=base
  x=x+base
  x=x+base
  x=x+base
  x=x+base
  x=x+base
  x=x+base
  x=x+base
  x=x+base
  pixels[i]=rgb(int(x*float(255))%256,0,0)
