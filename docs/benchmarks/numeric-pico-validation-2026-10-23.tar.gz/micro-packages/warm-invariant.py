import math
from lightvm import profile,render,rgb,fixed,fixed_sqrt
profile("animation")
@render
def draw(ctx,runtime,pixels):
 t=runtime.time*0.0+0.125
 for i in range(pixels.count):
  x=math.exp(t)
  pixels[i]=rgb(int(x),i%255,0)
