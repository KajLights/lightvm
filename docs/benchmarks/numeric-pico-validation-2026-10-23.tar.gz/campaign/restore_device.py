"""Restore original user-visible state and verify original program identities."""
import sys,json,time,hashlib
from pathlib import Path
r=Path('/tmp/lightvm-pico-tuning-2026-10-23');repo=Path('/Users/kws/.codex/worktrees/core-numeric-foundation/lightvm');sys.path.insert(0,str(repo/'tools'))
from client import Client,SerialTransport
before=json.loads((r/'device-before-private.json').read_text());original=before['config'];c=Client(SerialTransport('/dev/cu.usbmodem11401'),timeout=120)
try:
 programs=c.programs();old={(p['name'],p['type']):p for p in before['programs']}
 actual={(p['name'],p['type']):p for p in programs}
 assert set(actual)==set(old),('unexpected/missing programs',set(actual)^set(old))
 assert all(actual[k]['crc32']==v['crc32'] and actual[k]['size']==v['size'] for k,v in old.items())
 if c.get_config()!=original:
  c.configure({'schema':'lightvm.config','outputs':[]});c.configure(original)
 out=before['description']['outputs'][0];light=out['light'];preset=out['selected_preset'] or light['preset']
 c.recall_preset(preset,'lights');c.set_light(power=light['power'],brightness=light['brightness'],color=light['color'],preset=preset,output='lights')
 time.sleep(2)
 after=c.describe();state=c.light_state('lights');status=c.status_fields(output='lights')
 assert c.get_config()==original
 assert after['render_workers']==2 and after['cpu_clock_hz']==125000000,after['render_workers']
 for key in ('power','brightness','color','preset'):assert state[key]==light[key],(key,state[key],light[key])
 assert not after['boot_error'] and status['animation_error']=='-'
 result={'passed':True,'firmware_sha256':hashlib.sha256((r/'tuned5-two/lightvm.uf2').read_bytes()).hexdigest(),'original_program_identities_retained':True,'programs':programs,'active_configuration_restored':True,'saved_configuration_matches_initial_active':c.get_config(saved=True)==original,'light_restored':{k:state[k] for k in ('power','brightness','color','preset')},'description':after,'status':status,'temporary_programs_removed':True,'network_configuration_written':False}
 (r/'restoration.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('description','programs','status')}))
finally:c.close()
