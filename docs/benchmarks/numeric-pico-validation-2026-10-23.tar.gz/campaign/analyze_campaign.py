"""Summarize raw samples without removing failures or boundary diagnostics."""
import hashlib,json,statistics
from pathlib import Path
R=Path('/tmp/lightvm-pico-tuning-2026-10-23')
def read(name):return json.loads((R/name).read_text())
def dist(values):
 values=sorted(x for x in values if x is not None)
 return None if not values else {'count':len(values),'median':statistics.median(values),'min':values[0],'max':values[-1]}
def steady(row):
 values=row.get('foreground_gap_samples',[])
 return {key:values[-1][key]-values[0][key] for key in ('over_10ms','ingress_over_10ms')} if values else {}
def stats(rows,layer='A/layer0'):
 return {'render_us':dist([r['layers'][layer]['mean_render_us'] for r in rows]),'updates_hz':dist([r['layers'][layer]['updates_per_second'] for r in rows]),'presentations_hz':dist([r['presentations_per_second'] for r in rows]),'usb_p95_ms':dist([r['status_latency_ms']['p95'] for r in rows]),'usb_p99_ms':dist([r['status_latency_ms']['p99'] for r in rows]),'steady_service_deltas':[steady(r) for r in rows],'heap_current_ranges':[[min(h['heap'] for h in r['heap_samples']),max(h['heap'] for h in r['heap_samples'])] for r in rows]}
out={'schema':'lightvm.validation.numeric-pico','date':'2026-10-23','reviewed_commit':'2459b5b','scope':'RP2040 measurements; network-control service and other physical boards remain open','regression':[],'measurements':{},'services':{}}
samples=read('final-two-regression.json')['samples']
for case in dict.fromkeys(r['case'] for r in samples):
 rows=[r for r in samples if r['case']==case]
 for layer in rows[0]['layers']:
  entry={'case':case,'layer':layer}
  for variant in ('baseline','candidate'):entry[variant]=stats([r for r in rows if r['variant']==variant],layer)
  a=entry['baseline']['render_us'];b=entry['candidate']['render_us'];entry['change_percent']=100*(b['median']/a['median']-1) if a and b else None
  entry['disposition']='uncontrolled random population; diagnostic only' if case=='control-stars' else 'cached output; no timed renders' if not a else 'within 5% median regression gate' if entry['change_percent']<=5 else 'FAIL: median regression exceeds 5%'
  out['regression'].append(entry)
all_final=[]
for label in ('final-two','final-one'):
 for mode in ('throughput','small','micro'):
  path=R/(label+'-'+mode+'.json')
  if not path.exists():continue
  raw=read(path.name);samples=raw['samples'];result={'completed':raw.get('passed',False),'sample_count':len(samples),'groups':[],'mixed':[{'pixels':r['pixels'],'programs':r['programs'],'presentations_hz':r['presentations_per_second'],'layers':{k:{kk:vv for kk,vv in v.items() if kk in ('mean_render_us','updates_per_second','updates')} for k,v in r['layers'].items()},'steady_deltas':steady(r)} for r in samples if r['case']=='mixed']}
  all_final+=samples
  for count,case in dict.fromkeys((r['pixels'],r['case']) for r in samples if r['case']!='mixed'):
   rows=[r for r in samples if r['pixels']==count and r['case']==case];entry={'pixels':count,'case':case}
   for variant in ('scalar','bulk'):entry[variant]=stats([r for r in rows if r['variant']==variant])
   a=entry['scalar']['render_us'];b=entry['bulk']['render_us'];entry['bulk_reduction_percent']=100*(1-b['median']/a['median']) if a and b else None
   result['groups'].append(entry)
  out['measurements'][label+'-'+mode]=result
for p in sorted(R.glob('*service.json')):
 if p.name.startswith('post-memory'):continue
 raw=read(p.name);entry={k:raw[k] for k in ('firmware_sha256','label','scene','polling_hz','errors','latencies','passed','transport_passed','service_gate_passed') if k in raw}
 for phase in ('idle','loaded'):
  if phase not in raw:continue
  row=raw[phase];entry[phase]={'steady_deltas':steady(row),'usb_latency_ms':{k:v for k,v in row['status_latency_ms'].items() if k!='samples'},'layers':{k:{kk:vv for kk,vv in v.items() if kk in ('mean_render_us','updates_per_second')} for k,v in row['layers'].items()}}
 out['services'][p.name]=entry
for name in ('final-two-matrix','final-two-wire','final-one-wire','final-two-runtime','final-one-runtime','native-math-pico','host-final-matrix'):
 p=R/(name+'.json')
 if p.exists():
  raw=read(p.name);out[name]={k:raw[k] for k in ('passed','cases','firmware_sha256','corpus_sha256') if k in raw and not isinstance(raw[k],list)}
  for key in ('replays','frames','rejections','cases'):
   if isinstance(raw.get(key),list):out[name][key+'_count']=len(raw[key])
mem=read('final-two-memory.json')
stars=R/'final-stars-population-regression.json'
if stars.exists():
 raw=read(stars.name);entry={'completed':raw.get('passed',False),'settings':raw['scene_settings'],'warmup_seconds':raw['warmup_seconds']}
 for variant in ('baseline','candidate'):entry[variant]=stats([r for r in raw['samples'] if r['variant']==variant])
 a=entry['baseline']['render_us'];b=entry['candidate']['render_us']
 entry['change_percent']=100*(b['median']/a['median']-1) if a and b else None
 entry['within_5_percent']=entry['completed'] and entry['change_percent']<=5
 out['stars_population_control']=entry
out['memory']={'checks_passed':mem['passed'],'initial_cleanup_failed':True,'recovery':read('memory-recovery.json'),'cancellations':len(mem['cancellations']),'rejections':len(mem['rejections']),'points':[{'label':p['label'],'heap':int(p['status']['heap']),'heap_peak':int(p['status']['heap_peak'])} for p in mem['samples']]}
keys=('render_max_job_us','render_epoch_max_us','main_stack_peak_bytes','worker_stack_peak_bytes')
all_final+=[r for r in read('final-two-regression.json')['samples'] if r['variant']=='candidate']
all_final.append({'description_after':read('final-two-matrix.json')['description_after']})
out['observed_highwaters']={k:max((r['description_after'].get(k,0) for r in all_final),default=0) for k in keys}
selected={hashlib.sha256((R/f).read_bytes()).hexdigest() for f in ('tuned5-two/lightvm.uf2','final-one/lightvm.uf2')}
def highwater(value):
 if isinstance(value,dict):
  for k in keys:
   if isinstance(value.get(k),(int,float)):out['observed_highwaters'][k]=max(out['observed_highwaters'][k],value[k])
  for v in value.values():highwater(v)
 elif isinstance(value,list):
  for v in value:highwater(v)
for p in R.glob('*.json'):
 if 'private' in p.name or p.name=='campaign-summary.json':continue
 raw=read(p.name)
 if isinstance(raw,dict) and raw.get('firmware_sha256') in selected:highwater(raw)
 if isinstance(raw,dict) and raw.get('firmwares',{}).get('candidate') in selected:
  highwater([r for r in raw['samples'] if r['variant']=='candidate'])

out['firmwares']={name:hashlib.sha256((R/file).read_bytes()).hexdigest() for name,file in [('preserved_baseline','device-baseline.uf2'),('committed_review','committed-two.uf2'),('final_two','tuned5-two/lightvm.uf2'),('final_one','final-one/lightvm.uf2')]}
(R/'campaign-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'regression_cases':len(out['regression']),'measurements':{k:v['sample_count'] for k,v in out['measurements'].items()},'highwaters':out['observed_highwaters']}))
