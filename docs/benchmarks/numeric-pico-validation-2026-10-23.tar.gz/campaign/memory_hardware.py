"""Observe old/candidate/transition heap peaks and cancellation on a fresh Pico boot."""
import argparse,hashlib,json,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--root',type=Path,required=True);p.add_argument('--port',required=True);p.add_argument('--firmware',type=Path,required=True);p.add_argument('--result',type=Path,required=True);a=p.parse_args()
sys.path[:0]=[str(a.repo),str(a.repo/'tools')]
from client import Client,SerialTransport,MANAGE,ProtocolError
from lightvm.portable import PortableCompiler
c=Client(SerialTransport(a.port),timeout=120);original=c.get_config();created=[]
r={'firmware_sha256':hashlib.sha256(a.firmware.read_bytes()).hexdigest(),'description_before':c.describe(),'samples':[],'cancellations':[],'rejections':[],'scope':'VM heap high-water and current use; native reservations are reported separately by build/stack gates.'}
def checkpoint():a.result.write_text(json.dumps(r,indent=2)+'\n')
def point(label):
 row={'label':label,'status':c.status_fields(output='numeric'),'description':c.describe()};r['samples'].append(row);checkpoint();return int(row['status']['heap'])
def activate_raw(name):
 state=c.program_state(output='numeric',layer='layer0');composition=c.composition(output='numeric')
 fields={'op':'composition_layer_activate','name':name,'output':'numeric','slot':'A','layer':'layer0','expected_revision':composition['revision'],'expected_generation':state['generation']}
 c.require_ok(c.command(MANAGE,json.dumps(fields,separators=(',',':')).encode()))
 return json.loads(c.data_reply).get('operation')
try:
 names=('pm_old','pm_next','pm_heavy','pm_huge','pm_cross')
 if {x['name'] for x in c.programs()}.intersection(names):raise RuntimeError('memory test names already exist')
 data={'pm_old':(a.root/'matrix/G1-l64-o-19-bulk.lbc').read_bytes(),'pm_next':(a.root/'matrix/B2-body128-bulk.lbc').read_bytes()}
 for name,source in [('pm_heavy','from lightvm import profile,init,render,rgb\nprofile("animation")\n@init\ndef setup(ctx,runtime):\n ctx.x=0.0\n for i in range(20000):ctx.x=(ctx.x+0.03125)*0.9375\n@render\ndef draw(ctx,runtime,pixels):\n for i in range(pixels.count):pixels[i]=rgb(i%255,17,87)\n'),('pm_huge','from lightvm import profile,init,render,FixedArray\nprofile("animation")\n@init\ndef setup(ctx,runtime):ctx.values=FixedArray(65535)\n@render\ndef draw(ctx,runtime,pixels):pass\n'),('pm_cross',(a.repo/'examples/transitions/crossfade.py').read_text())]:data[name]=PortableCompiler(source).compile()[0]
 r['packages']={k:hashlib.sha256(v).hexdigest() for k,v in data.items()}
 for name,value in data.items():c.save_program(name,value);created.append(name)
 c.configure({'schema':'lightvm.config','outputs':[]});c.configure({'schema':'lightvm.config','outputs':[{'id':'numeric','type':'ws2812b','config':{'pin':'GP16','count':1024,'brightness_limit':32}}]})
 c.configure_composition([{'id':'layer0','program':'pm_old'}],output='numeric');stable=point('old A live')
 generation=c.program_state(output='numeric',layer='layer0')['generation']
 for trial in range(10):
  op=activate_raw('pm_heavy');observations=[];deadline=time.monotonic()+10
  if not op:raise RuntimeError('heavy preparation unexpectedly completed synchronously')
  while op['stage'] not in ('initialise','first_render') and not op['terminal']:
   observations.append({'operation':op,'status':c.status_fields(output='numeric')});op=c.operation(op['boot_id'],op['id'])
   if time.monotonic()>deadline:raise RuntimeError('candidate did not initialise')
  observations.append({'operation':op,'status':c.status_fields(output='numeric')})
  cancelled=c.operation(op['boot_id'],op['id'],cancel=True)
  while not cancelled['terminal'] and time.monotonic()<deadline:cancelled=c.operation(cancelled['boot_id'],cancelled['id'])
  after=c.program_state(output='numeric',layer='layer0');heap=int(c.status_fields(output='numeric')['heap'])
  assert cancelled['stage']=='cancelled' and after['generation']==generation and heap==stable,(cancelled,heap,stable)
  r['cancellations'].append({'trial':trial+1,'observations':observations,'operation':cancelled,'heap_after':heap,'generation_retained':True});checkpoint()
 point('old A after ten cancelled candidates')
 c.activate('pm_next',output='numeric',layer='layer0');point('new A after atomic replacement')
 c.configure_composition([{'id':'layer0','program':'pm_old'}],output='numeric',slot='B');point('A plus B live')
 c.select_transition('pm_cross',output='numeric');c.set_progress(50,output='numeric');steady=point('A plus B plus program transition')
 before=c.program_state(output='numeric',layer='layer0')['generation'];observed=[]
 for _ in range(20):observed.append(int(c.status_fields(output='numeric')['heap']));time.sleep(.05)
 assert set(observed)=={steady},observed
 r['steady_heap_samples']=observed
 for trial in range(10):
  try:c.activate('pm_huge',output='numeric',layer='layer0')
  except ProtocolError as error:reason=str(error)
  else:raise AssertionError('oversized candidate admitted')
  after=c.program_state(output='numeric',layer='layer0');heap=int(c.status_fields(output='numeric')['heap'])
  assert after['generation']==before and heap==steady,(heap,steady)
  r['rejections'].append({'trial':trial+1,'reason':reason,'heap':heap,'generation_retained':True});checkpoint()
 point('transition after ten rejected candidates');r['description_after']=c.describe();r['passed']=True;checkpoint();print(json.dumps({'passed':True,'cancellations':len(r['cancellations']),'rejections':len(r['rejections']),'heaps':[(x['label'],x['status']['heap'],x['status']['heap_peak']) for x in r['samples']]}),flush=True)
finally:
 try:
  c.configure({'schema':'lightvm.config','outputs':[]});c.configure(original)
  for name in created:c.delete_program(name)
  checkpoint()
 finally:c.close()
