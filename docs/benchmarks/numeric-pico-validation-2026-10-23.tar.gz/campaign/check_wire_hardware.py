"""Independent wire admission and frame oracle on the selected Pico W."""
import argparse,hashlib,json,struct,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--port',required=True);p.add_argument('--firmware',type=Path,required=True);p.add_argument('--result',type=Path,required=True);a=p.parse_args()
sys.path[:0]=[str(a.repo),str(a.repo/'tools'),str(a.repo/'tests/fixtures')]
from client import Client,SerialTransport,ProtocolError,FRAME,STOP
from lightvm.portable import PortableCompiler
import independent_emitter as emitter
sha=lambda b:hashlib.sha256(b).hexdigest()
c=Client(SerialTransport(a.port),timeout=120);created=[];original=c.get_config()
r={'firmware_sha256':sha(a.firmware.read_bytes()),'description_before':c.describe(),'frames':[],'rejections':[]}
def checkpoint():a.result.write_text(json.dumps(r,indent=2)+'\n')
try:
 existing={p['name'] for p in c.programs()}
 if existing.intersection(('pw_scalar','pw_bulk','pw_invalid')):raise RuntimeError('wire test program names exist')
 for bulk in (False,True):
  name='pw_bulk' if bulk else 'pw_scalar';data=emitter.emit(bulk);c.save_program(name,data);created.append(name)
  for count in (1,31,32,33,127,128,129,200,500,1024):
   c.configure({'schema':'lightvm.config','outputs':[]});c.configure({'schema':'lightvm.config','outputs':[{'id':'numeric','type':'ws2812b','config':{'pin':'GP16','count':count,'brightness_limit':32}}]})
   c.configure_composition([{'id':'layer0','program':name}],output='numeric');c.require_ok(c.command(STOP,output='numeric'));c.reset_program(output='numeric',layer='layer0');c.require_ok(c.command(FRAME,bytes(4),output='numeric'))
   fmt,image=c.snapshot(output='numeric',layer='layer0');image=bytes(image)
   assert image==emitter.expected_pixels(count),(bulk,count,fmt,len(image))
   r['frames'].append({'bulk':bulk,'pixels':count,'format':fmt,'sha256':sha(image),'package_sha256':sha(data)});checkpoint()
 baseline=c.program_state(output='numeric',layer='layer0');before=bytes(c.snapshot(output='numeric',layer='layer0')[1]);heap=int(c.status_fields(output='numeric')['heap'])
 invalid={k:v for k,v in emitter.corpus().items() if k.startswith('reject-')}
 alias=bytearray(emitter.emit(invalid='map-control-alias'));struct.pack_into('<I',alias,96+8*10+4,0);invalid['reject-empty-alias']=bytes(alias)
 for expr in ('min(0.0,-0.0)','max(-0.0,0.0)','math.sin(-0.0)'):
  src='import math\nfrom lightvm import profile,init,render\nprofile("animation")\n@init\ndef setup(ctx,runtime):ctx.x='+expr+'\n@render\ndef draw(ctx,runtime,pixels):pass\n'
  data,_=PortableCompiler(src).compile();invalid['floor-'+expr]=data.replace(b'"requires":"1.3.0"',b'"requires":"1.2.0"')
 for name,data in invalid.items():
  try:c.save_program('pw_invalid',data)
  except ProtocolError as error:reason=str(error)
  else:raise AssertionError(name+' was accepted')
  after=c.program_state(output='numeric',layer='layer0');now=int(c.status_fields(output='numeric')['heap'])
  assert after['generation']==baseline['generation'] and now==heap and bytes(c.snapshot(output='numeric',layer='layer0')[1])==before,name
  r['rejections'].append({'name':name,'package_sha256':sha(data),'reason':reason,'heap':now,'generation_retained':True,'frame_retained':True});checkpoint()
 r['description_after']=c.describe();r['passed']=True;checkpoint();print(json.dumps({'passed':True,'frames':len(r['frames']),'rejections':len(r['rejections'])}),flush=True)
finally:
 try:
  c.configure({'schema':'lightvm.config','outputs':[]});c.configure(original)
  for name in created:c.delete_program(name)
 finally:c.close()
