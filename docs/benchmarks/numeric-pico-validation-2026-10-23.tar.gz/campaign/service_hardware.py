"""Concurrent HTTP, WebSocket and authenticated MQTT load on temporary numeric scenes.

Credentials are read from a private file and never included in results.
"""
import argparse,hashlib,json,sys,threading,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--root',type=Path,required=True);p.add_argument('--port',required=True);p.add_argument('--firmware',type=Path,required=True);p.add_argument('--network',type=Path,required=True);p.add_argument('--label',required=True);p.add_argument('--seconds',type=float,default=30);p.add_argument('--transports',nargs='+',default=['http','websocket','mqtt'],choices=['http','websocket','mqtt']);p.add_argument('--scene',choices=['numeric','idle','color'],default='numeric');a=p.parse_args()
sys.path[:0]=[str(a.repo/'tools'),str(a.repo/'tests')]
from client import Client,SerialTransport,HttpTransport
from benchmark_saved_preset import sample,percentile
from benchmark_ha_hardware import Broker
from test_websocket import Wire
c=Client(SerialTransport(a.port),timeout=120);original=c.get_config();created=[];stop=threading.Event();threads=[];events={k:[] for k in a.transports};errors=[]
r={'firmware_sha256':hashlib.sha256(a.firmware.read_bytes()).hexdigest(),'label':a.label,'scene':a.scene,'polling_hz':{'usb':20,**{k:10 for k in a.transports}},'events':events,'errors':errors}
path=a.root/(a.label+'-service.json')
def checkpoint():path.write_text(json.dumps(r,indent=2)+'\n')
def observe(kind,make):
 other=None
 try:
  other=make()
  while not stop.is_set():
   began=time.monotonic();state=other.status_fields(output='lights');elapsed=time.monotonic()-began
   if state.get('animation_error')!='-':raise RuntimeError('animation fault during '+kind)
   events[kind].append({'elapsed_s':began-started,'latency_ms':elapsed*1000})
   stop.wait(max(0,.1-elapsed))
 except Exception as e:errors.append({'transport':kind,'error':str(e)})
 finally:
  if other:other.close()
def mqtt():
 broker=None
 try:
  broker=Broker(json.loads(a.network.read_text())['mqtt'],description['controller_id']);broker.pump(.2);n=0
  while not stop.is_set():
   brightness=64+n%128;n+=1;began=time.monotonic()
   event=broker.send({'state':'ON','brightness':brightness},{'state':'ON','brightness':brightness},timeout=10)
   event['elapsed_s']=began-started;events['mqtt'].append(event);stop.wait(max(0,.1-(time.monotonic()-began)))
 except Exception as e:errors.append({'transport':'mqtt','error':str(e)})
 finally:
  if broker:broker.close()
try:
 description=c.describe();network=c.network_status();deadline=time.monotonic()+60
 while not network['mqtt_connected'] and time.monotonic()<deadline:time.sleep(.25);network=c.network_status()
 r['network_status_before']=network
 if network['state']!='connected' or not network['mqtt_connected']:raise RuntimeError('configured network is not ready')
 url=f"http://{network['ip']}:{network['http_port']}"
 existing={x['name'] for x in c.programs()}
 if existing.intersection(('ps_gather','ps_math')):raise RuntimeError('service test names already exist')
 for name,file in [('ps_gather','G1-l64-o-19-bulk'),('ps_math','M1-all-pairs-bulk')]:
  data=(a.root/'matrix'/(file+'.lbc')).read_bytes();c.save_program(name,data);created.append(name)
 c.configure({'schema':'lightvm.config','outputs':[]})
 c.configure({'schema':'lightvm.config','outputs':[{'id':'lights','type':'ws2812b','config':{'pin':'GP16','count':500,'brightness_limit':32},'home_assistant':{'default_preset':'rainbow','presets':['rainbow','stars']}}]})
 if a.scene=='numeric':c.configure_composition([{'id':'layer0','program':'ps_gather'},{'id':'layer1','program':'ps_math'}],output='lights')
 elif a.scene=='color':c.configure_composition([{'id':'layer0','program':'color'}],output='lights')
 time.sleep(2)
 r['idle']=sample(c,'lights',10);r['before']=c.describe();checkpoint()
 started=time.monotonic()
 threads=[threading.Thread(target=observe,args=('http',lambda:Client(HttpTransport(url,timeout=5),timeout=5))),threading.Thread(target=observe,args=('websocket',lambda:Client(Wire(url),timeout=5))),threading.Thread(target=mqtt)]
 threads=[t for name,t in zip(['http','websocket','mqtt'],threads) if name in a.transports]
 for t in threads:t.start()
 r['loaded']=sample(c,'lights',a.seconds);stop.set()
 for t in threads:t.join(15)
 if any(t.is_alive() for t in threads):raise RuntimeError('network worker did not stop')
 r['after']=c.describe();r['network_status_after']=c.network_status();r['latencies']={k:{'count':len(v),'p95_ms':percentile([x['latency_ms'] for x in v],.95),'p99_ms':percentile([x['latency_ms'] for x in v],.99),'max_ms':max(x['latency_ms'] for x in v)} for k,v in events.items() if v}
 r['ingress_over_10ms_delta']=r['loaded']['description_after']['ingress_over_10ms']-r['loaded']['description_before']['ingress_over_10ms']
 r['foreground_over_10ms_delta']=r['loaded']['description_after']['foreground_over_10ms']-r['loaded']['description_before']['foreground_over_10ms']
 r['transport_passed']=not errors and all(events.values()) and r['network_status_after']['mqtt_connected'] and not r['network_status_after']['mqtt_error']
 r['steady_deltas']={phase:{key:rows[-1][key]-rows[0][key] for key in ('over_10ms','ingress_over_10ms')} for phase in ('idle','loaded') for rows in [r[phase]['foreground_gap_samples']]}
 r['service_gate_passed']=all(value==0 for value in r['steady_deltas']['loaded'].values())
 r['passed']=r['transport_passed'] and r['service_gate_passed'];checkpoint()
 if not r['passed']:raise RuntimeError('concurrent load incomplete; see recorded errors')
 print(json.dumps({'passed':r['passed'],'latencies':r['latencies'],'ingress_over_10ms_delta':r['ingress_over_10ms_delta'],'foreground_over_10ms_delta':r['foreground_over_10ms_delta']}),flush=True)
finally:
 stop.set()
 for t in threads:t.join(15)
 try:
  c.configure({'schema':'lightvm.config','outputs':[]});c.configure(original)
  for name in created:c.delete_program(name)
  checkpoint()
 finally:c.close()
