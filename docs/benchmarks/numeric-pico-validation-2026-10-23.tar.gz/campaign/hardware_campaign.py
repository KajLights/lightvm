"""Reproducible Pico W campaign. Temporary scenes; no saved configuration writes."""
import argparse,hashlib,json,statistics,subprocess,sys,time
from pathlib import Path
from types import SimpleNamespace
from serial.tools import list_ports
p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','regression','matrix','throughput','small','micro']);p.add_argument('--repo',type=Path,required=True);p.add_argument('--root',type=Path,required=True);p.add_argument('--port',default='/dev/cu.usbmodem11401');p.add_argument('--serial',default='E6614103E7236D37');p.add_argument('--firmware',type=Path);p.add_argument('--baseline',type=Path);p.add_argument('--picotool',type=Path);p.add_argument('--label',default='candidate');p.add_argument('--case',action='append');p.add_argument('--samples',type=int,default=5);p.add_argument('--seconds',type=float,default=3);p.add_argument('--stable-stars',action='store_true');args=p.parse_args()
sys.path[:0]=[str(args.repo),str(args.repo/'tools')]
from lightvm.portable import PortableCompiler
from client import Client,SerialTransport
from benchmark_saved_preset import sample
from benchmark_multicore import SOURCES
import benchmark_numeric
sha=lambda b:hashlib.sha256(b).hexdigest()
EMPTY={'schema':'lightvm.config','outputs':[]}
original=json.loads((args.root/'device-before-private.json').read_text())['config']
packages=args.root/'campaign-packages';packages.mkdir(exist_ok=True)

def prepare():
 sources={'map':(SOURCES['map'],True),'scalar':(SOURCES['scalar'],False),'draw':(SOURCES['draw'],True),'sprites':(SOURCES['sprites'],True)}
 for name in ('color','rainbow','stars','sweep'):sources['control-'+name]=((args.repo/f'examples/animations/{name}.py').read_text(),True)
 manifest={}
 for name,(source,optimize) in sources.items():
  data,meta=PortableCompiler(source,optimize=optimize).compile()
  (packages/(name+'.py')).write_text(source);(packages/(name+'.lbc')).write_bytes(data)
  manifest[name]={'source_sha256':sha(source.encode()),'bytecode_sha256':sha(data),'requires':meta['requires']}
 (packages/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 prefix='import math\nfrom lightvm import profile,render,rgb,fixed,fixed_sqrt\nprofile("animation")\n'
 micro={}
 for kind in ('q16','f32'):
  cast='fixed' if kind=='q16' else 'float'
  for op in ('base','add','mul','div','mod','sqrt'):
   operand=f'{cast}(1.125)' if op=='div' else 'base'
   operation={'base':'x','add':f'x+{operand}','mul':f'x*{operand}','div':f'x/{operand}','mod':f'x%{cast}(0.1875)','sqrt':'fixed_sqrt(x)' if kind=='q16' else 'math.sqrt(x)'}[op]
   source=prefix+f'@render\ndef draw(ctx,runtime,pixels):\n phase={cast}(runtime.time*0.0)\n for i in range(pixels.count):\n'+f'  base={cast}(i%17+1)/{cast}(32)+phase\n  x=base\n'+f'  x={operation}\n'*(0 if op=='base' else 8)+f'  pixels[i]=rgb(int(x*{cast}(255))%256,0,0)\n'
   micro[kind+'-'+op]=source
 micro['cold-invariants']=prefix+'@render\ndef draw(ctx,runtime,pixels):\n t=runtime.time*0.0+0.125\n for i in range(pixels.count):\n'+'  x=math.exp(t)\n'*7+'  pixels[i]=rgb(int(x),i%255,0)\n'
 micro['warm-invariant']=prefix+'@render\ndef draw(ctx,runtime,pixels):\n t=runtime.time*0.0+0.125\n for i in range(pixels.count):\n  x=math.exp(t)\n  pixels[i]=rgb(int(x),i%255,0)\n'
 micro['branch-cost']=prefix+'@render\ndef draw(ctx,runtime,pixels):\n t=runtime.time*0.0+0.125\n for i in range(pixels.count):\n  x=0.0\n  if i%2==0:\n'+'   x=math.exp(t)\n'*7+'  else:\n'+'   x=math.exp(t+0.125)\n'*7+'  pixels[i]=rgb(int(x),0,0)\n'
 micro['math-body']=(args.repo/'tests/fixtures/numeric/math-body.py').read_text()
 dest=args.root/'micro-packages';dest.mkdir(exist_ok=True);manifest={}
 for name,source in micro.items():
  (dest/(name+'.py')).write_text(source)
  for mode,opt in (('scalar',False),('bulk',True)):
   c=PortableCompiler(source,optimize=opt);data,meta=c.compile();key=name+'-'+mode
   (dest/(key+'.lbc')).write_bytes(data)
   manifest[key]={'source_sha256':sha(source.encode()),'bytecode_sha256':sha(data),'bytes':len(data),'requires':meta['requires'],'maps':sum(i[0]==39 for i in c.code),'ordered_reasons':[reason for _,ok,reason in c.map_reports if not ok]}
 (dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('Prepared regression and operation/chunk workloads',flush=True)

def flash(firmware,label):
 with (args.root/(label+'-flash.log')).open('w') as log:subprocess.run([str(args.picotool),'load','-v','-x',str(firmware),'-f','--ser',args.serial],stdout=log,stderr=subprocess.STDOUT,check=True)
 for _ in range(100):
  ports=[port.device for port in list_ports.comports() if port.serial_number==args.serial]
  if ports:args.port=ports[0];time.sleep(2);return
  time.sleep(.1)
 raise RuntimeError('Pico did not return after verified flash')

def regression():
 manifest=json.loads((packages/'manifest.json').read_text());created=[]
 warmup=2 if args.stable_stars else 1
 settings={'capacity':20,'duration':1000.0,'probability':10000.0,'random_colors':False} if args.stable_stars else {}
 result={'scene_settings':settings,'scope':'alternating firmware pairs, identical frozen packages','warmup_seconds':warmup,'samples':[],'packages':manifest,'firmwares':{k:sha(v.read_bytes()) for k,v in [('baseline',args.baseline),('candidate',args.firmware)]}}
 path=args.root/(args.label+'-regression.json')
 def checkpoint():path.write_text(json.dumps(result,indent=2)+'\n')
 def connect():return Client(SerialTransport(args.port),timeout=120)
 c=connect()
 try:
  existing={x['name'] for x in c.programs()}
  if existing.intersection('pt_'+n for n in manifest):raise RuntimeError('campaign program names already exist')
  for name in manifest:c.save_program('pt_'+name,(packages/(name+'.lbc')).read_bytes());created.append('pt_'+name)
 finally:c.close()
 try:
  cases={name:[name] for name in manifest};cases['mixed']=['map','scalar']
  if args.case:cases={name:cases[name] for name in args.case}
  for trial in range(args.samples):
   order=('baseline','candidate') if trial%2==0 else ('candidate','baseline')
   for variant in order:
    firmware=args.baseline if variant=='baseline' else args.firmware
    label=f'{args.label}-{trial+1}-{variant}';flash(firmware,label);c=connect()
    try:
     for case,names in cases.items():
      c.configure(EMPTY);c.configure({'schema':'lightvm.config','outputs':[{'id':'numeric','type':'ws2812b','config':{'pin':'GP16','count':200,'brightness_limit':32}}]})
      c.configure_composition([{'id':'layer'+str(i),'program':'pt_'+name,**({'settings':settings} if name=='control-stars' and settings else {})} for i,name in enumerate(names)],output='numeric')
      time.sleep(warmup);row=sample(c,'numeric',args.seconds)
      if args.stable_stars:assert row['transition_before']['A']['layers'][0]['frames']>=25, 'population warmup incomplete'
      row.update(case=case,variant=variant,trial=trial+1,firmware_sha256=sha(firmware.read_bytes()))
      result['samples'].append(row);checkpoint()
      print(json.dumps({'trial':trial+1,'variant':variant,'case':case,'render_us':{k:round(v['mean_render_us'],2) if v['mean_render_us'] is not None else None for k,v in row['layers'].items()}}),flush=True)
     c.configure(EMPTY);c.configure(original)
    finally:c.close()
  result['passed']=True;checkpoint()
 finally:
  flash(args.firmware,args.label+'-restore-candidate');c=connect()
  try:
   c.configure(EMPTY);c.configure(original)
   for name in created:c.delete_program(name)
  finally:c.close()

def numeric(mode):
 matrix=args.root/'matrix'
 correctness=mode=='matrix'
 cases=sorted({n.rsplit('-',1)[0] for n in json.loads((matrix/'manifest.json').read_text())}) if correctness else ['G1-l64-o-19','G2-l17','Q1-p32768','B1-lazy-piecewise','M1-all-pairs','M2-all-pairs']
 if correctness:
  # Unchanged uncontrolled-RNG examples remain timing controls; exact comparison
  # needs an explicit seed, which their current public animation reset lacks.
  cases=[n for n in cases if n not in ('control-rainbow','control-stars')]
  counts=[1,31,32,33,63,64,65,127,128,129,200,500,1024]
 elif mode=='small':cases=['G1-l3-o0','Q1-p32768'];counts=[1,3,17,32,33,64]
 elif mode=='micro':matrix=args.root/'micro-packages';cases=None;counts=[200]
 else:counts=[200,500,1024]
 benchmark_numeric.run(SimpleNamespace(packages=matrix,case=cases,port=args.port,process=None,firmware=args.firmware,label=args.label,result=args.root/(args.label+'-'+mode+'.json'),correctness=correctness,pixels=counts,samples=1 if mode in ('small','micro') else args.samples,seconds=args.seconds,warmup=.5 if mode in ('small','micro') else 1,mixed=mode=='throughput'))

if args.mode=='prepare':prepare()
elif args.mode=='regression':regression()
else:numeric(args.mode)
