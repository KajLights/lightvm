from pathlib import Path
import subprocess,sys,time
from serial.tools import list_ports
root=Path('/tmp/lightvm-pico-tuning-2026-10-23')
tool='/Users/kws/work/kajlights/lightvm/build/deps/picotool-usb/picotool'
repo=Path('/Users/kws/.codex/worktrees/core-numeric-foundation/lightvm')
serial='E6614103E7236D37'
def flash(file,label):
 with (root/(label+'.log')).open('w') as log:subprocess.run([tool,'load','-v','-x',str(file),'-f','--ser',serial],stdout=log,stderr=subprocess.STDOUT,check=True)
 for _ in range(100):
  found=[p.device for p in list_ports.comports() if p.serial_number==serial]
  if found:time.sleep(1);return found[0]
  time.sleep(.1)
 raise RuntimeError('Pico USB did not return')
try:
 port=flash(root/'pico-w-one/numeric_probe.uf2','flash-math-probe')
 subprocess.run([sys.executable,str(repo/'tools/check_native_math_hardware.py'),'--port',port,'--firmware',str(root/'pico-w-one/numeric_probe.uf2'),'--result',str(root/'native-math-pico.json')],check=True)
finally:
 port=flash(Path('/tmp/lightvm-core-implementation/pico-w/lightvm.uf2'),'flash-committed-two')
 print('Committed candidate on',port,flush=True)
