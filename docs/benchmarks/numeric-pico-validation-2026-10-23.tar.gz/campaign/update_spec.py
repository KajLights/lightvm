from pathlib import Path
root=Path('/Users/kws/work/kajlights/lightvm/build/numeric-implementation/source')
p=root/'docs/design/core-numeric-kernels-plan.md';s=p.read_text()
s=s.replace('23 October 2026. **Status: implementation corrections verified; physical R5/R6\nacceptance open.**', '23 October 2026. **Status: implementation corrections committed; RP2040\nnumeric execution measured and tuned; control-service acceptance open.**')
s=s.replace('corrections from the original review. The\n', 'corrections from the original review. The subsequent\n[Pico W campaign](numeric-pico-validation-2026-10-23.md) records current-firmware\ncorrectness, performance, memory and the failed network-control service gate. The\n',1)
s=s.replace('| R5 | Accounting implemented; physical calibration open | Separate first/steady costs, 1,024-unit first-path admission cap, weighted invocation reservations including faults and speculative suffixes, explicit watchdog semantics; exact boundary and lazy-path tests pass. No physical latency/performance claim for this candidate |', '| R5 | Accounting and RP2040 workloads checked; service acceptance open | First/steady and weighted invocation reservations remain intact after dispatch tuning. Current-candidate arithmetic, kernel, cold/warm and ordered-body results are in the Pico W record. A render-job bound does not close the failed control-service gate |')
s=s.replace('| R6 | Host matrix and cross-builds pass; physical campaign open | 2,210 host replays across 34 cases, including full parameter grids/five-impulse damping and unchanged controls; RP2040/RP2350 strict RAM/stack gates and ESP32-S3 build pass. Board timing, network load and deployment acceptance still require connected hardware |', '| R6 | RP2040 campaign recorded; network service and other boards open | 2,210 host replays, 416 deterministic physical frame pairs, independent wire/fault checks and RP2040 timing/memory results. RP2040/RP2350 strict RAM/stack and ESP32-S3 builds pass. Concurrent brightness controls fail the 10 ms service target on both preserved and final firmware; RP2350/ESP32 physical results remain absent |')
s=s.replace('watchdog contract and oversized-body selection rule are implemented. R5/R6\nphysical calibration and current-candidate performance/service gates remain\nopen; cross-build and host checks do not replace them. The\n', 'watchdog contract and oversized-body selection rule are implemented. The\n[Pico W campaign](numeric-pico-validation-2026-10-23.md) adds current-candidate\nphysical evidence and dispatch tuning. R5/R6 service acceptance and the other\nphysical boards remain open; cross-build and host checks do not replace them. The\n')
s=s.replace('| S6 | Full host matrix/cross-builds pass; physical R5/R6 open |', '| S6 | RP2040 results recorded; control service and other boards open |')
s=s.replace('the next campaign, measure the current candidate for R5/R6 using the frozen\nparameter matrix and unchanged controls. S6 is the release gate.', 'the next campaign, address the measured control-service gaps below and run the\nremaining physical boards using the same frozen matrix. S6 is the release gate.')
marker='### Review verification\n'
section='''### Current RP2040 findings — 23 October 2026

The [current physical record](numeric-pico-validation-2026-10-23.md) follows
reviewed implementation commit `2459b5b`. Generated flash-resident cost lookup
and a direct native-call dispatch path recover accounting overhead without
changing work weights, numeric precision, reservations or kernel selection.
Five alternating firmware pairs retain every unchanged control. Stars has a
variable random population; its raw results remain diagnostic, while the
separate fixed-population sprite control is repeatable. Do not claim an exact
unchanged-Stars regression gate from those stochastic windows.

Outstanding control work is now concrete. Brightness changes call
`refresh_light_frame()`, which drains the old physical output and invokes a
synchronous `pixels_show()`. At 500 WS2812 pixels the wire transfer alone takes
about 15 ms. Concurrent HTTP/WebSocket/MQTT tests and MQTT-only isolation exceed
the 10 ms ingress target on both preserved and final numeric firmware. Convert
brightness refresh to an owned asynchronous output operation, preserving paused
frames, A/B transitions, cancellation, DMA-buffer lifetime and acknowledgements;
then repeat the same load and stack/resource checks. Also isolate the remaining
HTTP/WebSocket foreground gaps: timely actual ingress does not erase a failed
full-loop foreground target. Do not change numeric weights to hide control I/O.
The inherited near-boot gap remains separately open.

The 1,024-pixel A/B/program-transition scene holds 63,474 of 65,536 VM-heap bytes.
Candidate cancellation/rejection restores the exact prior heap, but an additional
configuration parser is rejected at that occupancy. Allocation-free clearing
of B releases enough space for ordinary configuration restoration. Retain this
recoverability path and test cleanup at peak occupancy; full transactional
replacement is only supported when its parser/candidate peak fits. Do not enlarge
the heap or describe a successful steady scene as proof that every replacement
can coexist with it.

'''
assert marker in s;s=s.replace(marker,section+marker)
p.write_text(s)
p=root/'docs/design/numeric-workloads.md';s=p.read_text().replace('23 October 2026. **Full host parameter matrix and cross-builds pass; physical\nacceptance remains open.**', '23 October 2026. **Host and RP2040 numeric checks pass; control-service and\nother-board acceptance remain open.**').replace('[current validation record](numeric-followup-validation-2026-10-23.md)', '[current Pico W validation](numeric-pico-validation-2026-10-23.md)')
s+='''
## Current physical disposition

The [23 October Pico W campaign](numeric-pico-validation-2026-10-23.md) adds
416 scalar/bulk frame comparisons (32 deterministic cases × 13 admitted counts),
independent wire/floor rejections, native-math vectors and fault/retention checks.
Unchanged Rainbow and Stars remain timing controls; their default unseeded RNG
prevents a frame-for-frame device comparison through the current public reset
API. Host replays include explicit seeds and still cover both examples.

Repeated render timing, small-loop screens, fixed/f32 operation chains and
first/steady-cost controls are reported separately. Counts above the attached
200-pixel strip are logical execution/admission tests. Screened operation chains
include common loop/quantization overhead and are not isolated cycle counts.

Concurrent brightness controls expose an existing synchronous output-refresh
path that misses the 10 ms service target. The original and tuned firmware both
fail this gate; HTTP/WebSocket polling alone has no observed ingress violation
in its isolated window but still has foreground violations. Peak-memory tests
also require clearing a scene before parsing a replacement at nearly full heap.
These findings and RP2350/ESP32 physical results retain their explicit open
statuses. Numeric throughput gains do not close unrelated control-service gates.
'''
p.write_text(s)
p=root/'docs/design/numeric-followup-validation-2026-10-23.md';s=p.read_text();s=s.replace('23 October 2026. The implementation corrections', 'The later [Pico W campaign](numeric-pico-validation-2026-10-23.md) supplies the\ncurrent physical results and records the remaining control-service failure.\nThe no-board statements below describe this earlier software-validation run.\n\n23 October 2026. The implementation corrections',1);p.write_text(s)
print('Updated staged specification and historical-record links.')
