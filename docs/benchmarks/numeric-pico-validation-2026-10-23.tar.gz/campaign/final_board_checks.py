import sys,subprocess,time,json
from pathlib import Path
from serial.tools import list_ports
r=Path('/tmp/lightvm-pico-tuning-2026-10-23');repo=Path('/Users/kws/.codex/worktrees/core-numeric-foundation/lightvm');py=sys.executable;picotool='/Users/kws/work/kajlights/lightvm/build/deps/picotool-usb/picotool';one=r/'final-one/lightvm.uf2';two=r/'tuned5-two/lightvm.uf2';results=[]
def run(label,cmd,allow_failure=False):
 print('Starting '+label,flush=True);began=time.time()
 with (r/(label+'.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 results.append({'job':label,'exit_code':p.returncode,'start_unix':began,'end_unix':time.time()});(r/'final-board-status.json').write_text(json.dumps(results,indent=2)+'\n');print(label+' exit '+str(p.returncode),flush=True)
 if p.returncode and not allow_failure:raise RuntimeError(label+' failed')
def flash(firmware,label):
 run(label,[picotool,'load','-v','-x',str(firmware),'-f','--ser','E6614103E7236D37'])
 for _ in range(100):
  if any(p.serial_number=='E6614103E7236D37' for p in list_ports.comports()):time.sleep(2);return
  time.sleep(.1)
 raise RuntimeError('board did not return')
try:
 flash(one,'final-one-wire-flash')
 run('final-one-wire',[py,str(r/'check_wire_hardware.py'),'--repo',str(repo),'--port','/dev/cu.usbmodem11401','--firmware',str(one),'--result',str(r/'final-one-wire.json')])
 run('final-one-runtime',[py,str(repo/'tools/check_numeric_runtime_hardware.py'),'--port','/dev/cu.usbmodem11401','--firmware',str(one),'--result',str(r/'final-one-runtime.json')])
 flash(two,'final-two-extra-checks-flash')
 run('final-stars-population',[py,str(r/'hardware_campaign.py'),'regression','--repo',str(repo),'--root',str(r),'--firmware',str(two),'--baseline',str(r/'device-baseline.uf2'),'--picotool',picotool,'--label','final-stars-population','--samples','5','--seconds','3','--case','control-stars','--stable-stars'])
 run('final-two-color-network',[py,str(r/'service_hardware.py'),'--repo',str(repo),'--root',str(r),'--port','/dev/cu.usbmodem11401','--firmware',str(two),'--network','/Users/kws/work/kajlights/lightvm/build/performance-review/hardware-2026-10-22/original-objects/5-$network.json','--label','final-two-color-network','--seconds','20','--scene','color'],True)
finally:
 flash(two,'last-restored-two-flash')
 run('restoration',[py,str(r/'restore_device.py')])
