import subprocess,sys,time,json
from pathlib import Path
root=Path('/tmp/lightvm-pico-tuning-2026-10-23')
repo=Path('/Users/kws/.codex/worktrees/core-numeric-foundation/lightvm')
py=sys.executable
firmware=root/'tuned5-two/lightvm.uf2'
common=['--repo',str(repo),'--port','/dev/cu.usbmodem11401','--firmware',str(firmware)]
jobs=[('memory', [py,str(root/'memory_hardware.py'),*common,'--root',str(root),'--result',str(root/'final-two-memory.json')]),('wire',[py,str(root/'check_wire_hardware.py'),*common,'--result',str(root/'final-two-wire.json')]),('runtime',[py,str(repo/'tools/check_numeric_runtime_hardware.py'),'--port','/dev/cu.usbmodem11401','--firmware',str(firmware),'--result',str(root/'final-two-runtime.json')]),('service',[py,str(root/'service_hardware.py'),*common,'--root',str(root),'--network','/Users/kws/work/kajlights/lightvm/build/performance-review/hardware-2026-10-22/original-objects/5-$network.json','--label','final-two','--seconds','30'])]
results=[]
for name,cmd in jobs[1:]:
 print('Starting '+name,flush=True)
 with (root/('final-two-'+name+'.log')).open('w') as log:
  r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 results.append({'check':name,'exit_code':r.returncode})
 (root/'final-checks-status.json').write_text(json.dumps(results,indent=2))
 print(name+' exit '+str(r.returncode),flush=True)
