import json,subprocess,os,hashlib
from pathlib import Path
r=Path('/tmp/lightvm-pico-tuning-2026-10-23');p=r/'micro-packages';manifest=json.loads((p/'manifest.json').read_text());results=[]
for case in sorted({name.rsplit('-',1)[0] for name in manifest}):
 modes={}
 for mode in ('scalar','bulk'):
  file=p/(case+'-'+mode+'.lbc');raw=subprocess.run(['/tmp/lightvm-core-implementation/host/test_platform','--numeric-package',str(file),'200','0','2','10000000'],capture_output=True,text=True,check=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
  assert not raw.stderr,raw.stderr
  d=json.loads(raw.stdout);assert d['load'] and d['prepare'] and d['status']==1,(case,mode,d)
  modes[mode]=d
 assert modes['scalar']['pixels']==modes['bulk']['pixels'],case
 results.append({'case':case,'equal':True,'modes':{mode:{'plan_bytes_host':d['plan_bytes'],'work':d['work'],'dispatches':d['dispatches'],'frame_sha256':hashlib.sha256(bytes.fromhex(d['pixels'])).hexdigest()} for mode,d in modes.items()}})
(r/'micro-host.json').write_text(json.dumps({'passed':True,'cases':results},indent=2)+'\n');print(len(results),'micro scalar/bulk frame pairs pass')
