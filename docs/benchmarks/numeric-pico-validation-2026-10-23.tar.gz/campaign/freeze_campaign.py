"""Freeze reproducible inputs/results; exclude credentials and private network data."""
import hashlib,json,subprocess,tarfile,io
from pathlib import Path
R=Path('/tmp/lightvm-pico-tuning-2026-10-23')
S=Path('/Users/kws/work/kajlights/lightvm/build/numeric-implementation/source')
G=Path('/Users/kws/.codex/worktrees/core-numeric-foundation/lightvm')
B=S/'docs/benchmarks';B.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
summary=json.loads((R/'campaign-summary.json').read_text())
for label in ('final-two','final-one'):
 for mode in ('throughput','small','micro'):
  assert summary['measurements'][label+'-'+mode]['completed'],(label,mode)
  assert summary['measurements'][label+'-'+mode]['sample_count']=={'throughput':181,'small':24,'micro':32}[mode]
assert json.loads((R/'restoration.json').read_text())['passed']
assert summary['final-two-matrix']['replays_count']==416 and summary['final-two-matrix']['passed']
for label in ('final-one','final-two'):
 assert summary[label+'-wire']['passed'] and summary[label+'-wire']['frames_count']==20 and summary[label+'-wire']['rejections_count']==17
summary.update(overall_acceptance=False,service_gate_passed=False,host_ctest={'passed':25,'failed':0},host_matrix_replays=2210,physical_matrix_pairs=416,
 board={'board':'pico_w','chip':'RP2040','serial':'E6614103E7236D37','cpu_hz':125000000,'physical_pixels':200,'test_counts':[200,500,1024],'pin':'GP16','order':'GRB','test_brightness_limit':32},
 compiler={'pico_sdk':'2.3.1','arm_gcc':'13.2.1 20231009','python':'3.12','flags':'-g -O3 -DNDEBUG'},
 limits={'storage_bytes':1048576,'vm_heap_bytes':65536,'static_sram_bytes':132784,'native_stack_bytes':24576,'driver_bytes':30464,'operating_headroom_bytes':16384,'remaining_bytes':592},
 outstanding=['Asynchronous brightness refresh and remaining foreground/startup service attribution','Repeat control-service acceptance after repair','Physical RP2350 and ESP32-S3 conformance/performance'])
entries={}
def add(name,data):
 assert name not in entries,name
 entries[name]=data

def clean(value):
 if isinstance(value,list):return [clean(v) for v in value]
 if isinstance(value,dict):return {k:('<redacted network address/name>' if k in ('ssid','ip','host') else clean(v)) for k,v in value.items()}
 return value
for p in sorted(R.iterdir()):
 if not p.is_file() or p.suffix not in ('.json','.log','.py') or 'private' in p.name:continue
 data=p.read_bytes()
 if p.suffix=='.json':data=(json.dumps(clean(json.loads(data)),indent=2)+'\n').encode()
 add('campaign/'+p.name,data)
for directory in ('matrix','micro-packages','campaign-packages'):
 for p in sorted((R/directory).iterdir()):
  if p.is_file() and p.suffix in ('.py','.lbc','.json'):add(directory+'/'+p.name,p.read_bytes())
for label,directory in [('final-two','tuned5-two'),('final-one','final-one')]:
 for name in ('lightvm.uf2','lightvm.elf','CMakeCache.txt','stack-paths.json'):
  p=R/directory/name;add('builds/'+label+'/'+name,p.read_bytes())
for name in ('device-baseline.uf2','committed-two.uf2'):add('builds/'+name,(R/name).read_bytes())
add('builds/native-math-probe.uf2',(R/'pico-w-one/numeric_probe.uf2').read_bytes())
for label,directory in [('pico2-w','/tmp/lightvm-core-implementation/pico2-w')]:
 for name in ('stack-paths.json','CMakeCache.txt'):add('builds/'+label+'/'+name,(Path(directory)/name).read_bytes())
for name in ('tests/fixtures/native-math-vectors.json','tests/fixtures/independent_emitter.py'):
 add(name,(S/name).read_bytes())
changed=['src/bytecode_core.h','src/numeric_metadata.inc','src/numeric_work.inc','src/portable.c','tests/numeric_contract.inc','tests/test_numeric_work.py','tools/generate_numeric_metadata.py','tests/fixtures/numeric/math-body.py']
for name in changed:add('changed-source/'+name,(S/name).read_bytes())
summary['changed_sources']={name:sha((S/name).read_bytes()) for name in changed}
summary['reviewed_commit']=subprocess.check_output(['git','rev-parse','2459b5b'],cwd=G,text=True).strip()
tracked=subprocess.check_output(['git','ls-files','src','platforms','cmake','lightvm','tools','CMakeLists.txt','docs/design/numeric-operations.json'],cwd=G,text=True).splitlines()
inputs={name:sha((S/name).read_bytes()) for name in tracked if (S/name).is_file()};inputs['src/numeric_work.inc']=sha((S/'src/numeric_work.inc').read_bytes())
add('build-inputs.json',(json.dumps(dict(sorted(inputs.items())),indent=2)+'\n').encode())
summary['build_inputs_sha256']=sha(entries['build-inputs.json'])
summary['restoration']=json.loads((R/'restoration.json').read_text())
summary['stack']={label:{k:v for k,v in json.loads((R/directory/'stack-paths.json').read_text()).items() if k in ('software_gate_passed','main','worker','features','elf_sha256','contract_identity')} for label,directory in [('one','final-one'),('two','tuned5-two')]}
summary['review']='No actionable final-diff correctness findings; native full-cost boundary and generated metadata checks cover the dispatch change.'
readme='''# Pico W campaign evidence — 23 October 2026

The parent implementation is commit 2459b5b. Overlay changed-source/ to reproduce
the tuned runtime. build-inputs.json hashes the source inputs; builds/ preserves
both tested worker images, the physical baseline, the reviewed candidate, native
math probe, strict stack reports and CMake caches. Every UF2 flash used readback
verification. Package manifests pin compiler outputs independently of firmware.

Use Python 3.12 and the repository's tools. hardware_campaign.py takes --repo,
--root (the extracted campaign root containing matrix/, micro-packages/ and
campaign-packages/), --firmware, --label and --port. Firmware must already match
for throughput/small/micro/matrix modes; regression also takes --baseline and
--picotool. Temporary output scenes and program names must not already exist.
The regression helper reads device-before-private.json for configuration restore:
create that local private file from the controller's current config/description
before reproducing; the user's original private snapshot is intentionally absent.
Service tests additionally require a private --network file with MQTT credentials.
Raw service JSON omits network address/SSID; credentials were never in results.

The runner scripts retain this campaign's absolute paths; adapt them to the local
checkout and extracted root. These are frozen experiment harnesses, not a public
SDK API. Do not run two hardware harnesses against the USB device concurrently.
Only GP16 was driven, with 200 physical pixels; larger counts were logical tests.

Failures are preserved: abandoned tuning candidates had sprite regressions;
concurrent brightness load fails the 10 ms service gate on old and final firmware;
near-full-heap cleanup initially needed a composition clear; the
empty-scene service harness hit a missing frame counter and was rerun with Color.
Raw passed=true means assertions/measurement completed and may precede cleanup.
Use the structured summary and Markdown report for acceptance dispositions.

Do not reset a historical service maximum or omit a failed sample to claim a pass.
No universal operation speedup, all-body timing bound, or other-board conformance
is implied by these RP2040 observations.
'''
add('README.md',readme.encode())
# Refuse to freeze any actual credential values from the private configuration.
private=json.loads(Path('/Users/kws/work/kajlights/lightvm/build/performance-review/hardware-2026-10-22/original-objects/5-$network.json').read_text())
secrets=[]
def collect(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if any(t in k.lower() for t in ('password','secret','token')) and isinstance(x,str) and len(x)>=4:secrets.append(x.encode())
   collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
collect(private)
for name,data in entries.items():
 for secret in secrets:assert secret not in data,'private credential in '+name
manifest={name:sha(data) for name,data in entries.items()}
add('archive-manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())
archive=B/'numeric-pico-validation-2026-10-23.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for name,data in sorted(entries.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=1792761264;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
summary['archive']={'file':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'entries':len(entries),'credentials_scan':'passed; private snapshots excluded; network address/name fields redacted'}
(B/'numeric-pico-validation-2026-10-23.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))
