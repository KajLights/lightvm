import sys,json
from pathlib import Path
root=Path('/tmp/lightvm-pico-tuning-2026-10-23');sys.path.insert(0,'/Users/kws/.codex/worktrees/core-numeric-foundation/lightvm/tools')
from client import Client,SerialTransport
c=Client(SerialTransport('/dev/cu.usbmodem11401'),timeout=120)
try:
 r={'before':c.status_fields(output='numeric')}
 c.clear_composition(output='numeric',slot='B');r['after_clear_B']=c.status_fields(output='numeric')
 c.configure({'schema':'lightvm.config','outputs':[]});c.configure(json.loads((root/'device-before-private.json').read_text())['config'])
 created={'pm_old','pm_next','pm_heavy','pm_huge','pm_cross','pw_scalar','pw_bulk','nf_large','ps_gather','ps_math'}
 for p in c.programs():
  if p['name'] in created:c.delete_program(p['name'])
 r['after']=c.status_fields(output='lights');r['recovered']=True
 (root/'memory-recovery.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
finally:c.close()
