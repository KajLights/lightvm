import subprocess,sys,time,json
from pathlib import Path
from serial.tools import list_ports
root=Path('/tmp/lightvm-pico-tuning-2026-10-23');repo=Path('/Users/kws/.codex/worktrees/core-numeric-foundation/lightvm');py=sys.executable
picotool='/Users/kws/work/kajlights/lightvm/build/deps/picotool-usb/picotool'
results=[]
def call(label,cmd,allow_failure=False):
 print('Starting '+label,flush=True);began=time.time()
 with (root/(label+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 results.append({'job':label,'exit_code':r.returncode,'start_unix':began,'end_unix':time.time()});(root/'measurement-status.json').write_text(json.dumps(results,indent=2)+'\n');print(label+' exit '+str(r.returncode),flush=True)
 if r.returncode and not allow_failure:raise RuntimeError(label+' failed')
def flash(firmware,label):
 call(label,[picotool,'load','-v','-x',str(firmware),'-f','--ser','E6614103E7236D37'])
 for _ in range(100):
  if any(p.serial_number=='E6614103E7236D37' for p in list_ports.comports()):time.sleep(2);return
  time.sleep(.1)
 raise RuntimeError('board did not return')
def service(label,firmware,*flags):
 call(label,[py,str(root/'service_hardware.py'),'--repo',str(repo),'--root',str(root),'--port','/dev/cu.usbmodem11401','--firmware',str(firmware),'--network','/Users/kws/work/kajlights/lightvm/build/performance-review/hardware-2026-10-22/original-objects/5-$network.json','--label',label,'--seconds','20',*flags],True)
baseline=root/'device-baseline.uf2';two=root/'tuned5-two/lightvm.uf2';one=root/'final-one/lightvm.uf2'
try:
 flash(baseline,'baseline-service-flash');service('baseline-two',baseline)
 flash(two,'candidate-service-flash')
 service('final-two-httpws',two,'--transports','http','websocket')
 service('final-two-mqtt',two,'--transports','mqtt')
 service('final-two-idle-network',two,'--scene','idle')
 for label,firmware in [('final-two',two),('final-one',one)]:
  if label=='final-one':flash(firmware,'final-one-flash')
  modes=['matrix','throughput','small','micro'] if label=='final-two' else ['throughput','small','micro']
  for mode in modes:
   call(label+'-'+mode,[py,str(root/'hardware_campaign.py'),mode,'--repo',str(repo),'--root',str(root),'--firmware',str(firmware),'--label',label,'--samples','5','--seconds','3' if mode=='throughput' else '1'])
finally:
 flash(two,'final-restored-two-flash')
