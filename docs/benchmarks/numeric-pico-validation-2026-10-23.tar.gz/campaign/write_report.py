from pathlib import Path
import json,statistics,hashlib
R=Path('/tmp/lightvm-pico-tuning-2026-10-23');D=Path('/Users/kws/work/kajlights/lightvm/build/numeric-implementation/source/docs/design/numeric-pico-validation-2026-10-23.md')
s=json.loads((R/'campaign-summary.json').read_text())
f=lambda n: '—' if n is None else f'{n:,.1f}'
def groups(name):return {(g['pixels'],g['case']):g for g in s['measurements'].get(name,{}).get('groups',[])}
def med(group,variant):
 d=group.get(variant,{}).get('render_us');return d['median'] if d else None
lines=['''# Pico W numeric validation and dispatch tuning

23 October 2026. The reviewed implementation was committed as `2459b5b` before
this board campaign. The subsequent tuning preserves the numeric and work-budget
contracts and adds no SRAM. **Numeric correctness and the recorded throughput
checks pass; full service/release acceptance remains open.** Concurrent brightness
controls miss the 10 ms ingress target on both preserved and final firmware.

The [structured summary](../benchmarks/numeric-pico-validation-2026-10-23.json)
contains gates, firmware identities, per-window variability and memory/service
results. The [frozen evidence](../benchmarks/numeric-pico-validation-2026-10-23.tar.gz)
contains raw samples, failed trials, workloads/packages, harnesses, build logs,
stack reports, and the final source changes relative to `2459b5b`. The JSON pins
the archive hash. Raw harness `passed` fields mean that measurement completed;
acceptance decisions below include the service failure and diagnostic controls.

## Setup and review

Pico W RP2040 `E6614103E7236D37`, 125 MHz; SDK 2.3.1; Arm GNU 13.2.Rel1
(13.2.1 20231009), Release `-g -O3 -DNDEBUG`. Wi-Fi, HTTP, WebSocket, MQTT and boot
support remain enabled. Storage stays 1 MiB, VM heap 64 KiB, two HTTP clients,
1,024-pixel capacity and the existing slice/epoch/work limits. Both one- and
two-worker firmware use the same sources. The existing 200-pixel GRB WS2812 strip
is on GP16. Test brightness limit is 32; 500/1,024 counts measure logical work and
wire transfers, not additional physical LEDs.

The board's program image was backed up before flashing. Its digest exactly
matches the preserved S2–S5 firmware; it is the matched regression baseline,
not an inferred source build. Firmware flashing included readback verification.
No network credentials enter the archive. Temporary programs/configurations are
removed; the original configuration, programs and Rainbow/light controls are
verified after the final two-worker image is restored.

The review covered admission, feature floors, liveness, work charging, helpers,
metadata and the independent emitter. All 25 ASan/UBSan host suites passed before
commit. The new dispatch path then passed the same 25 suites, an explicit native
sine budget boundary (63/64/65/66 units), 2,210 full-matrix host replays and 16
additional operation-chain scalar/bulk pairs. Generated tables check cleanly.
Pico W, Pico 2 W strict RAM/stack gates and the ESP32-S3 firmware build pass.

## Measured tuning

The initial reviewed candidate added avoidable overhead to ordinary/native
instruction dispatch. Intermediate screens and paired runs are retained,
including the abandoned sprite regressions (roughly 17%, then 7–8%). The selected
change uses a generated 256-byte flash cost table, eliminates a redundant
watchdog comparison and decodes each native call record once before entering its
call path. Native arguments no longer trigger four unrelated register reads.
Native costs still come from the catalogue; the full charge precedes execution.
No numeric precision, work weight, chunk selection or resource reserve changed.

Five alternating AB/BA firmware pairs use identical frozen packages, one-second
warmup, three-second windows, 200 logical pixels and 20 Hz USB STATUS polling.
Values below are medians of per-window render cost; raw minimum/maximum and every
sample remain in the JSON. Render CPU cost and displayed contributions are
separate from wire-limited presentation FPS.

| Control | Baseline µs | Final µs | Change |
| --- | ---: | ---: | ---: |''']
for g in s['regression']:
 a=g['baseline']['render_us'];b=g['candidate']['render_us'];label=g['case']+(' / scalar layer' if g['layer']=='A/layer1' else '')
 lines.append(f"| {label} | {f(a['median'] if a else None)} | {f(b['median'] if b else None)} | {f(g['change_percent'])}% |")
lines.append('''
All repeatable controls remain within the specified 5% median regression limit;
draw is close to that threshold and retains its raw variability. Color reuses
its frame, so no timed-render percentage applies. Default Stars varies with its
random population: its default-window result is diagnostic and cannot establish
an unchanged-Stars regression gate. The additional population-controlled run
uses the exact same source and package with its existing settings (capacity 20,
duration 1,000 seconds, birth probability 10,000/s, fixed colour), two-second
warmup and at least 25 completed warmup frames; its outcome is recorded separately.

## Physical correctness and throughput

- 16,209 isolated native-math corpus vectors pass, including domain rejection,
  signed zero and the errno sentinel. Maximum oracle error is zero ULP for the
  sampled operations except pow, which reaches one ULP. Arithmetic sources are
  unchanged by dispatch tuning; the probe has its own recorded firmware hash.
- 416 deterministic scalar/bulk frame pairs pass: 32 cases × 13 admitted counts
  (1/31/32/33/63/64/65/127/128/129/200/500/1,024), five explicit frame deltas per
  mode. Full parameter grids and ordered negative controls are included. This is
  pixel equivalence; host replays additionally compare raw state and damping
  histories. Default unseeded Rainbow/Stars stay out of device exact replay.
- On each worker image, independent literal-wire emission matches 20 exact frames
  and rejects 17 malformed/floor-forged packages while retaining generation, heap and frame.
  Lazy late faults, recovery and ten rejected candidates per case pass for
  scalar/bulk execution at 33 and 129 pixels.

Six workload families use five alternating scalar/bulk pairs at each count,
one-second warmup and three-second sampling windows for each worker count.
The mixed-scene observation is a separate single window, not five-pair acceptance.
The full input grids remain frozen inside their workloads. Values are median
render microseconds; the structured record retains ranges, completions, displayed
contributions, heap samples and command percentiles.

| Workload | Pixels | Scalar / 1 worker | Bulk / 1 worker | Scalar / 2 workers | Bulk / 2 workers | 2-worker reduction |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |''')
one=groups('final-one-throughput');two=groups('final-two-throughput')
for key,g in two.items():
 n,case=key;a=one.get(key,{})
 lines.append(f"| {case} | {n} | {f(med(a,'scalar'))} | {f(med(a,'bulk'))} | {f(med(g,'scalar'))} | {f(med(g,'bulk'))} | {f(g['bulk_reduction_percent'])}% |")
lines.append('''
All 180 two-worker scalar/bulk timing windows have flat sampled heap and zero
inner-window ingress-over-10-ms increments. One first-trial, one-worker G1 bulk
window has one ingress violation and a 56.6 ms maximum USB STATUS latency; its
render-job/epoch high waters did not increase (2,822/4,217 µs). No instrumentation
locates that single delay, so it remains a service-attribution exception. All raw
windows are retained.

The required 15% improvement on at least two newly eligible workloads is exceeded
in the measured cases. This does not assert that every short loop wins or that
fixed arithmetic is universally faster than f32.

## Small loops and operation costs

These are one-pair screens (0.5-second warmup, one-second windows), not repeated
acceptance estimates. Negative reductions mean bulk was slower in that screen.

| Pixels | G1 reduction / 1 worker | G1 / 2 workers | Q1 / 1 worker | Q1 / 2 workers |
| --- | ---: | ---: | ---: | ---: |''')
a=groups('final-one-small');b=groups('final-two-small')
for n in (1,3,17,32,33,64):
 vals=[g.get((n,case),{}).get('bulk_reduction_percent') for case in ('G1-l3-o0','Q1-p32768') for g in (a,b)]
 lines.append('| '+str(n)+' | '+' | '.join(f(v)+'%' for v in vals)+' |')
lines.append('''
Operation-chain screens use 200 pixels and eight written arithmetic operations
per pixel. A captured clock dependency prevents frame reuse while adding zero
to the values. The base row omits the eight operations. These are whole guest
loop costs, including conversion, loop and RGB quantization overhead; they are
not isolated instruction cycle counts. Each representation keeps its own
rounding contract. Scalar/bulk frames agree within each representation.

| Chain | Q16 scalar / 1 worker | Q16 bulk / 1 worker | f32 scalar / 1 worker | f32 bulk / 1 worker | Q16 bulk / 2 workers | f32 bulk / 2 workers |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |''')
a=groups('final-one-micro');b=groups('final-two-micro')
for op in ('base','add','mul','div','mod','sqrt'):
 vals=[med(a.get((200,'q16-'+op),{}),'scalar'),med(a.get((200,'q16-'+op),{}),'bulk'),med(a.get((200,'f32-'+op),{}),'scalar'),med(a.get((200,'f32-'+op),{}),'bulk'),med(b.get((200,'q16-'+op),{}),'bulk'),med(b.get((200,'f32-'+op),{}),'bulk')]
 lines.append('| '+op+' | '+' | '.join(f(v) for v in vals)+' |')
lines.append('''
The first/steady screens retain seven cached exp calls, one cached exp call,
mutually exclusive seven-exp arms, and the original thirty log/exp-pair body.
The last body is explicitly excluded from maps by the first-pixel work cap and
runs in ordered form. The screen cannot prove a universal timing bound for all
admitted bodies; the 1,024-unit path cap and whole-work reservation tests remain
separate safety evidence.

| Workload | Scalar / 1 worker | Bulk emission / 1 worker | Scalar / 2 workers | Bulk emission / 2 workers |
| --- | ---: | ---: | ---: | ---: |''')
for case in ('cold-invariants','warm-invariant','branch-cost','math-body'):
 vals=[med(g.get((200,case),{}),v) for g in (a,b) for v in ('scalar','bulk')]
 lines.append('| '+case+' | '+' | '.join(f(v) for v in vals)+' |')
lines.append('''
## Service gate: still failing

Load runs retain the configured Wi-Fi/MQTT network and use USB STATUS at 20 Hz,
HTTP and WebSocket STATUS at 10 Hz each, and authenticated MQTT brightness
commands at 10 Hz. All transports complete without reported errors. The first
combined run lasts 30 seconds; the baseline and isolated runs last 20 seconds.
Counters below use first/last STATUS samples *inside* each window, excluding
boundary DESCRIPTION/transition queries. Those boundary costs remain in raw data.

| Run | Foreground gaps >10 ms | Actual ingress gaps >10 ms | USB p95 / p99 ms |
| --- | ---: | ---: | ---: |''')
for name,g in s['services'].items():
 if 'loaded' not in g:continue
 d=g['loaded'];v=d['steady_deltas'];q=d['usb_latency_ms']
 lines.append(f"| {g['label']} | {v.get('over_10ms')} | {v.get('ingress_over_10ms')} | {f(q['p95'])} / {f(q['p99'])} |")
lines.append('''
The idle-rendering windows in the service-load harness have no observed
inner-window service violation; the separate one-worker timing exception above
is not cleared by them. The
combined-load failure predates the numeric changes: the preserved firmware
exhibits it too. MQTT-only changes reproduce the ingress gap; HTTP/WebSocket-only
polling keeps actual ingress below 10 ms in its measured window but still exceeds
the full-loop foreground target. End-to-end HTTP/WebSocket/MQTT p95/p99 values,
including Wi-Fi/broker latency, are in the structured record; they are distinct
from device ingress counters and do not locate a stall by themselves.

Repeating combined traffic with cached Color in place of the numeric layers
still produces 190 actual-ingress and 190 foreground violations in 20 seconds.
That isolates the failure from the heavy numeric workload.

The relevant control path is `refresh_light_frame()` in `src/app.c`: a brightness
change drains/cancels the active transfer and calls synchronous `pixels_show()`.
At 500 logical WS2812 pixels a transfer takes approximately 15 ms, independently
of numeric workload cost. Convert this path to an owned asynchronous refresh,
retaining paused-frame behavior, A/B transitions, generation and buffer ownership,
then repeat the load test. Additional network/foreground phases still need
attribution. Reducing kernel work weights would not repair this control path.

The inherited near-boot approximately 54 ms gap remains separately open.
Uploads/preparation, large DESCRIPTION responses and synchronous manual FRAME
can increase lifetime maxima; none is silently included as a steady-render pass.
The failed empty-scene isolation harness hit a missing-frame-counter assumption;
that failed attempt is retained and is not a service result.

## Memory and stack

A fresh selected-firmware boot was used for the peak-memory sequence. Cancellation
and rejection retain the exact live generation/current heap. Twenty steady
A/B/transition samples are flat; host native invocation checks additionally deny
allocation during render. Flat device samples alone cannot prove that no transient
allocation occurred.

| Point | Current VM heap | Peak VM heap |
| --- | ---: | ---: |''')
for row in s['memory']['points']:lines.append(f"| {row['label']} | {row['heap']:,} | {row['heap_peak']:,} |")
lines.append('''
Ten in-progress candidate cancellations and ten oversized candidate rejections
pass. At 63,474 live bytes the scene fits, but a replacement configuration parser
does not. Initial test cleanup therefore failed; the next harnesses also failed
admission until space was released. All failures are retained. Clearing B recovers
to 45,942 bytes and permits configuration restoration, without reboot or a larger
heap. This is a measured admission/headroom limit, not a leak. Future tests must
clear scenes through the lightweight control path before allocating a parser at
near-full occupancy.

Static Pico W SRAM remains 132,784 bytes, leaving **592 bytes** after the existing
65,536-byte VM heap, 24,576-byte native stacks, 30,464-byte driver budget and
16,384-byte operating headroom. The reviewed implementation had already added
48 static bytes relative to the preserved firmware; tuning adds none. The strict
whole-path bounds including interrupt allowance are 12,000/16,384 main and
5,064/8,192 worker, retaining both required margins. Hardware high-water samples
remain observations, not proof that every interrupt/callback path was exercised.
''')
lines.append('Observed campaign high waters: '+', '.join(f'{k}={v:,}' for k,v in s['observed_highwaters'].items())+'. These are lifetime maxima, not per-window maxima.\n')
lines.append('''
Pico 2 W also passes the unchanged strict accounting/fingerprint gate (136,076
static bytes; 124,020 remaining after reservations). ESP32-S3 builds and fits its
2 MiB application partition. Neither has a physical conformance/performance
result in this campaign.

## Disposition

The final source and recorded Pico W measurements support this dispatch tuning
and the numeric throughput gains. R1–R4 remain closed. R5's accounting and measured
numeric paths are supported; R5/R6 overall service acceptance is open. Remaining
work is asynchronous brightness refresh and foreground/startup attribution,
repeated service checks after that repair, and physical RP2350/ESP32 validation.
The larger source-language compiler remains outside this core change.
''')
document='\n'.join(lines)+'\n'
star=s.get('stars_population_control')
if star and star['completed']:
 a=star['baseline']['render_us'];b=star['candidate']['render_us']
 text=f"The five population-controlled Stars pairs measured {a['median']:,.1f} → {b['median']:,.1f} µs ({star['change_percent']:+.2f}%). Baseline window range: {a['min']:,.1f}–{a['max']:,.1f} µs; final: {b['min']:,.1f}–{b['max']:,.1f} µs. The unchanged source passes the 5% regression gate with this stable population. The default stochastic windows remain visible above.\n\n"
 document=document.replace('## Physical correctness and throughput',text+'## Physical correctness and throughput')
D.write_text(document.rstrip()+'\n');print(D)
