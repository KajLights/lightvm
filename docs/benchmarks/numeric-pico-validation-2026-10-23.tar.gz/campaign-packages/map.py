from lightvm import profile,init,render,rgb,hsv,PixelArray,Transform
profile('animation')
@render
def draw(ctx,runtime,pixels):
 for i in range(pixels.count):
  pixels[i]=hsv((i/pixels.count)*(i/pixels.count)+0.37,0.6,0.8)
