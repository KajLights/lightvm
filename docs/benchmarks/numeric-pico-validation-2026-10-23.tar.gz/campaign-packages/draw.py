from lightvm import profile,init,render,rgb,hsv,PixelArray,Transform
profile('animation')
@init
def setup(ctx,runtime):
 ctx.image=PixelArray(31)
 ctx.image.colorwheel(0,8)
@render
def draw(ctx,runtime,pixels):
 pixels.draw(ctx.image,transform=Transform(translate=-0.375,scale=3.25),overflow="wrap")
