from lightvm import profile,init,render,rgb,hsv,PixelArray,Transform
profile('animation')
@render
def draw(ctx,runtime,pixels):
 for i in range(pixels.count):
  value=i*0.001
  for j in range(12):
   value=(value+0.03125)*0.9375
  pixels[i]=rgb(int(value*200),i%255,87)
