# Pico W campaign evidence — 23 October 2026

The parent implementation is commit 2459b5b. Overlay changed-source/ to reproduce
the tuned runtime. build-inputs.json hashes the source inputs; builds/ preserves
both tested worker images, the physical baseline, the reviewed candidate, native
math probe, strict stack reports and CMake caches. Every UF2 flash used readback
verification. Package manifests pin compiler outputs independently of firmware.

Use Python 3.12 and the repository's tools. hardware_campaign.py takes --repo,
--root (the extracted campaign root containing matrix/, micro-packages/ and
campaign-packages/), --firmware, --label and --port. Firmware must already match
for throughput/small/micro/matrix modes; regression also takes --baseline and
--picotool. Temporary output scenes and program names must not already exist.
The regression helper reads device-before-private.json for configuration restore:
create that local private file from the controller's current config/description
before reproducing; the user's original private snapshot is intentionally absent.
Service tests additionally require a private --network file with MQTT credentials.
Raw service JSON omits network address/SSID; credentials were never in results.

The runner scripts retain this campaign's absolute paths; adapt them to the local
checkout and extracted root. These are frozen experiment harnesses, not a public
SDK API. Do not run two hardware harnesses against the USB device concurrently.
Only GP16 was driven, with 200 physical pixels; larger counts were logical tests.

Failures are preserved: abandoned tuning candidates had sprite regressions;
concurrent brightness load fails the 10 ms service gate on old and final firmware;
near-full-heap cleanup initially needed a composition clear; the
empty-scene service harness hit a missing frame counter and was rerun with Color.
Raw passed=true means assertions/measurement completed and may precede cleanup.
Use the structured summary and Markdown report for acceptance dispositions.

Do not reset a historical service maximum or omit a failed sample to claim a pass.
No universal operation speedup, all-body timing bound, or other-board conformance
is implied by these RP2040 observations.
