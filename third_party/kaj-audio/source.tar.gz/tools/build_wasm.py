#!/usr/bin/env python3
"""Build the portable analyser for AudioWorklet and Node conformance checks."""
import argparse
import os
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
def build(output,emcc):
    output.mkdir(parents=True,exist_ok=True)
    exports=['kf_host_'+n for n in ('new','destroy','pcm','output','edges','push','reset')]
    subprocess.run([emcc,'-O2','-std=c11','-ffp-contract=off','-Wall','-Wextra','-Werror',
        '-I'+str(ROOT/'core'),*[str(ROOT/'core'/name) for name in ('features.c','onset.c','fft_portable.c','host.c')],
        '-sMODULARIZE=1','-sEXPORT_ES6=1','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=0',
        '-sINITIAL_MEMORY=1048576','-sSTACK_SIZE=65536',
        '-sEXPORTED_FUNCTIONS='+str(['_'+e for e in exports]).replace("'",'"'),
        '-sEXPORTED_RUNTIME_METHODS=["HEAP16","HEAPU16","HEAPF32"]',
        '-o',str(output/'kaj-audio.mjs')],check=True)
    (output/'profiles.json').write_bytes((ROOT/'core/profiles.json').read_bytes())
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'build/wasm')
    parser.add_argument('--emcc',default=os.environ.get('EMCC','emcc'))
    args=parser.parse_args();build(args.output,args.emcc)
