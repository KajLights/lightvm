"""Independent deterministic PCM corpus. Regenerate intentionally, then commit."""
import gzip, hashlib, json, math, struct
from pathlib import Path
RATE=48000
rows=[]
seed=0x12345678
for i in range(600*1024):
    t=i/RATE; section=int(t); u=t-section
    seed=(1664525*seed+1013904223)&0xffffffff
    noise=(seed/2147483648-1)
    if section==0:x=0
    elif section==1:x=.2
    elif section==2:x=.1*math.sin(2*math.pi*93.75*t)
    elif section==3:x=.1*math.sin(2*math.pi*1014.8125*t)
    elif section==4:x=.15*math.sin(2*math.pi*(100*u+5800*u*u))
    elif section==5:x=(.02 if u<.5 else .3)*math.sin(2*math.pi*750*t)
    elif section==6:x=2*math.sin(2*math.pi*93.75*t)
    elif section==7:x=0
    elif section==8: # Kick/snare attacks, alternating every 250 ms.
        phase=u%.25
        x=(.7*math.exp(-phase*35)*math.sin(2*math.pi*(80*phase-20*phase*phase)) if int(u*4)%2==0 else .5*math.exp(-phase*45)*noise)
    elif section==9:x=.12*sum(math.sin(2*math.pi*220*n*t)/n for n in range(1,8)) # Sustained strings.
    elif section==10:x=.15*math.sin(2*math.pi*700*t+4*math.sin(2*math.pi*5*t)) # Vibrato.
    elif section==11:x=.004*noise*(.7+.3*math.sin(2*math.pi*3*t)) # Quiet breath-like noise.
    else:x=0
    rows.append(max(-32768,min(32767,math.floor(x*32768+.5))))
data=struct.pack('<'+'h'*len(rows),*rows)
root=Path(__file__).parent
(root/'conformance.pcm.gz').write_bytes(gzip.compress(data,mtime=0))
(root/'conformance.json').write_text(json.dumps({'sample_rate':RATE,'channels':1,'format':'s16le','samples':len(rows),'sha256':hashlib.sha256(data).hexdigest(),'seed':'12345678','sections':['silence','DC','bin tone','off-bin tone','sweep','gain step','clipping','silence','kick/snare','harmonic strings','vibrato','quiet noise','stop'],'generator':'generate.py; Python math and deterministic LCG; independent of C analyser'},indent=2)+'\n')
