# Portable audio core, ABI 1

This directory is the single source of truth for PCM analysis and LVAS/LVAF.
There is no ESP-IDF, LightVM, socket, clock or capture dependency in the core.
Consumers pin a kaj-fi Git revision. The Sense uses its optimized ESP FFT adapter;
native services and browser WASM can use `fft_portable.c`.

`profiles.json` defines profile IDs, complete parameter ranges/defaults and the
PCM adapter contract. Profile 1 is Adaptive percussion v1. Profile 2 is the
explicit Level rise baseline v1 over the identical calibrated spectral pipeline.
The Sense advertises only profile 1. Unknown profiles fail initialization/admission.
Changing tuning/profile or losing capture continuity resets histories and sessions.

`host.h` exposes a small allocation-before-capture API for WASM. Input is exactly
one contiguous 1024-sample signed-int16 hop at 48 kHz, with its capture-end timestamp
in monotonic microseconds. Output is six metrics, 64 spectrum slots, novelty,
threshold and discrete occurrence strength. Unused spectrum slots are zero. Read
actual band edges through `kf_host_edges`. A ready hop returns 1; initial window
warmup returns 0; invalid timing returns -1. Hosts own sample-clock mapping,
resampling, sessions, event IDs and decimation to every fifth ready analysis.

Build browser assets with `python3 tools/build_wasm.py` under Emscripten 4.0.7.
`python3 tools/check_parity.py` compares the committed independent PCM corpus on
native portable FFT, ESP's ANSI FFT convention and WASM. It checks exact event
hops and 1e-4 metric/envelope, 1e-3 centroid absolute tolerances. It does not claim
to exercise the physical S3 optimized instructions. Native/onset regression tests
also cover gaps, rearming, sensitivity and percussion/nonpercussion cases.

Build a Mac/Linux fixture publisher with `python3 tools/build_host.py`. Decompress
`tests/fixtures/conformance.pcm.gz` to a local s16le file, generate a stable nonzero
64-bit identity once using OS secure randomness and retain it with the service's
configuration. Run:

```
build/host/fixture_publisher LAN_IP 49152 SOURCE_HEX 1 8 fixture.pcm
python3 tools/listen.py --address LAN_IP --source-id SOURCE_HEX --allow-synthetic
```

Use distinct ports and identities for additional outputs. The fixture service
paces PCM in real time, loops with a new session, marks it synthetic, invalidates
continuity on scheduling stalls, and sends only derived features. It is a test
service, not a production microphone daemon. Bind only the intended interface;
provision the host firewall normally. Raw PCM stays local.
