#include "publication.h"
#include <assert.h>

bool kf_publication_push(KfPublication *p, KfFrame *f, uint64_t audio_us, float strength)
{
    f->audio_us=audio_us;
    unsigned n=0;
    for(unsigned i=0;i<f->event_count;++i)
        if(audio_us-f->events[i].time_us<=KF_EVENT_TTL_US) f->events[n++]=f->events[i];
    f->event_count=n;
    if(strength>0) {
        /* Minimum 120 ms refractory and 350 ms retention allow at most three. */
        assert(n<KF_EVENT_LIMIT);
        f->events[f->event_count++]=(KfEvent){.id=++p->event_id,.time_us=audio_us,
            .kind=KF_EVENT_ONSET,.strength=strength};
    }
    if(p->remaining_hops) { --p->remaining_hops; return false; }
    p->remaining_hops=KF_PUBLISH_HOPS-1;
    ++f->sequence;
    return true;
}
