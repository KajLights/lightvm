#include "host.h"
#include "fft_portable.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
struct KfHost {KfAnalysis analysis;int16_t pcm[KF_HOP];float out[73];};
KfHost *kf_host_new(unsigned profile,float gain,float floor,float attack,float release,
                    unsigned bands,float threshold,unsigned refractory){
    KfAnalysisConfig config={gain,floor,release,bands,attack,threshold,refractory};
    if(!kf_analysis_config_valid(config)||(profile!=1&&profile!=2))return NULL;
    KfHost *h=calloc(1,sizeof(*h));if(!h)return NULL;
    kf_fft_portable_init();
    if(!kf_analysis_init_profile(&h->analysis,config,kf_fft_portable,profile)){free(h);return NULL;}
    return h;
}
void kf_host_destroy(KfHost *h){free(h);}
int16_t *kf_host_pcm(KfHost *h){return h->pcm;}
float *kf_host_output(KfHost *h){return h->out;}
uint16_t *kf_host_edges(KfHost *h){return h->analysis.band_edges;}
void kf_host_reset(KfHost *h){kf_analysis_reset(&h->analysis);memset(h->out,0,sizeof(h->out));}
int kf_host_push(KfHost *h,double end_us){
    if(!isfinite(end_us)||end_us<1||end_us>9007199254740991.0){kf_host_reset(h);return -1;}
    float strength;
    if(!kf_analysis_push(&h->analysis,h->pcm,(uint64_t)end_us,h->out,&strength))return h->analysis.filled?0:-1;
    memcpy(h->out+6,h->analysis.spectrum,sizeof(h->analysis.spectrum));
    h->out[70]=h->analysis.onset.score;h->out[71]=h->analysis.onset.threshold;h->out[72]=strength;
    return 1;
}
