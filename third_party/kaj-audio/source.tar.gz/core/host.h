#pragma once
#include "features.h"
typedef struct KfHost KfHost;
/* Allocate/initialize before capture. No allocations in push/reset. */
KfHost *kf_host_new(unsigned profile,float gain,float floor,float attack,float release,
                    unsigned bands,float threshold,unsigned refractory);
void kf_host_destroy(KfHost *);
int16_t *kf_host_pcm(KfHost *);
/* 6 metrics, 64 spectrum slots, novelty, threshold, occurrence strength. */
float *kf_host_output(KfHost *);
uint16_t *kf_host_edges(KfHost *);
int kf_host_push(KfHost *,double end_us);
void kf_host_reset(KfHost *);
