#pragma once
#include "subscriptions.h"

typedef struct {
    uint64_t sent, received, remote;
} KfClockBound;
/* Conservative age includes 2 ms drift margin. No clock mapping after 5 s. */
bool kf_clock_age(const KfClockBound *,uint64_t capture,uint64_t now,uint64_t *age);
typedef struct {
    KfFrame latest;
    KfClockBound clock;
    uint64_t pin,client,lease,source,session,request,request_sent,next,expires;
    uint64_t event_high,event_seen,joined_us,events,received,last_check;
    uint32_t profile,packets,reordered,invalid,ignored,expired,duplicates,gaps;
    uint8_t pending,retry,status;
    bool allow_synthetic,has_latest;
} KfSubscriber;
void kf_subscriber_init(KfSubscriber *,uint64_t pin,uint32_t profile,bool synthetic);
void kf_subscriber_open(KfSubscriber *,uint64_t nonce,uint64_t now);
/* Socket owner resolves and verifies the peer, and provides secure random bits.
 * True supplies one control datagram to send; retries retain earliest send time.
 * When request exhaustion/expiry clears client, resolve and call open anew. */
bool kf_subscriber_poll(KfSubscriber *,uint64_t now,uint32_t jitter,KfControl *);
bool kf_subscriber_control(KfSubscriber *,const KfControl *,uint64_t now);
bool kf_subscriber_frame(KfSubscriber *,const KfFrame *,uint64_t now);
bool kf_subscriber_available(const KfSubscriber *,uint64_t now);
bool kf_subscriber_close(KfSubscriber *,KfControl *);
