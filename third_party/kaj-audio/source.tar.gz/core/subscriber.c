#include "subscriber.h"
#include <string.h>

bool kf_clock_age(const KfClockBound *c,uint64_t capture,uint64_t now,uint64_t *age){
    if(!c->remote||!c->sent||now<c->received||now-c->received>=5000000||now<c->sent)return false;
    uint64_t elapsed=now-c->sent;
    if(elapsed>UINT64_MAX-2000)return false;
    if(c->remote>=capture){
        uint64_t difference=c->remote-capture;
        if(difference>UINT64_MAX-elapsed-2000)return false;
        elapsed+=difference;
    }else{
        uint64_t difference=capture-c->remote;
        if(difference>elapsed)return false;
        elapsed-=difference;
    }
    if(elapsed>UINT64_MAX-2000)return false;
    *age=elapsed+2000;return true;
}
void kf_subscriber_init(KfSubscriber *s,uint64_t pin,uint32_t profile,bool synthetic){
    memset(s,0,sizeof(*s));s->pin=pin;s->profile=profile;s->allow_synthetic=synthetic;
}
void kf_subscriber_open(KfSubscriber *s,uint64_t nonce,uint64_t now){
    s->client=nonce;s->lease=s->source=s->session=s->expires=0;s->request=1;
    s->pending=KF_OPEN;s->retry=0;s->request_sent=0;s->next=now;
    s->has_latest=false;s->clock=(KfClockBound){0};s->status=0;
}
static void keep(KfSubscriber *s,uint64_t now){
    if(s->request==UINT64_MAX){s->client=0;s->has_latest=false;return;}
    s->request++;s->request_sent=0;s->pending=KF_KEEP;s->retry=0;s->next=now;s->last_check=now;
}
bool kf_subscriber_poll(KfSubscriber *s,uint64_t now,uint32_t jitter,KfControl *out){
    if(!s->client)return false;
    if(s->expires&&now>=s->expires){s->client=0;s->has_latest=false;return false;}
    if(!s->pending&&(now>=s->next||
       (now-s->last_check>=1000000&&(!s->received||now-s->received>=1000000))))keep(s,now);
    if(!s->client||!s->pending||now<s->next)return false;
    *out=(KfControl){.kind=s->pending,.client=s->client,.request=s->request,.lease=s->lease,
        .source=s->lease?s->source:s->pin,.sequence=s->pending==KF_KEEP&&s->has_latest?s->latest.sequence:0,
        .profile=s->profile,.version=5};
    if(!s->request_sent)s->request_sent=now;
    static const unsigned delays[]={250000,500000,1000000,2000000,5000000};
    unsigned delay=delays[s->retry<4?s->retry:4];if(s->retry<4)s->retry++;
    s->next=now+(uint64_t)delay*(900+jitter%201)/1000;return true;
}
bool kf_subscriber_control(KfSubscriber *s,const KfControl *c,uint64_t now){
    if(!s->client||!s->pending||!s->request_sent||c->client!=s->client||c->request!=s->request)return false;
    if(c->kind==KF_ERROR){
        if(c->lease!=s->lease)return false;
        s->status=c->status;s->next=now+5000000;
        if(c->status==KF_BAD_LEASE){s->client=0;s->has_latest=false;}
        return true;
    }
    if(c->profile!=s->profile||c->version!=5){s->status=KF_UNSUPPORTED;return false;}
    if(s->pin&&c->source!=s->pin){s->status=KF_WRONG_SOURCE;return false;}
    if(c->kind==KF_OFFER&&s->pending==KF_OPEN&&c->lease&&c->remaining_ms){
        s->lease=c->lease;s->source=c->source;keep(s,now);return true;
    }
    if(c->kind!=KF_ACK||s->pending!=KF_KEEP||c->lease!=s->lease||c->source!=s->source||!c->remaining_ms)return false;
    if(now<s->request_sent||now-s->request_sent>=(uint64_t)c->remaining_ms*1000)return false;
    if(s->session!=c->session){
        s->session=c->session;s->has_latest=false;s->received=0;
        s->event_high=c->event;s->event_seen=UINT64_MAX;s->joined_us=c->time;
    }
    s->expires=s->request_sent+(uint64_t)c->remaining_ms*1000;
    s->clock=(KfClockBound){s->request_sent,now,c->time};
    s->pending=0;s->status=0;s->last_check=now;
    /* Normal jitter is applied by the socket owner to poll's random input. The
     * nonce gives each acquisition a stable ±10% renewal phase. */
    s->next=now+4000000ull*(900+s->client%201)/1000;
    if(now-s->request_sent>100000)s->next=now+1000000;
    return true;
}
bool kf_subscriber_available(const KfSubscriber *s,uint64_t now){
    uint64_t age;
    return s->client&&s->expires>now&&s->has_latest&&kf_clock_age(&s->clock,s->latest.audio_us,now,&age)&&age<=350000;
}
bool kf_subscriber_frame(KfSubscriber *s,const KfFrame *f,uint64_t now){
    if(!s->client||!s->expires||now>=s->expires||f->lease!=s->lease||f->sensor!=s->source||
       (f->flags&&!s->allow_synthetic)){s->ignored++;return false;}
    if(f->session!=s->session){
        if(!s->pending&&now-s->last_check>=1000000)keep(s,now);
        s->ignored++;return false;
    }
    uint64_t age;
    if(!kf_clock_age(&s->clock,f->audio_us,now,&age)||age>350000){s->expired++;return false;}
    bool newer=!s->has_latest||f->sequence>s->latest.sequence;
    if(s->has_latest){
        if(f->flags!=s->latest.flags||f->band_count!=s->latest.band_count||
           memcmp(f->band_edges,s->latest.band_edges,(f->band_count+1)*sizeof(uint16_t))){s->invalid++;return false;}
        if(newer){
            if(f->audio_us<=s->latest.audio_us||f->send_us<=s->latest.send_us){s->invalid++;return false;}
            uint64_t gap=f->sequence-s->latest.sequence-1;s->gaps+=gap>UINT32_MAX?UINT32_MAX:(uint32_t)gap;
        }else{
            if(f->audio_us>s->latest.audio_us||f->send_us>s->latest.send_us){s->invalid++;return false;}
            s->reordered++;
        }
    }
    for(unsigned i=0;i<f->event_count;i++){
        KfEvent e=f->events[i];
        if(e.time_us<=s->joined_us||!kf_clock_age(&s->clock,e.time_us,now,&age)||age>350000){s->expired++;continue;}
        if(e.id>s->event_high){uint64_t shift=e.id-s->event_high;s->event_seen=shift>=64?0:s->event_seen<<shift;s->event_high=e.id;}
        uint64_t behind=s->event_high-e.id;
        if(behind>=64||(s->event_seen&(1ull<<behind))){s->duplicates++;continue;}
        s->event_seen|=1ull<<behind;s->events++;
    }
    if(newer){s->latest=*f;s->has_latest=true;s->received=now;}
    s->packets++;return true;
}
bool kf_subscriber_close(KfSubscriber *s,KfControl *out){
    bool valid=s->client&&s->lease&&s->request<UINT64_MAX;
    if(valid)*out=(KfControl){.kind=KF_CLOSE,.client=s->client,.request=s->request+1,.lease=s->lease,
        .source=s->source,.profile=s->profile,.version=5};
    s->client=0;s->has_latest=false;return valid;
}
