#include "features.h"
#include <math.h>
#include <string.h>

static float clamp(float x) { return fminf(1, fmaxf(0, x)); }
static float normalized_power(const KfAnalysis *s, float power)
{
    float db = 10 * log10f(fmaxf(power, 1e-20f)) + s->config.gain_db;
    return clamp((db - s->config.floor_db) / (-6 - s->config.floor_db));
}

void kf_analysis_reset(KfAnalysis *s)
{
    s->filled = 0;
    s->first_us = s->previous_us = 0;
    s->envelope = 0;
    s->previous_level = 0;
    kf_onset_init(&s->onset,s->config.floor_db-s->config.gain_db);
    memset(s->values, 0, sizeof(s->values));
    memset(s->spectrum, 0, sizeof(s->spectrum));
}

bool kf_analysis_config_valid(KfAnalysisConfig c)
{
    return isfinite(c.gain_db) && c.gain_db >= -24 && c.gain_db <= 48 &&
        isfinite(c.floor_db) && c.floor_db >= -100 && c.floor_db <= -12 &&
        isfinite(c.release_ms) && c.release_ms >= 20 && c.release_ms <= 2000 &&
        isfinite(c.attack_ms) && c.attack_ms >= 1 && c.attack_ms <= 500 &&
        isfinite(c.onset_threshold) && c.onset_threshold >= 0.02f && c.onset_threshold <= 0.5f &&
        c.onset_refractory_ms >= 120 && c.onset_refractory_ms <= 2000 &&
        c.band_count <= KF_MAX_BANDS;
}
KfAnalysisConfig kf_analysis_defaults(void){return (KfAnalysisConfig){0,-50,220,16,30,.08f,200};}
bool kf_analysis_init(KfAnalysis *s, KfAnalysisConfig c, KfFft fft){
    return kf_analysis_init_profile(s,c,fft,KF_ANALYSIS_ADAPTIVE);
}
bool kf_analysis_init_profile(KfAnalysis *s, KfAnalysisConfig c, KfFft fft,uint32_t profile)
{
    if (!s || !fft || !kf_analysis_config_valid(c) ||
        (profile!=KF_ANALYSIS_ADAPTIVE&&profile!=KF_ANALYSIS_LEVEL_RISE)) return false;
    memset(s, 0, sizeof(*s));
    s->config = c;
    s->profile = profile;
    s->transform = fft;
    const float hop_ms = 1000.0f * KF_HOP / KF_RATE;
    s->attack = 1 - expf(-hop_ms / c.attack_ms);
    s->release = 1 - expf(-hop_ms / c.release_ms);
    s->decay = expf(-hop_ms / 160);
    float energy = 0;
    for (unsigned i = 0; i < KF_WINDOW; ++i) {
        float w = 0.5f - 0.5f * cosf(6.283185307179586f * i / KF_WINDOW);
        s->window[i] = w;
        energy += w * w;
    }
    /* Parseval: one-sided power, normalized by Hann mean-square gain. */
    s->power_scale = 2.0f / (KF_WINDOW * energy);
    if (c.band_count) {
        /* Logarithmic target spacing, quantized to disjoint FFT-bin ranges.
         * Reserve at least one bin for every band, including narrow bass bands. */
        s->band_edges[0] = KF_SPECTRUM_FIRST_BIN;
        float octaves = log2f((float)KF_SPECTRUM_END_BIN / KF_SPECTRUM_FIRST_BIN);
        for (unsigned band = 1; band < c.band_count; ++band) {
            unsigned edge = (unsigned)lroundf(KF_SPECTRUM_FIRST_BIN * exp2f(octaves * band / c.band_count));
            unsigned minimum = s->band_edges[band - 1] + 1;
            unsigned maximum = KF_SPECTRUM_END_BIN - (c.band_count - band);
            s->band_edges[band] = edge < minimum ? minimum : edge > maximum ? maximum : edge;
        }
        s->band_edges[c.band_count] = KF_SPECTRUM_END_BIN;
    }
    kf_analysis_reset(s);
    return true;
}

void kf_analysis_spectrum(const KfAnalysis *s, KfFrame *frame)
{
    frame->band_count = s->config.band_count;
    if (!frame->band_count) return;
    memcpy(frame->band_edges, s->band_edges, (frame->band_count + 1) * sizeof(uint16_t));
    memcpy(frame->spectrum, s->spectrum, frame->band_count * sizeof(float));
}

bool kf_analysis_push(KfAnalysis *s, const int16_t samples[KF_HOP], uint64_t end_us,
                      float values[KF_FEATURES], float *onset_strength)
{
    *onset_strength = 0;
    /* Caller resets the wire session on any capture discontinuity. Defensive
     * timing check also prevents old history from surviving a gap in host use. */
    if (!end_us || (s->previous_us &&
        (end_us <= s->previous_us || end_us - s->previous_us > 2 * KF_HOP * 1000000ull / KF_RATE))) {
        kf_analysis_reset(s);
        return false;
    }
    s->previous_us = end_us;
    if (!s->first_us) s->first_us = end_us;
    memmove(s->pcm, s->pcm + KF_HOP, KF_HOP * sizeof(float));
    for (unsigned i = 0; i < KF_HOP; ++i) s->pcm[KF_HOP + i] = samples[i] / 32768.0f;
    if (s->filled < KF_WINDOW) s->filled += KF_HOP;
    if (s->filled < KF_WINDOW) return false;

    float mean = 0, power = 0;
    for (unsigned i = 0; i < KF_WINDOW; ++i) mean += s->pcm[i];
    mean /= KF_WINDOW;
    for (unsigned i = 0; i < KF_WINDOW; ++i) {
        float x = s->pcm[i] - mean;
        power += x * x;
        s->fft[2 * i] = x * s->window[i];
        s->fft[2 * i + 1] = 0;
    }
    if (!s->transform(s->fft)) { kf_analysis_reset(s); return false; }

    float bands[3] = {0}, weighted = 0, amplitude_sum = 0,high_amplitude = 0,high_power = 0;
    float spectrum_power[KF_MAX_BANDS] = {0};
    float onset_power[KF_ONSET_BANDS] = {0};
    unsigned band = 0,onset_band = 0;
    /* At 48 kHz/2048, bins 2..511 cover [40, 12000) Hz. */
    for (unsigned i = KF_SPECTRUM_FIRST_BIN; i < KF_SPECTRUM_END_BIN; ++i) {
        float re = s->fft[2 * i], im = s->fft[2 * i + 1];
        float p = re * re + im * im;
        float hz = i * ((float)KF_RATE / KF_WINDOW);
        bands[hz < 250 ? 0 : hz < 2000 ? 1 : 2] += p;
        while(i>=s->onset.edges[onset_band+1])++onset_band;
        onset_power[onset_band]+=p;
        if (s->config.band_count) {
            while (i >= s->band_edges[band + 1]) ++band;
            spectrum_power[band] += p;
        }
        float amplitude = sqrtf(p);
        if(i>=32){high_amplitude+=amplitude;high_power+=p;}
        amplitude_sum += amplitude;
        weighted += amplitude * hz;
    }
    float level = normalized_power(s, power / KF_WINDOW);
    float raw[KF_FEATURES] = {level, 0, 0, 0, 0, 0};
    if (level > 0) {
        for (unsigned i = 0; i < 3; ++i) raw[KF_BASS + i] = normalized_power(s, bands[i] * s->power_scale);
        if (amplitude_sum > 0) raw[KF_CENTROID] = clamp(log2f(fmaxf(100, weighted / amplitude_sum) / 100) / 6.321928095f);
    }

    for(unsigned i=0;i<KF_ONSET_BANDS;i++)onset_power[i]*=s->power_scale;
    float density=high_amplitude*high_amplitude/fmaxf(480.0f*high_power,1e-20f);
    if(s->profile==KF_ANALYSIS_ADAPTIVE){
        *onset_strength=kf_onset_push(&s->onset,onset_power,power/KF_WINDOW,density,end_us,
                                     s->config.onset_threshold,s->config.onset_refractory_ms);
    }else{
        /* Profile 2 is an explicit baseline over the identical calibrated FFT
         * pipeline. It measures unsmoothed normalized RMS rise, not percussion. */
        KfOnset *o=&s->onset;
        o->score=fmaxf(0,level-s->previous_level);o->threshold=s->config.onset_threshold;
        if(o->score<o->threshold*.5f)o->armed=true;
        if(end_us-s->first_us>=500000&&o->armed&&o->score>o->threshold&&
           (!o->last_us||end_us-o->last_us>=(uint64_t)s->config.onset_refractory_ms*1000)){
            *onset_strength=fminf(1,(o->score-o->threshold)/fmaxf(.25f,o->threshold));
            o->last_us=end_us;o->armed=false;
        }
        s->previous_level=level;
    }
    s->envelope=*onset_strength>0?1:s->envelope*s->decay;
    for (unsigned i = 0; i < KF_ONSET; ++i) {
        float alpha = raw[i] > s->values[i] ? s->attack : s->release;
        s->values[i] += (raw[i] - s->values[i]) * alpha;
        if (s->values[i] < 1e-5f) s->values[i] = 0;
    }
    s->values[KF_ONSET] = s->envelope < 1e-5f ? 0 : s->envelope;
    for (unsigned i = 0; i < s->config.band_count; ++i) {
        float target = level > 0 ? normalized_power(s, spectrum_power[i] * s->power_scale) : 0;
        float alpha = target > s->spectrum[i] ? s->attack : s->release;
        s->spectrum[i] += (target - s->spectrum[i]) * alpha;
        if (s->spectrum[i] < 1e-5f) s->spectrum[i] = 0;
    }
    memcpy(values, s->values, sizeof(s->values));
    return true;
}
