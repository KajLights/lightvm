#pragma once
#include "features.h"
#include <stddef.h>

#define KF_WIRE_HEADER 92u
#define KF_WIRE_BAND 8u
#define KF_WIRE_EVENT 24u
#define KF_WIRE_MAX (KF_WIRE_HEADER + KF_MAX_BANDS * KF_WIRE_BAND + KF_EVENT_LIMIT * KF_WIRE_EVENT)
size_t kf_encode(const KfFrame *, uint8_t *out, size_t capacity);
bool kf_decode(const uint8_t *, size_t length, KfFrame *);

/* Network-task-owned repetition state. Prepare a copy; commit it only after a
 * successful send. Source frames keep recent occurrences even if overwritten. */
typedef struct { uint64_t session, ids[KF_EVENT_LIMIT]; unsigned sent[KF_EVENT_LIMIT]; } KfRepeats;
void kf_select_events(KfRepeats *, KfFrame *);
