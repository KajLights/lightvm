#include "onset.h"
#include <math.h>
#include <string.h>

static float median(float *x,unsigned n)
{
    for(unsigned i=1;i<n;i++){
        float v=x[i];unsigned j=i;
        while(j&&x[j-1]>v){x[j]=x[j-1];--j;}x[j]=v;
    }
    return n?x[n/2]:0;
}
void kf_onset_init(KfOnset *s,float raw_floor_db)
{
    memset(s,0,sizeof(*s));s->armed=true;
    s->absolute_gate=powf(10.0f,(raw_floor_db+12.0f)/10.0f);
    s->noise_power=s->absolute_gate/16.0f;
    s->band_decay=expf(-(1024.0f/48000.0f)/1.5f);
    s->level_decay=expf(-(1024.0f/48000.0f)/8.0f);
    s->edges[0]=2;
    for(unsigned b=1;b<KF_ONSET_BANDS;b++){
        unsigned edge=(unsigned)lroundf(2.0f*exp2f(8.0f*b/KF_ONSET_BANDS));
        unsigned minimum=s->edges[b-1]+1,maximum=512-(KF_ONSET_BANDS-b);
        s->edges[b]=(uint16_t)(edge<minimum?minimum:edge>maximum?maximum:edge);
    }
    s->edges[KF_ONSET_BANDS]=512;
}
float kf_onset_push(KfOnset *s,const float power[KF_ONSET_BANDS],float rms_power,float high_density,uint64_t now,float sensitivity,unsigned refractory_ms)
{
    if(!s->first_us)s->first_us=now;
    /* Keep recent musical context through a quiet gap. Never normalize a
     * whisper immediately to the previous music's loudness. */
    s->recent_power=fmaxf(rms_power,s->recent_power*s->level_decay);
    if(rms_power<s->recent_power*0.1f){
        float alpha=rms_power<s->noise_power?0.1f:0.001f;
        s->noise_power+=(rms_power-s->noise_power)*alpha;
    }
    s->gate_power=fmaxf(s->absolute_gate,fmaxf(s->recent_power*0.01f,s->noise_power*4.0f));
    s->quiet=rms_power<s->gate_power;
    float current[KF_ONSET_BANDS],previous[KF_ONSET_BANDS];
    float common=fmaxf(s->recent_power*0.0005f,s->absolute_gate/KF_ONSET_BANDS);
    for(unsigned b=0;b<KF_ONSET_BANDS;b++){
        s->peak[b]=fmaxf(power[b],s->peak[b]*s->band_decay);
        float reference=fmaxf(s->peak[b],common);
        /* Apply the same whitening reference to both sides of each difference,
         * so movement of the reference alone cannot create a positive flux. */
        current[b]=log1pf(8.0f*sqrtf(power[b]/reference));
        previous[b]=log1pf(8.0f*sqrtf(s->previous[b]/reference));
    }
    float flux=0,low_flux=0,low_power=0,previous_low_power=0,total=0;unsigned rising=0,low_count=0;
    for(unsigned b=0;b<KF_ONSET_BANDS;b++){
        float reference=previous[b];
        if(b)reference=fmaxf(reference,previous[b-1]);
        if(b+1<KF_ONSET_BANDS)reference=fmaxf(reference,previous[b+1]);
        float change=fmaxf(0,current[b]-reference);
        flux+=change;rising+=change>0.15f;total+=power[b];
        if(s->edges[b]<11){low_flux+=change;low_power+=power[b];previous_low_power+=s->previous[b];++low_count;}
    }
    low_flux/=low_count;
    s->score=fmaxf(flux/KF_ONSET_BANDS,0.35f*low_flux);
    /* Prefer broadband attacks or a distinct low-frequency accent. A generic
     * note-on detector also fires on isolated mid/high tonal notes; this one
     * intentionally does not. It is not an instrument classifier/beat clock. */
    s->percussive=(rising>=5&&high_density>0.25f)||
        (low_flux>0.25f&&low_power>0.25f*total&&low_power>1.3f*previous_low_power);
    float sorted[KF_ONSET_HISTORY],deviations[KF_ONSET_HISTORY];
    memcpy(sorted,s->history,s->history_count*sizeof(float));
    float centre=median(sorted,s->history_count);
    for(unsigned i=0;i<s->history_count;i++)deviations[i]=fabsf(s->history[i]-centre);
    s->threshold=centre+fmaxf(sensitivity,3.0f*median(deviations,s->history_count));
    if(s->score<s->threshold*0.5f)s->armed=true;
    float strength=0;
    if(now-s->first_us>=500000&&s->armed&&!s->quiet&&s->percussive&&
       s->score>s->threshold&&s->score>=s->previous_score&&
       (!s->last_us||now-s->last_us>=(uint64_t)refractory_ms*1000)){
        strength=fminf(1.0f,(s->score-s->threshold)/fmaxf(0.25f,s->threshold));
        s->last_us=now;s->armed=false;
    }
    memcpy(s->previous,power,sizeof(s->previous));s->previous_score=s->score;
    s->history[s->history_next]=s->score;
    s->history_next=(s->history_next+1)%KF_ONSET_HISTORY;
    if(s->history_count<KF_ONSET_HISTORY)++s->history_count;
    return strength;
}
