#include "protocol.h"
#include <math.h>
#include <string.h>
#include <float.h>
_Static_assert(sizeof(float) == 4 && FLT_RADIX == 2 && FLT_MANT_DIG == 24, "binary32 required");
static void put(uint8_t *p, uint64_t x, unsigned n) { while (n) { p[--n] = (uint8_t)x; x >>= 8; } }
static uint64_t get(const uint8_t *p, unsigned n) { uint64_t x = 0; while (n--) x = (x << 8) | *p++; return x; }
static void put_float(uint8_t *p, float x) { uint32_t b; memcpy(&b, &x, 4); put(p, b, 4); }
static float get_float(const uint8_t *p) { uint32_t b = (uint32_t)get(p, 4); float x; memcpy(&x, &b, 4); return x; }
static bool unit(float x) { return isfinite(x) && x >= 0 && x <= 1; }
static bool valid(const KfFrame *f)
{
    if (!f->lease || !f->sensor || !f->session || !f->sequence || !f->audio_us ||
        (f->flags & ~KF_FLAG_SYNTHETIC) ||
        f->send_us < f->audio_us || f->event_count > KF_EVENT_LIMIT || f->band_count > KF_MAX_BANDS) return false;
    for (unsigned i = 0; i < KF_FEATURES; ++i) if (!unit(f->values[i])) return false;
    if (f->band_count && (f->band_edges[0] != KF_SPECTRUM_FIRST_BIN ||
                         f->band_edges[f->band_count] != KF_SPECTRUM_END_BIN)) return false;
    for (unsigned i = 0; i < f->band_count; ++i)
        if (f->band_edges[i] >= f->band_edges[i+1] || !unit(f->spectrum[i])) return false;
    for (unsigned i = 0; i < f->event_count; ++i) {
        const KfEvent *e = &f->events[i];
        if (!e->id || !e->time_us || e->time_us > f->audio_us ||
            f->send_us - e->time_us > KF_EVENT_TTL_US || e->kind != KF_EVENT_ONSET ||
            !unit(e->strength) || !e->strength) return false;
        if (i && (e->id <= f->events[i-1].id || e->time_us < f->events[i-1].time_us)) return false;
    }
    return true;
}
size_t kf_encode(const KfFrame *f, uint8_t *p, size_t cap)
{
    if (!valid(f)) return 0;
    size_t event_offset = KF_WIRE_HEADER + KF_WIRE_BAND * f->band_count;
    size_t n = event_offset + KF_WIRE_EVENT * f->event_count;
    if (cap < n) return 0;
    memset(p, 0, n); memcpy(p, "LVAF", 4);
    p[4] = 5; p[5] = KF_FEATURES; p[6] = f->event_count; p[7] = f->flags;
    put(p+8, f->sensor, 8); put(p+16, f->session, 8); put(p+24, f->sequence, 8);
    put(p+32, f->audio_us, 8); put(p+40, f->send_us, 8);
    put(p+48, f->lease, 8); put(p+56, KF_RATE, 4); put(p+60, KF_HOP, 2); put(p+62, KF_WINDOW, 2);
    for (unsigned i = 0; i < KF_FEATURES; ++i) put_float(p+64+4*i, f->values[i]);
    p[88] = f->band_count; p[89] = 1; /* Layout: contiguous FFT-bin intervals. */
    for (unsigned i = 0; i < f->band_count; ++i) {
        uint8_t *band = p + KF_WIRE_HEADER + i * KF_WIRE_BAND;
        put(band, f->band_edges[i], 2); put(band+2, f->band_edges[i+1], 2);
        put_float(band+4, f->spectrum[i]);
    }
    for (unsigned i = 0; i < f->event_count; ++i) {
        uint8_t *e = p + event_offset + i * KF_WIRE_EVENT;
        put(e, f->events[i].id, 8); put(e+8, f->events[i].time_us, 8);
        e[16] = f->events[i].kind; put_float(e+20, f->events[i].strength);
    }
    return n;
}
bool kf_decode(const uint8_t *p, size_t n, KfFrame *out)
{
    if (n < KF_WIRE_HEADER || memcmp(p, "LVAF", 4) || p[4] != 5 || p[5] != KF_FEATURES ||
        p[6] > KF_EVENT_LIMIT || (p[7] & ~KF_FLAG_SYNTHETIC) || p[88] > KF_MAX_BANDS || p[89] != 1 || p[90] || p[91] ||
        n != KF_WIRE_HEADER + p[88] * KF_WIRE_BAND + p[6] * KF_WIRE_EVENT ||
        get(p+56, 4) != KF_RATE || get(p+60, 2) != KF_HOP || get(p+62, 2) != KF_WINDOW) return false;
    KfFrame f = {.sensor=get(p+8,8), .session=get(p+16,8), .sequence=get(p+24,8),
                 .lease=get(p+48,8), .audio_us=get(p+32,8), .send_us=get(p+40,8), .event_count=p[6], .band_count=p[88], .flags=p[7]};
    for (unsigned i=0; i<KF_FEATURES; ++i) f.values[i] = get_float(p+64+4*i);
    for (unsigned i=0; i<f.band_count; ++i) {
        const uint8_t *band = p + KF_WIRE_HEADER + i * KF_WIRE_BAND;
        uint16_t start = get(band,2), end = get(band+2,2);
        if (i && start != f.band_edges[i]) return false;
        f.band_edges[i] = start; f.band_edges[i+1] = end;
        f.spectrum[i] = get_float(band+4);
    }
    size_t event_offset = KF_WIRE_HEADER + KF_WIRE_BAND * f.band_count;
    for (unsigned i=0; i<f.event_count; ++i) {
        const uint8_t *e = p + event_offset + i * KF_WIRE_EVENT;
        if (e[17] || e[18] || e[19]) return false;
        f.events[i] = (KfEvent){.id=get(e,8), .time_us=get(e+8,8), .kind=e[16], .strength=get_float(e+20)};
    }
    if (!valid(&f)) return false;
    *out = f;
    return true;
}
void kf_select_events(KfRepeats *r, KfFrame *f)
{
    if (r->session != f->session) { memset(r, 0, sizeof(*r)); r->session = f->session; }
    unsigned count = 0;
    for (unsigned i=0; i<f->event_count; ++i) {
        KfEvent e = f->events[i];
        if (e.time_us > f->send_us || f->send_us - e.time_us > KF_EVENT_TTL_US) continue;
        unsigned slot = KF_EVENT_LIMIT;
        for (unsigned j=0; j<KF_EVENT_LIMIT; ++j) if (r->ids[j] == e.id) { slot=j; break; }
        if (slot == KF_EVENT_LIMIT) {
            slot=0;
            for (unsigned j=1; j<KF_EVENT_LIMIT; ++j) if (r->ids[j] < r->ids[slot]) slot=j;
            r->ids[slot]=e.id; r->sent[slot]=0;
        }
        if (r->sent[slot] < 3) { f->events[count++]=e; ++r->sent[slot]; }
    }
    f->event_count=count;
}
