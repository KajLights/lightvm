#pragma once
#include <stdbool.h>
/* Call once before capture, never concurrently with an active transform. */
void kf_fft_portable_init(void);
bool kf_fft_portable(float *complex_data);
