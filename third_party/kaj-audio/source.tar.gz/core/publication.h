#pragma once
#include "features.h"

#define KF_PUBLISH_HOPS 5u /* 48 kHz / 1024 / 5 = 9.375 snapshots/s. */
typedef struct {
    unsigned remaining_hops;
    uint64_t event_id;
} KfPublication;

/* Call for every completed analysis hop. Retain events between publications;
 * return true when this current snapshot should enter the network mailbox.
 * Reset both state and frame at each stream-session boundary. */
bool kf_publication_push(KfPublication *, KfFrame *, uint64_t audio_us, float strength);
