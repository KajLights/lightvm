#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "onset.h"

#define KF_RATE 48000u
#define KF_WINDOW 2048u
#define KF_HOP 1024u
#define KF_FEATURES 6u
#define KF_MAX_BANDS 64u
#define KF_DEFAULT_BANDS 16u
#define KF_SPECTRUM_FIRST_BIN 2u
#define KF_SPECTRUM_END_BIN (KF_WINDOW / 4u)
#define KF_EVENT_LIMIT 4u
#define KF_EVENT_TTL_US 350000u
#define KF_ANALYSIS_ABI 1u
#define KF_ANALYSIS_ADAPTIVE 1u
#define KF_ANALYSIS_LEVEL_RISE 2u
enum { KF_LEVEL, KF_BASS, KF_MID, KF_TREBLE, KF_CENTROID, KF_ONSET };
enum { KF_EVENT_ONSET = 1 };
enum { KF_FLAG_SYNTHETIC = 1 };
typedef struct {
    uint64_t id, time_us;
    uint8_t kind;
    float strength;
} KfEvent;
typedef struct {
    uint64_t sensor, session, sequence, audio_us, send_us, lease;
    uint8_t flags;
    float values[KF_FEATURES];
    unsigned band_count;
    uint16_t band_edges[KF_MAX_BANDS + 1];
    float spectrum[KF_MAX_BANDS];
    unsigned event_count;
    KfEvent events[KF_EVENT_LIMIT];
} KfFrame;

typedef struct {
    float gain_db, floor_db, release_ms;
    unsigned band_count; /* 0 disables additional spectrum output. */
    float attack_ms, onset_threshold;
    unsigned onset_refractory_ms;
} KfAnalysisConfig;
typedef bool (*KfFft)(float *complex_data); /* unscaled, natural-order FFT */
typedef struct {
    _Alignas(16) float pcm[KF_WINDOW], window[KF_WINDOW], fft[2 * KF_WINDOW];
    float values[KF_FEATURES], envelope;
    KfOnset onset;
    uint16_t band_edges[KF_MAX_BANDS + 1];
    float spectrum[KF_MAX_BANDS];
    float attack, release, decay, power_scale;
    KfAnalysisConfig config;
    uint64_t first_us, previous_us;
    unsigned filled;
    uint32_t profile;
    float previous_level;
    KfFft transform;
} KfAnalysis;

bool kf_analysis_config_valid(KfAnalysisConfig);
KfAnalysisConfig kf_analysis_defaults(void);
bool kf_analysis_init_profile(KfAnalysis *, KfAnalysisConfig, KfFft, uint32_t profile);
bool kf_analysis_init(KfAnalysis *, KfAnalysisConfig, KfFft);
void kf_analysis_reset(KfAnalysis *);
/* Copy the configured spectrum and its exact bin ranges into a wire frame. */
void kf_analysis_spectrum(const KfAnalysis *, KfFrame *);
/* Feed one contiguous hop. False means warmup or invalid timing/FFT failure.
 * On an event, strength > 0; it is separate from the decaying scalar envelope. */
bool kf_analysis_push(KfAnalysis *, const int16_t samples[KF_HOP], uint64_t end_us,
                      float values[KF_FEATURES], float *onset_strength);
