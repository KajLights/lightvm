#pragma once
#include "protocol.h"

#define KF_CONTROL_SIZE 80u
#define KF_PROFILE_ADAPTIVE 1u
#define KF_OFFER_US 2000000ull
#define KF_LEASE_US 15000000ull
enum { KF_OPEN=1, KF_OFFER, KF_KEEP, KF_ACK, KF_CLOSE, KF_ERROR };
enum { KF_OK, KF_FULL, KF_BAD_LEASE, KF_WRONG_SOURCE, KF_UNSUPPORTED, KF_BAD_REQUEST };
typedef struct {
    uint64_t client, request, lease, source, session, time, sequence, event;
    uint32_t profile;
    uint16_t remaining_ms;
    uint8_t kind, status, bands, version;
} KfControl;
bool kf_control_decode(const uint8_t *, size_t, KfControl *);
size_t kf_control_encode(const KfControl *, uint8_t *, size_t);

/* Address and port are opaque host-provided endpoint identifiers. No alternate
 * delivery address exists in the wire request. All storage belongs to caller. */
typedef struct { uint32_t address; uint16_t port; } KfEndpoint;
typedef struct {
    KfEndpoint peer;
    uint64_t client, token, request, expires, joined_us, joined_event, joined_session;
    KfRepeats repeats;
    uint32_t sent, errors, backpressure;
    uint64_t retry_at;
    bool active;
} KfLease;
typedef struct { KfEndpoint peer; uint64_t window; unsigned count; } KfRate;
typedef uint64_t (*KfRandom)(void *);
typedef struct {
    KfLease *leases;
    unsigned capacity, first, responses;
    uint64_t source, session, sequence, event, window;
    uint32_t profile;
    uint8_t bands;
    KfRandom random;
    void *random_context;
    KfRate rates[16];
    uint32_t full, expired, invalid, limited;
} KfService;
bool kf_service_init(KfService *, KfLease *, unsigned, uint64_t, uint32_t, KfRandom, void *);
void kf_service_expire(KfService *, uint64_t);
void kf_service_frame(KfService *, const KfFrame *);
bool kf_service_control(KfService *, KfEndpoint, const KfControl *, uint64_t, KfControl *);
/* Prepare a fresh per-lease copy. Commit repeats only after a successful send. */
bool kf_service_prepare(KfLease *, const KfFrame *, uint64_t, KfFrame *, KfRepeats *);
