#include "subscriptions.h"
#include <string.h>

static uint64_t get(const uint8_t *p,unsigned n){uint64_t x=0;while(n--)x=(x<<8)|*p++;return x;}
static void put(uint8_t *p,uint64_t x,unsigned n){while(n){p[--n]=(uint8_t)x;x>>=8;}}
static bool valid(const KfControl *c){
    if(!c->client||!c->request||!c->profile||c->version!=5||c->bands>64||c->kind<KF_OPEN||c->kind>KF_ERROR)return false;
    if(c->kind==KF_ERROR)return c->status>=KF_FULL&&c->status<=KF_BAD_REQUEST&&c->source&&
        !c->session&&!c->time&&!c->sequence&&!c->event&&!c->remaining_ms&&!c->bands;
    if(c->status)return false;
    if(c->kind==KF_OFFER||c->kind==KF_ACK){
        if(!c->lease||!c->source||c->remaining_ms>15000)return false;
        if(!c->session&&(c->time||c->sequence||c->event))return false;
        if(c->session&&!c->time)return false;
        return c->kind!=KF_OFFER||c->remaining_ms>0;
    }
    if(c->session||c->time||c->event||c->remaining_ms||c->bands)return false;
    if(c->kind==KF_OPEN)return c->request==1&&!c->lease&&!c->sequence;
    return c->request>1&&c->lease&&c->source&&(c->kind!=KF_CLOSE||!c->sequence);
}
bool kf_control_decode(const uint8_t *p,size_t n,KfControl *out){
    if(n!=KF_CONTROL_SIZE||memcmp(p,"LVAS",4)||p[4]!=1||p[7])return false;
    KfControl c={.kind=p[5],.status=p[6],.client=get(p+8,8),.request=get(p+16,8),
        .lease=get(p+24,8),.source=get(p+32,8),.session=get(p+40,8),.time=get(p+48,8),
        .sequence=get(p+56,8),.event=get(p+64,8),.remaining_ms=(uint16_t)get(p+72,2),
        .bands=p[74],.version=p[75],.profile=(uint32_t)get(p+76,4)};
    if(!valid(&c))return false;
    *out=c;return true;
}
size_t kf_control_encode(const KfControl *c,uint8_t *p,size_t cap){
    if(cap<KF_CONTROL_SIZE||!valid(c))return 0;
    memset(p,0,KF_CONTROL_SIZE);memcpy(p,"LVAS",4);p[4]=1;p[5]=c->kind;p[6]=c->status;
    put(p+8,c->client,8);put(p+16,c->request,8);put(p+24,c->lease,8);put(p+32,c->source,8);
    put(p+40,c->session,8);put(p+48,c->time,8);put(p+56,c->sequence,8);put(p+64,c->event,8);
    put(p+72,c->remaining_ms,2);p[74]=c->bands;p[75]=5;put(p+76,c->profile,4);return KF_CONTROL_SIZE;
}
static bool same(KfEndpoint a,KfEndpoint b){return a.address==b.address&&a.port==b.port;}
bool kf_service_init(KfService *s,KfLease *leases,unsigned count,uint64_t source,uint32_t profile,KfRandom random,void *ctx){
    if(!s||!leases||!count||!source||!profile||!random)return false;
    memset(s,0,sizeof(*s));memset(leases,0,count*sizeof(*leases));
    s->leases=leases;s->capacity=count;s->source=source;s->profile=profile;s->random=random;s->random_context=ctx;return true;
}
void kf_service_expire(KfService *s,uint64_t now){
    for(unsigned i=0;i<s->capacity;i++)if(s->leases[i].token&&now>=s->leases[i].expires){memset(&s->leases[i],0,sizeof(KfLease));s->expired++;}
}
void kf_service_frame(KfService *s,const KfFrame *f){
    if(s->session!=f->session)s->event=0;
    s->session=f->session;s->sequence=f->sequence;s->bands=(uint8_t)f->band_count;
    if(f->event_count)s->event=f->events[f->event_count-1].id;
    else if(!f->sequence)s->event=0;
}
static bool rate(KfService *s,KfEndpoint peer,uint64_t now){
    uint64_t window=now/1000000+1;
    if(s->window!=window){s->window=window;s->responses=0;}
    if(s->responses>=32)return false;
    unsigned slot=16;
    for(unsigned i=0;i<16;i++)if(same(s->rates[i].peer,peer)&&s->rates[i].window==window){slot=i;break;}
    if(slot==16)for(unsigned i=0;i<16;i++)if(s->rates[i].window!=window){slot=i;break;}
    if(slot==16)return false; /* Bounded unknown-endpoint cache: fail closed. */
    KfRate *r=&s->rates[slot];
    if(r->window!=window)*r=(KfRate){.peer=peer,.window=window};
    if(r->count>=4)return false;
    r->count++;s->responses++;return true;
}
static void reply(KfService *s,const KfControl *in,KfControl *out,unsigned status){
    *out=(KfControl){.kind=KF_ERROR,.status=(uint8_t)status,.client=in->client,.request=in->request,
        .lease=in->lease,.source=s->source,.version=5,.profile=s->profile};
}
bool kf_service_control(KfService *s,KfEndpoint peer,const KfControl *in,uint64_t now,KfControl *out){
    if(!valid(in)||(in->kind!=KF_OPEN&&in->kind!=KF_KEEP&&in->kind!=KF_CLOSE)||!peer.address||!peer.port){s->invalid++;return false;}
    kf_service_expire(s,now);
    if(!rate(s,peer,now)){s->limited++;return false;}
    reply(s,in,out,KF_BAD_LEASE);
    if(in->profile!=s->profile){out->status=KF_UNSUPPORTED;return true;}
    if(in->source&&in->source!=s->source){out->status=KF_WRONG_SOURCE;return true;}
    KfLease *l=NULL,*empty=NULL;
    for(unsigned i=0;i<s->capacity;i++){
        KfLease *p=&s->leases[i];
        if(!p->token){if(!empty)empty=p;continue;}
        if(same(p->peer,peer)&&p->client==in->client&&(in->kind==KF_OPEN||in->lease==p->token))l=p;
    }
    if(in->kind==KF_OPEN){
        if(!l){
            if(!empty){out->status=KF_FULL;s->full++;return true;}
            uint64_t token=0;
            for(unsigned attempt=0;attempt<16&&!token;attempt++){
                token=s->random(s->random_context);
                for(unsigned i=0;i<s->capacity;i++)if(token==s->leases[i].token){token=0;break;}
            }
            if(!token){out->status=KF_FULL;return true;}
            l=empty;*l=(KfLease){.peer=peer,.client=in->client,.token=token,.request=1,.expires=now+KF_OFFER_US};
        }
        out->kind=KF_OFFER;
    }else{
        if(!l)return true;
        if(in->request<l->request)return false;
        if(in->kind==KF_CLOSE){
            if(in->request==l->request)return false;
            out->kind=KF_ACK;out->status=KF_OK;memset(l,0,sizeof(*l));return true;
        }
        if(in->request>l->request){
            if(!l->active){l->joined_us=now;l->joined_event=s->event;l->joined_session=s->session;}
            l->active=true;l->request=in->request;l->expires=now+KF_LEASE_US;
        }
        out->kind=KF_ACK;
    }
    out->status=KF_OK;out->lease=l->token;out->session=s->session;out->time=s->session?now:0;
    out->sequence=s->sequence;out->event=s->event;out->bands=s->bands;
    out->remaining_ms=(uint16_t)((l->expires-now+999)/1000);return true;
}
bool kf_service_prepare(KfLease *l,const KfFrame *f,uint64_t now,KfFrame *out,KfRepeats *repeats){
    if(!l->active||now>=l->expires||now<l->retry_at||now<f->audio_us||now-f->audio_us>80000)return false;
    *out=*f;out->lease=l->token;out->send_us=now;
    unsigned n=0;
    for(unsigned i=0;i<out->event_count;i++){
        KfEvent e=out->events[i];
        if(e.time_us>l->joined_us&&(f->session!=l->joined_session||e.id>l->joined_event))out->events[n++]=e;
    }
    out->event_count=n;*repeats=l->repeats;kf_select_events(repeats,out);return true;
}
