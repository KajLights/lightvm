#include "fft_portable.h"
#include "kaj_audio_features.h"
#include <math.h>
static float twiddle[KF_WINDOW];
static bool ready;
void kf_fft_portable_init(void){
    for(unsigned i=0;i<KF_WINDOW/2;i++){
        float phase=-6.283185307179586f*i/KF_WINDOW;
        twiddle[2*i]=cosf(phase);twiddle[2*i+1]=sinf(phase);
    }
    ready=true;
}
bool kf_fft_portable(float *a){
    if(!ready)return false;
    for(unsigned i=1,j=0;i<KF_WINDOW;i++){
        unsigned bit=KF_WINDOW/2;for(;j&bit;bit>>=1)j^=bit;j^=bit;
        if(i<j){float r=a[2*i],im=a[2*i+1];a[2*i]=a[2*j];a[2*i+1]=a[2*j+1];a[2*j]=r;a[2*j+1]=im;}
    }
    for(unsigned width=2;width<=KF_WINDOW;width*=2){
        unsigned half=width/2,step=KF_WINDOW/width;
        for(unsigned base=0;base<KF_WINDOW;base+=width)for(unsigned i=0;i<half;i++){
            unsigned x=2*(base+i),y=2*(base+i+half),t=2*i*step;
            float r=twiddle[t]*a[y]-twiddle[t+1]*a[y+1];
            float im=twiddle[t]*a[y+1]+twiddle[t+1]*a[y];
            a[y]=a[x]-r;a[y+1]=a[x+1]-im;a[x]+=r;a[x+1]+=im;
        }
    }
    return true;
}
