#pragma once
#include <stdbool.h>
#include <stdint.h>

#define KF_ONSET_BANDS 32u
#define KF_ONSET_HISTORY 24u
/* Causal, bounded percussion-biased spectral novelty detector. No audio gain
 * control and no dependency on the display spectrum's selected band count. */
typedef struct {
    uint16_t edges[KF_ONSET_BANDS+1];
    float previous[KF_ONSET_BANDS], peak[KF_ONSET_BANDS];
    float history[KF_ONSET_HISTORY];
    float recent_power, gate_power, absolute_gate, noise_power;
    float score, threshold, previous_score, band_decay, level_decay;
    unsigned history_count, history_next;
    uint64_t first_us, last_us;
    bool armed, quiet, percussive;
} KfOnset;

void kf_onset_init(KfOnset *, float raw_floor_db);
float kf_onset_push(KfOnset *, const float power[KF_ONSET_BANDS], float rms_power,float high_density,
                    uint64_t time_us, float sensitivity, unsigned refractory_ms);
