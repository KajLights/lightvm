#pragma once
#include "kaj_audio_features.h"
#include <stdatomic.h>
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
typedef struct { uint32_t epoch; KfFrame frame; } KfMessage;
typedef struct { uint32_t epoch, address; bool online; } KfNetwork;
typedef struct {
    atomic_uint frames, onsets, gaps, clipped, overwritten, sent, send_errors, stale, backpressure;
    atomic_uint analysis_last_us, analysis_max_us, analysis_overruns;
    atomic_uint analysis_total_us, analysis_calls;
    atomic_uint synthetic_generate_max_us, synthetic_late_max_us;
    atomic_uint subscribers, offers, lease_expired, lease_full, control_invalid, control_limited;
    atomic_int send_errno;
} KfStats;
extern KfStats kf_stats;
extern QueueHandle_t kf_mailbox;
KfNetwork kf_network_state(void);
int kf_network_rssi(void); /* dBm, or -127 when unavailable. */
void kf_publisher_task(void *);
void kf_fft_init(void);
bool kf_fft(float *);
bool kf_selftest(KfAnalysis *);
