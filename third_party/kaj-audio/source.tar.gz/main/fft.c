#include "runtime.h"
#include "dsps_fft2r.h"
#include "esp_check.h"
#if !CONFIG_DSP_OPTIMIZED || !dsps_fft2r_fc32_aes3_enabled
#error "kaj-fi requires the ESP32-S3 optimized FFT"
#endif
static _Alignas(16) float twiddles[KF_WINDOW];
void kf_fft_init(void) { ESP_ERROR_CHECK(dsps_fft2r_init_fc32(twiddles,KF_WINDOW)); }
bool kf_fft(float *data)
{
    return dsps_fft2r_fc32(data,KF_WINDOW)==ESP_OK && dsps_bit_rev2r_fc32(data,KF_WINDOW)==ESP_OK;
}
